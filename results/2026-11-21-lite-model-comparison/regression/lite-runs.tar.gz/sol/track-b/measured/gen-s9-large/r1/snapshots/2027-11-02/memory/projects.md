# Current portfolio — as of 2027-11-02

All baseline descriptions, aliases, owners, sponsors and targets below come from the worker's 18 October portfolio map [nt-0001]. Unless noted, sponsor is **Putri Ashby**, and dates are **2027 targets, not completed milestones**. Open/done detail is in `commitments.md`.

## Cirrus
**Aliases:** Project Cirrus; portal message routing pilot; Redridge pilot. **Owner:** Keisha Hargrove. **Target:** **3 December**, moved from 22 November by Keisha on 2 November, acknowledged by Aroha. AI patient-portal message router at Redridge Children's Hospital, hosted on Kittiwake. [nt-0001, ch-0106]
- Build baseline changed to **security review; blocked for real patient data pending that review** on 22 October. No subsequent clearance observed. [nt-0003]
- Aroha and Keisha explicitly agreed to **limit the pilot to four wards** on 26 October (also baseline scope). [em-0067, nt-0001]
- Mathieu generated a **synthetic patient data set** on 26 October; reiterated 29 October. This is a workaround, not evidence of real-data authorization. [em-0061, ch-0090, em-0091, em-0106]
- Aroha sent Andres **security review package v3** on 26 October. Document still has unconfirmed dependencies/assumptions; training to confirm, timeline needs unit input, costs carried over, users out of scope; open questions about fallback if dependency slips and final sign-off. Sending is done; review approval is unknown. [em-0065, dc-0003]
- **SSO role mapping:** Stanley accepted via Aroha's 18 October thanks; reported blocked 28 October, **waiting on an unsigned agreement**. Do not assume which agreement without further evidence. [ch-0012, mn-0011]
- **Load test plan owner is Adebayo**, after Stanley's 22 October handoff. A 25 October recap refers to Thursday's Stanley offer and includes Stanley saying “on it”; it does not explicitly reverse the handoff. [mn-0007, em-0044, ch-0041]
- Stanley owns support playbook; **blocked 2 November, waiting on a vendor fix** (vendor/fix unspecified). [mn-0012] Keisha owns booking nurses onboarding (**back on 1 November after delay**, not evidence sessions booked/held); Parisa to share accessibility review; Anh's help-desk script request became official 29 October. [ch-0022, mt-0001, em-0024, ch-0057, ch-0086, ch-0097]
- **Anh accepted sending Cirrus rollout checklist to Aroha** on 1 November. **Aroha took ownership of slow page loads**; no fix recorded. [mt-0011]
- **Aroha accepted walking Mathieu through budget justification**; invitation for 3 November 14:00–14:30 (-05:00), not completion. Cirrus review placeholder invite is 2 November 15:00–15:45; agenda to follow, attendees NEEDS-ACTION. [ch-0096, ca-0008, ca-0006]
- Aroha API contract v2 completed 20 October, confirmed in 22 October status and 25 October recap. [mn-0006, em-0050, ch-0042]
- Pending Aroha work: discharge-summary reading list to Keisha, coffee with Putri about portal routing, data-flow diagram to Andres. **Privacy impact assessment for Luz completed 2 November**, reported directly by Aroha; not security clearance. Comms-plan review remains tentative. [em-0002, ch-0009, ch-0019, em-0014, mt-0007, ch-0080, ch-0082, em-0109, ch-0101]
- **Mathieu requirements matrix → Aroha officially accepted 2 November**, upgrading earlier tentative offer; no delivery. [mt-0007, ch-0104]
- **Mathieu fixed timeout errors 2 November**, reported 19:27 and acknowledged by Aroha. Earlier “I can fix” and a check-mark reaction were only an offer, not completion. This does **not** establish resolution of Aroha's separate slow-page-load work, SSO mapping, support-playbook vendor block or security hold. [ch-0109, ch-0110, mt-0011]
- 29 October status says flagship timelines are tight, but does not name which project in that risk sentence. [em-0091]

## Kittiwake (shared AI platform)
**Aliases:** platform; common platform; Kittiwake platform. **Owner:** Mathieu Wijaya. Shared AI platform for hospital tenants. [nt-0001]
- Onboarding baseline → hardening 18 October → **steady state** 20 October, corroborated by Aroha's 22 October status. [ch-0011, mn-0005, em-0050]
- Aroha owes Adebayo the Kittiwake lessons-learned note, offered during a Cirrus meeting; do not confuse this with a Cirrus deliverable. [mt-0003]

## Bed Management Tool Selection
**Aliases:** bed management bake-off; Kasane/Clelera evaluation; BMTS selection. **Owner:** Aroha. **Sponsor:** Rodrigo Abernathy. **Target:** 6 December. Tool choice for Fenthorpe Community Clinics; Kasane Systems and Clelera Systems in running. [nt-0001]
- Requirements gathering → **questionnaires** on 25 October. No vendor selection recorded. [ch-0051]
- Aroha still owes Anh requirements list and vendor comparison. Rubric confirmed 19 October; reference-check notes updated same day after Anh's comments. [mn-0001, ch-0043, em-0015, ch-0023]
- Kasane intro invite was 27 October 13:30–14:00 at -05:00; invite alone is not proof of attendance/outcome. **Sandbox access set up 1 November**; change password at first login; sandbox resets Sunday nights. No credentials retained, no login/evaluation outcome known. [ca-0004, em-0100]
- **Aroha accepted sending bed-management pricing comparison to Anh** 1 November. **2 November email is an unsent draft (X-Draft: true), attachment not yet added**, so Anh delivery remains open. A standup offer to send pricing comparison to **Adebayo** (“probably”, “maybe next week”) is a **separate tentative recipient/action**, despite Cirrus meeting context. Anh now says **Adebayo needs it by Thursday 4 November**; Aroha's “got it” acknowledges the need, not an explicit firm undertaking. Do not replace Anh with Adebayo or treat it as a Cirrus deliverable. Vendor comparison remains distinct. [ch-0095, mt-0010, ch-0103, em-0118]
- **Decision memo → Anh accepted 2 November (“on it”), due 3 November**. The edited ask changes **5 November to 3 November**; latest wording governs. This is separate from pricing/vendor comparisons; neither memo delivery nor a vendor decision is recorded. [ch-0108]

## Redridge Referral Triage Discovery
**Aliases:** Redridge discovery; referral triage work; RRTD discovery. **Owner:** Keisha. **Target:** 6 December. Redridge Children's Hospital discovery with evolving problem framing. [nt-0001]
- Planning → **site visit** on 25 October, despite update being in a Cirrus/Kittiwake meeting. [mt-0006]
- Aroha owes Keisha site-visit agenda, Anh stakeholder map, and offered Winifred introduction to Anh for referral triage work. No completions seen. [ch-0040, mt-0008, ch-0026]
- Keisha to countersign **Redridge data-use agreement by Friday 5 November**; 29 October recap is an offer reminder, not signature evidence. The channel ties this to referral discovery; do not equate it automatically with Cirrus SSO's unspecified unsigned agreement. [em-0071, ch-0092, mn-0011]

## AI Safety Rounds Workshop
**Aliases:** workshop; Elmfield workshop; AI safety rounds session. **Owner:** Anh; **Aroha owns slides**. **Target:** 22 November. For nurses at Elmfield General Hospital. [nt-0001]
- Planning → **logistics** on 21 October. Run-through held 29 October 14:00–14:30; no recorded decision changing workshop target. [mt-0002, ca-0005, mt-0009]
- Slides **v1 sent to Daniela 18 October**; **v2 sent to Aylin 27 October**. These are distinct versions and recipients, both done. [ch-0008, ch-0038, ch-0071]
- Aroha sent Anh **attendee list v2** on 26 October. The provided spreadsheet is actually a generic tracker: Data feed/access/documentation open; comms/sign-off not started; accessibility review not started and waiting on another team; testing done. **It contains no attendee names**, so actual attendance/counts are unknown. [em-0068, dc-0004]
- **Worker decided to use approach B for workshop feedback form on 1 November**; what approach B entails is unknown. **Registration reminder dropped**, superseded by this decision (formerly an unconfirmed ask to Anh). Refreshments suggestion was dropped/folded into a broader ask on 26 October; no broader ask details captured. [nt-0005, em-0028, mn-0009, mn-0010]
- Interpreter-booking notes initially accepted by Anh 21 October, handed to Mathieu 22 October, sent by Mathieu 28 October. No project explicitly assigned to those notes beyond meeting context. [mt-0002, em-0039, ch-0077, em-0082]

## Informatics Nurse Specialist Hire
**Aliases:** informatics nurse specialist search; REQ-3419; INS hire. **Owner:** Aroha. Central team hire. [nt-0001]
- Sourcing → screens 18 October → **panel** 20 October. No offer/hire result available. [ch-0006, ch-0024]
- Candidate **Bram** (transcript “Brame”); Chiamaka/Amaka owns reference checks, still not completed. [ch-0028, ch-0034, mt-0005, ch-0070]
- Aroha accepted submitting panel feedback to Chiamaka on 28 October, after tentative response to Aylin 27 October. Pending. [ch-0075, em-0080]
- Anh **sent Daniela candidate pack 21 October**; forward to Aroha and later recaps confirm same completion, not new obligations. [ch-0037, em-0036, mn-0008, mt-0005, em-0091]
- Anh's timeline initially suggested/unagreed, confirmed by worker 21 October, **sent 25 October**. Mathieu's role profile **shared 29 October**. Mathieu still owes interview plan; interview scorecard remains only suggested. [mn-0004, ch-0036, nt-0002, ch-0049, ch-0087, mt-0007, ch-0029]

## Kirkmarsh Responsible AI Use Framework
**Aliases:** AI framework; framework; responsible-use framework. **Owner:** Aroha. **Target:** 15 November. Hospital-wide responsible-AI policy drafted centrally and consulted widely. [nt-0001]
- Baseline drafting; **draft v1 circulated 21 October**, corroborated by Putri and 22 October status. No final approval known. [ch-0035, em-0041, em-0050]
- Aroha accepted **rewrite of AI-use guiding principles** 28 October. Pending. [ch-0076]
- PDF draft v1 received 22 October: glossary terminology; assumptions need checking; scope carried over; data to confirm; security agreed at last review; integration reworded; open questions on maintainer and scope. “Security agreed” in this framework is **not Cirrus security clearance**. [dc-0001]

## Okapi
**Aliases:** Project Okapi; supply par levels prototype. **Owner:** Aroha. **Target:** 17 November. In-house supply par-level prototype incubated centrally before hospital adoption; Frostmere involved. [nt-0001]
- Concept → **prototype** on 22 October. [em-0047]
- **Demo prototype to Michaela proposed for Aroha 2 November**, no action owner agreed. This does not change baseline project ownership (Aroha). [mn-0012]
- Waiting on Anh roadmap slide (18 October action); Anh user journey map accepted 27 October and resumed 28 October, not delivered as of 29 October recap; Aino usability test script noted 28 October. [mn-0001, mt-0007, ch-0066, em-0079, ch-0089, nt-0004]

## Kittiwake Funding Model
**Aliases:** recharge model; funding options; Kittiwake recharge. **Owner:** Aroha. **Target:** 12 November. Funding options across hospitals ahead of Clinical Operations Council. [nt-0001]
- Baseline drafting options; no final model selection/approval or Council outcome supplied.
- **Funding options memo to Putri cancelled 25 October (“no longer needed”)**; this does not cancel whole project. [em-0011, em-0053]
- Malia Guo (Finance Shared Services) owns rebasing usage forecast; **picked back up 1 November**, no completion. [em-0029, ch-0055, em-0104]
- **Anh cost-model review by Aroha completed 29 October**, reconfirmed in 2 November historical recap; not new work. Anh assumptions-log review is a separate, still only suggested item. [em-0088, ch-0086, mn-0009, ch-0102]
- **Agreed budget now exists**, per Malia 2 November; she cannot put numbers in email yet, so **amount, currency, breakdown and approvers unknown**. This is not evidence of final model selection/Council approval or forecast delivery. Malia requested funding-model budget justification from Aroha; no acceptance. **Distinct from Cirrus budget walkthrough with Mathieu.** [em-0116]
- Aroha requested **funding-model API credential setup from Mathieu** 2 November; acceptance/setup unknown, no credential values supplied or retained. [em-0115]

## Clelera Enterprise Agreement
**Aliases:** Clelera deal; Clelera renewal. **Owner:** Kenji Faure. **Target:** 22 November. One Clelera agreement covering all hospitals rather than separate deals; Fenthorpe, Clelera Systems and Fenory Clinical involved. [nt-0001]
- Baseline negotiating terms; no executed agreement, final pricing or volume tiers recorded.
- **Clelera volume tiers:** tentative 18 October → official/accepted 19 October, Winifred taking ownership again 20 October. Still waiting; 21 October recap does not mean received. [ch-0013, ch-0014, ch-0015, em-0016, mt-0001, ch-0030]
- **Fenory volume tiers** are a distinct deliverable from **Douglas Cardenas**, Fenory Account Executive, reported by Ronit 26 October. Pending. [ch-0059]
- Mpho **shared action log v2 26 October**. Document: costs to confirm; data two options/no preference; integration out of scope; support draft; figures indicative/rounded; final sign-off and maintenance ownership open. [em-0063, dc-0002]
- Aroha owes Kenji counter-proposal (confirmed 25 October); Anh seat-count summary remains request only (25 October). Anh **requested negotiation brief 1 November** in email and chat; Aroha's “good to know” is acknowledgment, not acceptance. Putri's 2 November transcript recap says Aroha said yesterday they'd send it, but Aroha only says “Fair”/“Mm-hmm”; this ambiguous automated recap does not establish a new explicit undertaking or override the direct 1 November evidence. **Acceptance remains unconfirmed**, not delivered. Keep all three deliverables distinct. [em-0049, ch-0053, em-0054, em-0103, ch-0098, mt-0012]
- **Anh redline summary → Aroha suggested 2 November**, no owner agreed. Distinct from Aroha's negotiation brief and counter-proposal. [mn-0012]
- Anh-to-Aroha status slide had working-session invite 25 October; sharing/completion unconfirmed. [ca-0003]
- **Winifred returned security questionnaire 29 October** after Aroha's 28 October ask. Not evidence of approval or signing the deal. [em-0085, em-0089]
- Pricing comparison **Mpho → Margaux** still unagreed (29 October); Aroha review of Anh renewal timeline also tentative (“I'll think about it” in workshop run-through). [ch-0083, mt-0009]

## Frostmere Radiology Follow-up Discovery
**Aliases:** Frostmere discovery; radiology follow-up work; FRFUD discovery. **Owner:** Aroha. **Target:** 29 November. Discovery/site visits looking for AI opportunities before build. [nt-0001]
- Baseline site visits, no later stage change recorded.
- Achieng owns Frostmere baseline-data pull, and **Frostmere data-use agreement countersignature** (to Michaela). No deadline/signature evidence; 29 October recap still a promise. [ch-0018, em-0072, ch-0091]
- Anh pain-point list resumed 27 October; subsequent recap 28 October still only an agreement reminder, not delivery. [mn-0010, ch-0061, em-0075, ch-0078]
- Aroha **updated opportunity list after Anh comments 27 October**. Separate **process map review accepted 28 October**, reconfirmed 29 October and 2 November; not yet done. [ch-0065, mt-0007, ch-0081, ch-0085, ch-0100]
- **Observation notes sent to Anh 2 November**, directly reported by Aroha and thanked by Anh after same-day request. This does not complete process-map review or pain-point list. Notes contents not supplied. [ch-0105, ch-0107]
- Clinical safety case to Anh remains only suggested with no owner agreed. [mn-0010]

## Vashmere Partnership
**Aliases:** Vashmere relationship; Vashmere. **Owner:** Aroha. Ongoing relationships with Vashmere Nursing Research Collaborative; Fenthorpe/Ronit involved. [nt-0001]
- **Lilit introduced to Anh 19 October** for working group. **Lilit introduced to Isabela 26 October**, corroborated 29 October status. Distinct introductions, both done. [em-0009, em-0010, em-0070, ch-0060, em-0091, em-0101]

## Kittiwake Operating Model Review
**Aliases:** operating model review; ops model draft; Kittiwake operating model. **Owner:** Mathieu. Baseline peer review before leadership. [nt-0001]
- **Project now in revision**, per 2 November automated standup notes. Aroha review of Mathieu **draft v2 parked 27 October, superseded by a decision**; revision does not reopen that specific task. Underlying decision contents unknown. Do not claim draft was reviewed/approved. [mn-0005, ch-0062, mn-0012]

## Denials Analytics Advisory
**Owner:** Aylin Bianchi. **Aliases:** denials analytics advice; Elmfield denials analytics advisory. Light-touch advice, **no NDO deliverables of its own**, advising as needed. No later project-specific update supplied. [nt-0001]

## Frostmere Clinical Documentation Idea
**Owner:** Achieng. **Aliases:** Achieng's clinical documentation idea; clinical documentation placeholder. **Still waiting on Achieng problem statement**; baseline placeholder, no delivery recorded. [nt-0001, ch-0005]

## Clelera Intake Forms Diligence
**Owner:** Aroha. **Aliases:** Clelera deep dive; intake forms diligence. Elmfield/Clelera/Fenory; **stalled/gone quiet** baseline. **Still waiting on Winifred deep-dive materials**. Do not conflate with volume tiers, security questionnaire, or enterprise agreement. [nt-0001, ch-0010]
- Aroha accepted Michaela's **intake forms panel** 22 October; date/project linkage not explicit, so this alone does not establish revival of diligence. [ch-0039]

## Nurse Scheduling Learning Series
**Owner:** Anh. **Aliases:** learning series; nurse scheduling talks. Nurse series run with Vashmere, Redridge involved. Quiet/no sessions booked baseline → revived in 26 October automated lunch-and-learn recap → **scheduling** per Anh in 1 November leads transcript. No actual session bookings/dates supplied. Units seeing overreach and overcommitment were discussed in that segment; concerns, not cancellation or target change. [nt-0001, mn-0010, mt-0011]
