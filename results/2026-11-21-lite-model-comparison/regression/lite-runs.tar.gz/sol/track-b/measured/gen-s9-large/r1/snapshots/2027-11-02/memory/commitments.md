# Commitment ledger — 2027-11-02

**No due date means none supplied, not overdue.** “Open/accepted” means explicit undertaking with no completion seen. “Requested/tentative” is not an accepted obligation. Sources may describe actions for people other than the worker; keep actor/recipient separate. Later historical recaps do not reset dates or override handoffs.

## Aroha — accepted and open
| Project/context | Action and recipient | Accepted/known since | Evidence |
|---|---|---|---|
| Bed management | Send requirements list to Anh | 18 Oct (automated action) | mn-0001 |
| Cirrus / reading favor | Send discharge-summary reading list to Keisha | 18 Oct, repeated 19 Oct | em-0002, ch-0009, mn-0003 |
| Cirrus | Set up coffee with Putri about portal message routing | 19 Oct | ch-0019, em-0014, ch-0020 |
| Kittiwake | Send lessons-learned note to Adebayo | 22 Oct | mt-0003 (“Adebaio” transcription) |
| Intake forms panel, project/date unspecified | Join Michaela's panel on intake forms | 22 Oct | ch-0039 |
| Redridge referral discovery | Send site-visit agenda to Keisha | 22 Oct | ch-0040 |
| Clelera enterprise | Draft counter-proposal to Clelera for Kenji | Requested 22 Oct, explicitly reconfirmed 25 Oct | em-0049, ch-0053 |
| Bed management | Send vendor comparison to Anh | 25 Oct | ch-0043 |
| Cirrus | Send data-flow diagram to Andres | 27 Oct | mt-0007 |
| Redridge referral discovery | Send stakeholder map to Anh | 27 Oct | mt-0008 |
| INS hire | Submit Bram panel feedback to Chiamaka | Accepted 28 Oct (tentative 27 Oct) | em-0080, ch-0075 |
| Responsible AI framework | Rewrite AI-use guiding principles | 28 Oct | ch-0076 |
| Frostmere radiology discovery | Review Anh process map | 28 Oct, reconfirmed 29 Oct and 2 Nov; not completed | ch-0081, ch-0085, ch-0100 |
| Bed management | Send pricing comparison to **Anh** (distinct from vendor comparison and tentative Adebayo offer) | 1 Nov 12:48; **2 Nov unsent draft, attachment not yet added**; delivery still open | ch-0095, em-0118 |
| Bed management | Send decision memo → Anh | Accepted 2 Nov “on it”; **due 3 Nov**, edited from 5 Nov; distinct from comparisons | ch-0108 |
| Cirrus | Address slow page loads | 1 Nov leads call | mt-0011 |
| Cirrus | Walk **Mathieu** through budget justification | 1 Nov; scheduled 3 Nov 14:00–14:30 -05:00 | ch-0096, ca-0008 |
| NDO reporting | Send Putri Friday status note w/e 5 Nov: half page, moved/slipped/leadership needs | Reminder 1 Nov; **due 5 Nov EOD**; not sent | em-0097 |
| Referral triage relationship favor | Introduce Winifred to Anh for referral triage work | 20 Oct offer, not yet done | ch-0026 |

The last item is a first-person offer; no recipient acceptance or delivery is recorded. Keep distinct from completed Lilit introductions.

## Waiting on others — accepted/reported undertakings, no delivery seen
| Actor | Deliverable / recipient | Current status | Evidence |
|---|---|---|---|
| Achieng Colombo | Clinical documentation problem statement → Aroha | Long-running wait, reconfirmed 18 Oct | nt-0001, ch-0005 |
| Winifred Tanaka | Clelera deep-dive materials → Aroha | Long-running wait, promised 18 Oct | nt-0001, ch-0010 |
| Anh Villanueva | Okapi roadmap slide → Aroha | 18 Oct automated meeting action | mn-0001 |
| Winifred Tanaka | **Clelera** volume tiers → Aroha | Official 19 Oct; still no receipt | ch-0014, ch-0015, em-0016, mt-0001, ch-0030 |
| Stanley Valdez | Cirrus single sign-on role mapping | **Blocked 28 Oct: unsigned agreement** | ch-0012, mn-0011 |
| Stanley Valdez | Cirrus support playbook | **Blocked 2 Nov, waiting on a vendor fix**; vendor/fix unspecified | ch-0022, mt-0001, mn-0012 |
| Achieng Colombo | Radiology follow-up baseline data from Frostmere → Aroha | Accepted 19 Oct | ch-0018 |
| Keisha Hargrove | Book nurses onboarding sessions for Cirrus | Accepted 20 Oct; **back on 1 Nov after delay**, booking/completion not confirmed | mn-0006, em-0024, ch-0097 |
| Chiamaka Rashed / Amaka | Check references for Bram | Reported 20 Oct; numerous historical recaps, no completion | ch-0028, ch-0034, mn-0008, mt-0005, ch-0070 |
| Malia Guo | Rebase funding-model usage forecast | Reported 21 Oct; **resumed 1 Nov**, not delivered | em-0029, ch-0055, em-0104 |
| **Adebayo Kahananui** | Draft Cirrus load test plan | **Handed from Stanley 22 Oct**; 25 Oct recap describes old Stanley offer, no explicit reverse handoff | mn-0007, em-0044, ch-0041 |
| Parisa Chaudhry | Cirrus accessibility review → Aroha | Reported 26 Oct | ch-0057 |
| Douglas Cardenas (Fenory) | **Fenory** volume tiers → Aroha | Reported by Ronit 26 Oct; not Clelera tiers | ch-0059 |
| Anh Villanueva | Radiology discovery pain-point list → Aroha | 26 Oct accepted action; resumed/moving 27 Oct; recap 28 Oct, **not sent** | mn-0010, ch-0061, ch-0063, em-0075, ch-0078 |
| Keisha Hargrove | Countersign Redridge data-use agreement → Anh | **Due Friday 5 Nov**; 29 Oct recap not a signature | em-0071, ch-0092 |
| Achieng Colombo | Countersign Frostmere data-use agreement → Michaela | Accepted 26 Oct; reiterated 29 Oct; **no due date** | em-0072, ch-0091 |
| Anh Villanueva | Okapi user journey map → Aroha | Accepted 27 Oct; picked back up 28 Oct; 29 Oct recap not delivery | mt-0007, ch-0066, em-0079, ch-0089 |
| Mathieu Wijaya | INS interview plan → Aroha | Accepted 27 Oct | mt-0007 |
| Aino Menon | Okapi usability test script → Aroha | Worker voice memo undertaking, 28 Oct | nt-0004 |
| Anh Villanueva | Cirrus help-desk script → Aroha | **Official 29 Oct**, after “I'll think about it” 25 Oct | mt-0004, ch-0086 |
| Anh Villanueva | Cirrus rollout checklist → Aroha | Accepted 1 Nov, no delivery seen | mt-0011 |
| Mathieu Wijaya | Cirrus requirements matrix → Aroha | **Official/accepted 2 Nov**, previously tentative; not shared yet | mt-0007, ch-0104 |

## Requested / proposed / tentative — do not present as accepted
| Proposed actor | Request / recipient | Evidence and qualification |
|---|---|---|
| Mathieu | INS interview scorecard → Aroha | mn-0005 suggested/no owner; ch-0029 explicitly not agreed |
| Aroha | Review Anh funding-model assumptions log | mn-0009 explicitly still open; **not same as completed cost-model review** |
| Anh | Share Clelera enterprise status slide → Aroha | ca-0003 session invite for 25 Oct; no delivery evidence |
| Aroha | Clelera enterprise seat-count summary → Anh | em-0054 request only; no explicit acceptance/delivery |
| Aroha | Radiology discovery clinical safety case → Anh | mn-0010 suggested/no owner agreed |
| Aroha | Coffee with Putri about **prior authorization** | ch-0068 Lilit reports expectation; worker “maybe”; **different from accepted portal-routing coffee** |
| Aroha | Review Keisha Cirrus comms plan | ch-0080 “let me check and get back to you” |
| Mpho | Clelera enterprise pricing comparison → **Margaux**, not Aroha | ch-0083 explicitly not agreed |
| Aroha | Review Anh Clelera enterprise renewal timeline | mt-0009 “I'll think about it” |
| Aroha | Send bed-management pricing comparison → **Adebayo** | mt-0010 tentative 1 Nov; **ch-0103 says Adebayo needs it by 4 Nov**, worker “got it” acknowledgment, not explicit acceptance; **not same as accepted Anh recipient**; em-0118 draft to Anh is not delivery to either recipient |
| Aroha | Send Clelera enterprise negotiation brief → Anh | em-0103, ch-0098 ask 1 Nov; worker “good to know” only. mt-0012 Putri recap 2 Nov alleges yesterday's undertaking; worker “Fair”/“Mm-hmm” ambiguous. **Acceptance unconfirmed**, no delivery; do not promote from automated recap alone |
| Aroha | Demo Okapi prototype → Michaela | mn-0012 suggested 2 Nov, no owner agreed; not change of project owner |
| Anh | Clelera enterprise redline summary → Aroha | mn-0012 suggested 2 Nov, whether Anh picks it up still open; separate from negotiation brief |
| Mathieu | Set up funding-model API credentials → Aroha | em-0115 worker request 2 Nov; no acceptance/setup evidence; no credential values retained |
| Aroha | Funding-model budget justification → Malia | em-0116 request 2 Nov, no acceptance; distinct from accepted **Cirrus** budget walkthrough → Mathieu |

## Completed — retain date, actor and recipient
| Completed | Actor / action | Evidence |
|---|---|---|
| 18 Oct | Aroha sent **workshop slides v1 → Daniela** | ch-0008; historical confirmation ch-0038 |
| 19 Oct | Aroha introduced **Lilit → Anh**, Vashmere working group | em-0010 (request em-0009) |
| 19 Oct | Aroha confirmed bed-management evaluation rubric with Anh | em-0015 (action mn-0004) |
| 19 Oct | Aroha updated bed-management reference-check notes after Anh comments | ch-0023 (request mn-0002) |
| 20 Oct | Aroha turned around **Cirrus API contract v2** | mn-0006, em-0050, ch-0042 (request em-0020) |
| 21 Oct | Aroha circulated **AI-use framework draft v1** | ch-0035, em-0041, em-0050; document dc-0001 received 22 Oct |
| 21 Oct | **Anh sent INS candidate pack → Daniela** (not Aroha sending) | ch-0037, em-0036; historical mn-0008, mt-0005, em-0091 |
| 22 Oct 15:31 -05:00 | Aroha sent Putri status note **w/e 22 Oct**, meeting EOD deadline | em-0050; deadline em-0001, ch-0007 |
| 25 Oct 11:50 -05:00 | Anh sent **INS timeline → Aroha** | ch-0049; confirmation of undertaking nt-0002; earlier only tentative mn-0004/ch-0036 |
| 26 Oct | Mathieu generated **Cirrus synthetic patient data set** | em-0061; ch-0090, em-0091, em-0106 later confirmations (not new work/clearance) |
| 26 Oct 14:21 -05:00 | Mpho shared **Clelera enterprise action log v2 → Aroha** | em-0063, dc-0002 |
| 26 Oct 15:06 -05:00 | Aroha sent **Cirrus security package v3 → Andres** | em-0065, dc-0003 (request ch-0058); not review approval |
| 26 Oct 16:04 -05:00 | Aroha sent **workshop attendee list v2 → Anh** | em-0068, dc-0004 (request mn-0010); spreadsheet lacks attendee names |
| 26 Oct 17:54 -05:00 | Aroha introduced **Lilit → Isabela**, Vashmere working group | ch-0060, em-0091, em-0101 (1 Nov historical recap; request em-0070) |
| 27 Oct | Aroha updated **radiology discovery opportunity list** after Anh comments | mt-0007 (request ch-0065); not process-map review |
| 27 Oct 16:49 -05:00 | Aroha sent **workshop slides v2 → Aylin** | ch-0071 (undertaking mt-0008) |
| 28 Oct 11:36 -05:00 | **Mathieu sent interpreter-booking notes → Aroha** | ch-0077, em-0082; initially Anh mt-0002, handed off em-0039 |
| 29 Oct 12:28 -05:00 | Aroha **reviewed Anh funding-model cost model** | ch-0086 (undertaking em-0088); ch-0102 historical recap 2 Nov; not assumptions log |
| 29 Oct 13:08 -05:00 | Mathieu shared **INS role profile → Aroha** | ch-0087 (undertaking ch-0025); not interview plan or scorecard |
| 29 Oct 13:16 -05:00 | Winifred **returned Clelera security questionnaire** | em-0089 (ask em-0085); not volume tiers or deep-dive materials |
| 29 Oct 16:09 -05:00 | Aroha sent Putri status note **w/e 29 Oct**, meeting EOD deadline | em-0091; deadline em-0051, ch-0056 |
| 2 Nov, reported 09:51 -05:00 | Aroha **completed Cirrus privacy impact assessment**, told Luz; not security clearance | ch-0101; acceptance em-0109 |
| 2 Nov, reported 15:03 -05:00 | Aroha **sent radiology discovery observation notes → Anh earlier today**; contents unknown; not process-map review | ch-0107; request ch-0105 |
| 2 Nov, reported 19:27 -05:00 | Mathieu **fixed Cirrus timeout errors earlier today**, acknowledged by Aroha; not slow-page-load resolution | ch-0110; preceding offer ch-0109 |

## Cancelled / parked / superseded — not active work
- **Funding options memo → Putri:** dropped 25 October, “no longer needed.” Not delivered, and not cancellation of entire funding project. [em-0011, em-0053]
- **Aroha review of Mathieu Kittiwake operating model draft v2:** parked 27 October, “superseded by a decision.” Decision contents unknown; do not claim reviewed or approved. [mn-0005, ch-0062]
- **Workshop refreshments → Anh:** initially suggested/unagreed 25 October; dropped 26 October, folded into broader ask. Broader ask not described. [mn-0009, mn-0010]
- **Workshop registration reminder → Anh:** previously request only; **dropped 1 November**, superseded by worker's **approach B feedback-form decision**. Approach B details unknown; do not retain reminder as active. [em-0028, nt-0005]
- **Cirrus 19 October 09:30–09:55 standup:** cancelled, covered in leads call. Not cancellation of recurring series or project. [ca-0002]

## Status-note content (historical)
- **w/e 22 Oct:** framework draft circulated; Cirrus API v2 turned around; Kittiwake steady state; risk: vendor answers outstanding. [em-0050]
- **w/e 29 Oct:** Lilit→Isabela introduction; Mathieu synthetic Cirrus data; Anh→Daniela INS candidate pack; risk: flagship timelines tight (flagship not named). [em-0091]
