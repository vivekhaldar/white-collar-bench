# People and organizations

## Worker and central organization
**Aroha Mendoza** is the worker, in **Network Digital Office (NDO), Kirkmarsh Health Partners**. Owns bed-management selection, INS hire, responsible AI framework, Okapi, funding model, Frostmere radiology discovery, Vashmere relationship and Clelera intake diligence; owns workshop slides while Anh owns workshop. Formal job title not supplied. [nt-0001]

All roles below from [nt-0001] unless another ID is shown. Roles are not inferred from participation.

| Person / alias | Role and organization | Useful context |
|---|---|---|
| Putri Ashby | Chief Digital Officer, NDO | Most portfolio projects' sponsor; receives Friday status notes [nt-0001, em-0050, em-0091] |
| Anh Villanueva / Anh / @anh | Director of Digital Programs, NDO | Workshop and learning-series owner; frequent collaborator, funding/Okapi/INS inputs [nt-0001] |
| Mathieu Wijaya | Principal, Integration Platform, NDO | Kittiwake and operating-model owner; synthetic Cirrus data, INS role/profile/plan, interpreter notes; requirements matrix accepted, timeout errors fixed 2 Nov [nt-0001, em-0061, ch-0087, mt-0007, ch-0077, ch-0104, ch-0110] |
| Andres Yamamoto | Principal, Information Security, NDO | Requested/received Cirrus security package; awaits data-flow diagram [ch-0058, em-0065, mt-0007] |
| Kiran Hayashi | Integration Engineer, NDO | Cirrus/platform participant |
| Marguerite Teixeira / Margo | Product Lead, Clinical Apps, NDO | Alias inferred from matching Cirrus participant lists [ch-0041, ch-0057] |
| Chiamaka Rashed / Amaka | Talent Acquisition Partner, Kirkmarsh Health Partners | Checking Bram references; Aroha accepted panel feedback; Amaka linked by email recipient and greeting [ch-0034, em-0080] |
| Kenji Faure | Supply Chain Contracts Manager, Kirkmarsh Health Partners | Clelera enterprise owner; requested counter-proposal [em-0049, ch-0053] |
| Malia Guo | Director, Finance Shared Services | Funding usage-forecast rebase [em-0029, ch-0055]; reports agreed funding-model budget but numbers withheld, asks Aroha budget justification [em-0116]; wider formal org not explicitly supplied |
| Sanjay Quinlan | Events Coordinator | Room confirmations, survey, catering [em-0007, em-0034, em-0093] |
| Luz Ekwueme | Role not supplied | Cirrus privacy impact assessment **completed by Aroha 2 Nov**, acknowledged by Luz; not security clearance [ch-0082, em-0109, ch-0101] |
| Mikayla Babic | Role not supplied | Team retro/leads-related meetings [mn-0002, mn-0006] |
| Amira Andersen | Role not supplied | Lunch-and-learn attendee [mn-0010] |

## Redridge Children's Hospital
| Person | Role | Context |
|---|---|---|
| Keisha Hargrove | Operations Director | Cirrus and referral-discovery owner; nursing onboarding; Redridge agreement due 5 Nov [nt-0001, em-0024, em-0071] |
| Babajide Hendriks / Jide | Revenue Cycle Analyst | Cirrus/referral/framework/platform participant; alias explicit in portfolio |
| Stanley Valdez | Application Analyst | Cirrus SSO mapping/support playbook; load test handed to Adebayo [ch-0012, ch-0022, em-0044] |
| Adebayo Kahananui | Charge Nurse | Cirrus load test current owner; awaits Kittiwake lessons note [em-0044, mt-0003] |
| Parisa Chaudhry | Chief Medical Information Officer | Cirrus accessibility review to Aroha [ch-0057] |

## Fenthorpe Community Clinics
| Person / alias | Role | Context |
|---|---|---|
| Rodrigo Abernathy | Chief Medical Information Officer | Bed-management sponsor |
| Ronit Kusuma | Director of Pharmacy | Bed-management questionnaires update; reported Fenory tiers [ch-0051, ch-0059] |
| Isabela Mensah / Bela | Application Analyst | Bela identity inferred from matching project participants and DM title [ch-0030, ch-0051]; Lilit introduction recipient [ch-0060] |
| Mpho Sengupta | Revenue Cycle Analyst | Clelera enterprise action log shared; proposed comparison recipient is Margaux [em-0063, ch-0083] |
| Margaux Shami | Role unknown; Fenthorpe attendee designation | Attended bed-management/Cirrus sync [mn-0006]; likely Margaux in pricing request, surname not repeated there [ch-0083] |

## Elmfield General Hospital
| Person | Role | Context |
|---|---|---|
| Aylin Bianchi | Clinical Informatics Lead | Denials-advisory owner; INS stage updates; receives workshop slides v2 [nt-0001, ch-0024, ch-0071] |
| Oksana Salazar | Nurse Informaticist | Workshop/denials participant |
| Dominic Agarwal | Charge Nurse | Workshop participant |
| Daniela Ochieng | Application Analyst | Receives workshop slides v1 and INS candidate pack; workshop run-through [ch-0008, ch-0037, mt-0009] |

**Daniela Ochieng and Achieng Colombo are different people.**

## Frostmere Rehabilitation Center
| Person / alias | Role | Context |
|---|---|---|
| Achieng Colombo / Achieng | Director of Patient Access | Clinical-doc idea owner; radiology baseline, Frostmere countersignature; Okapi prototype update [nt-0001, ch-0018, em-0072, em-0047] |
| Michaela Dang | Application Analyst | Frostmere agreement recipient; intake-forms panel host [em-0072, ch-0039] |
| Aino Menon | Interface Engineer | Okapi usability script [nt-0004] |

## Vendors, research and other people
- **Winifred Tanaka / Winnie / W:** Account Executive, **Clelera Systems**. Owes deep-dive materials and Clelera tiers; returned security questionnaire 29 October. [nt-0001, ch-0010, em-0016, em-0089]
- **Eleni Rattanakorn / Lena:** Solutions Engineer, **Kasane Systems**. Set up Aroha's sandbox access 1 November; signature “Lena” alongside full name. Access details are not retained. [em-0100]
- **Douglas Cardenas:** Account Executive at **Fenory**; to send **Fenory** tiers, distinct from Winnie's Clelera tiers. [ch-0059]
- **Lilit Wekesa:** Senior Research Scientist, **Vashmere Nursing Research Collaborative**. Introduced to Anh 19 October, Isabela 26 October for Vashmere working group. Also reports interpreter notes completion and prior-authorization coffee expectation. [em-0009, em-0010, ch-0060, em-0082, ch-0068]
- **Bram:** INS candidate; surname and hiring outcome unknown. “Brame” in automated transcript is treated as spelling noise alongside repeated Bram messages. [ch-0028, mt-0005, ch-0070, em-0080]
- **Ziad Conti:** Lanminster Medical Center attendee, formal role unknown. [mt-0002]
- **Temitope Laurent:** Marketing, Clelera; sends promotional messages, not procurement commitments. [em-0012]
- **Paolo Rocha:** Conference Organizer, Regional Digital Services Summit promotional notices. [em-0022]
- **Katarzyna Boateng:** Health Systems Dispatch newsletter sender; no collaborator relationship established. [em-0033]

## Organization relationships
Redridge, Elmfield, Frostmere and Fenthorpe are the hospital/clinic partners in the worker portfolio; NDO is central. Kasane Systems and Clelera Systems compete in Fenthorpe bed-management selection. Clelera Systems and Fenory Clinical also occur in enterprise agreement/intake diligence, but no final vendor selection or signed agreement is known. Vashmere is a nursing research collaborative, not a hospital. [nt-0001]

## Transcript identity caution
“Arohah”→Aroha, “Anhe”→Anh, “Adebaio”→Adebayo and “Brame”→Bram are likely transcription variants supported by surrounding direct-source names. “Daniela's iPhone” is a device speaker label in the workshop run-through, not a newly identified colleague; “Mathieu's iPhone” similarly appears in the 1 November leads call. [mt-0002, mt-0003, mt-0005, mt-0007, mt-0009, mt-0011]
