# Commitments and waiting-on — 2027-03-02 close

Dates are targets/requests, not completion guarantees. Unconfirmed means no completion evidence. Calendar times floating local as supplied.

## Calendar / deadlines
| When | Item | Evidence / caveat |
|---|---|---|
| Weekdays 09:15–09:30, 22 Feb–2 Apr | Tinderbox standup, KES Huddle Room 2B/video | ca-0002; 1 Mar standup occurred [mt-0004] |
| Tue 2 Mar 10:00–12:30 — completed | Saltmarren transfer site visit | mn-0007; 3 evaluator interviews, no records copied/taken off campus |
| Tue 2 Mar 16:00–16:30 — completed | Chargeback private review, VC conference room 4B/video | mt-0008, dc-0007; paper delivered, v2 modeling rerun done |
| **Wed 3 Mar all day** | Leadership offsite, all principals incl. Mara/Sade/Ilya; **bus 07:30** System Office front entrance, won't wait; return ~17:00 | mt-0006, nt-0005; no laptops, phones at breaks/off during sessions. Breakfast/lunch provided, business casual, venue name unknown. Ramona covers Tinderbox standup/workshop logistics; Bartosz on-call/Ilya escalation for Kettleyard, Lulu reachable at desk |
| **Wed 3 Mar 10:00** | Saanvi load test on shared tenant; synthetic data only | mt-0007; 500 concurrent, 10-min ramp/20-min hold, p95 <2s; Bartosz platform support; not yet run |
| **Wed 3 Mar noon** | **Deck v2 to Ramona before handout printing** | ch-0008; Mara accepted. 5am Tuesday was joke, not deadline |
| **Thu 4 Mar 11:00–11:30** | **Delphine/Mara check-in**, video; scorecard summary, DSA, site-visit observations | ca-0004 sequence 1, moved from Wednesday; Delphine accepted, Mara NEEDS-ACTION |
| Thu 4 Mar 13:00–16:00 | Teaching with AI workshop, Pellery Hall 112 | ch-0004, dc-0005 |
| **Thu 4 Mar 15:00–15:30 — canceled** | Sade/Mara 1:1 occurrence | ca-0005 METHOD:CANCEL sequence 2. Lulu will find next-week slot; none booked; does not cancel chargeback review or workshop |
| Fri 5 Mar | Weekly update directly to Sade, subject `Weekly update: w/e 5 Mar`, three bullets + one risk | em-0019; not sent yet; don't reply-all |
| This week (1–5 Mar) | Mara scorecard summary to Delphine, both vendors + internal-build column | mt-0005, em-0029; accepted, unfinished; useful for 4 Mar agenda but no explicit earlier deadline |
| **Thu 4 Mar** | Mara event-based spec v2 to Dima / ARB | ch-0013; firm Thursday promise and contract-stability assurance; not delivered |
| This week, tentative | Mara Tinderbox security package to Hyun-woo | nt-0005, em-0031; still unsent draft, retention half done/subprocessor list missing |
| **Tue 9 Mar** | Writing-tool RFQ requirements to Clement, Word draft acceptable, not slides | em-0030; functional/technical/security/accessibility/support/data handling; confidential budget ceiling must not go to vendors |
| **Wed 10 Mar** | Council one-pager to Sade only; 3 bullets + 1 risk | mt-0008; expansion conditional first, options second, actuals risk; no campus written distribution |
| **Wed 10 Mar**, conditional | Dima full event-based LMS context API | mt-0007; depends on v2 in hand; original 5 Mar superseded |
| **Fri 12 Mar** | Mara Tinderbox PIA questionnaire to Hana | em-0027; book 30-min data-flow walkthrough before filling in; questionnaire attachment unavailable |
| **Mon 15 Mar** | MFA mandatory on staff/faculty accounts | em-0025, mt-0006; check second factor/backup/mobile before then, Mara enrollment unknown |
| **Tue 16 Mar**, time unknown | Product roadmap review, moved from 9 Mar | mt-0006; support-owner lines required, updated invite reported but not supplied |
| This week | Juni three-campus Penmarq pricing; Aga Scrivelo DPA markup | mt-0005, em-0017; pricing moved from pre-demo ask, no receipt |
| Fri 12 Mar Council of Campus CIOs | Chargeback options; no model chosen | mt-0008; private review complete but **no written options to campuses before Council**, CFO conversations verbal only |
| Mid-March earliest/after midterms | Library RA can resume; concept note no rush | em-0002 |
| **Wed 17 Mar**, time unknown | Dentist moved to 17th | nt-0004; prior slot/location not supplied |
| Fri 19 Mar | Transfer discovery readout target | nt-0001, em-0017; signed DSA/baseline not guaranteed |
| Fri 26 Mar | Writing tool recommendation target | mn-0003; not moved by hypothetical April selection discussion [mt-0005] |
| Mon 29 Mar | Tinderbox go-live target, stays on board for now | mt-0004; security, ARB/v2 API, group claims, tenant gates |
| Mon 8 / Tue 9 / Wed 10 Mar, times unknown | Faculty onboarding CHEM / HIST / BIOL, Library Room 2.14 | mt-0007; Ingrid booked one first session per course; dummy data, not real course/student processing |

## Mara's open work
- **Spec v2 event-based context contract due Thu 4 Mar**, promised to Dima with no subsequent changes; → ARB, event types/payloads/acknowledgment/replay/missed events, retain applicable v1 fields. Dima polling stopped; full API target 10 Mar conditional on v2. [mt-0004, mt-0007, ch-0013]
- **Finish/send security package** → Hyun-woo, Yusra cc: architecture/data flows written, retention half done, **subprocessor list missing**, attachments TODO, still **draft, not sent** at 22:47. No firm deadline/approval date. Published classification/Teo ticket identity config; not dependent on load results/v2 endpoint shapes. [nt-0005, em-0031, mt-0004]
- **PIA to Hana by 12 Mar**, arrange **30-min walkthrough before filling questionnaire**; flag campus practice for Yusra follow-up. Both PIA + security clearance needed before real student data. No booking/submission/approval; attachment not supplied. [em-0027]
- Rework Tinderbox evaluation around student-work outcomes, satisfaction likely secondary; revise leading survey question after CHEM rubric input. No firm due date or committed History circulation. [mt-0003]
- **Council chargeback one-pager to Sade by Wed 10 Mar**: 3 bullets + 1 risk, lead no Tinderbox expansion beyond Kestrow without chargeback agreement, options second, risk actuals unless worse. Paper/rebase/review done; no model chosen (Mara C, Sade leans B). No written options to campuses before Council; verbal CFO engagement only. FY28 cost owner/funding line unresolved. [mt-0008, dc-0007]
- **Deck v2 due 3 Mar noon:** tighten panel and resolve moderator/keynote/QR placeholders. [ch-0008, dc-0005]
- **Writing-tool scorecard summary this week** for Delphine; **add internal Kettleyard build column on same criteria** as Scrivelo/Penmarq. Not an assigned Lionel build estimate; no scores/winner. [mt-0005, em-0029]
- **Writing-tool RFQ requirements to Clement by Tue 9 Mar**: functional/technical/security/accessibility + scored support/data handling. Mara/Bettina named tier-2 post-handoff owner requirement, not ODS default; owner not selected. RFQ required, co-ops out of scope, demos/VSQs valid market research not repeated. Budget ceiling exists but numeric value unknown and must not be disclosed to vendors. [em-0029, em-0030]
- **Writing-feedback discovery use-case list to Delphine**, requested at site visit to prioritize bake-off, no date. **Quick look at advising appointment wait-time data promised to Tillie** (in Saltmarren scheduling system), no access/data yet; scope widening subject to Delphine. [mn-0007]
- Arrange **two-week Penmarq staff sandbox**: access delivered, invite individual accounts, sample drafts only under initial vendor guidance; tutor availability/start/end unknown. Clarify any student-derived anonymized draft use before upload. [mt-0005, em-0022]
- Baseline accuracy analysis for Delphine only after signed DSA/sample release; site interviews without copied/exported records. [nt-0003, em-0017]
- Mats scorecard **submitted**, all 3 in per Sol reported in evening worker note. Sol starts **two reference checks Wed 3 Mar**, references stage now, not checks completed or hire. Sade decides afterward. [nt-0005]
- **Sade + Bart Ngata post-live ownership meeting**: Mara asked Lulu 2 Mar for 45 min this week/next; Lulu looking Thu/Fri, invite pending. Request done, booking/decision not done. Hosting does not settle ownership. [ch-0011, ch-0009]
- Library concept note to Ramona Iturbe still owed, no rush/date. [em-0002]
- Morning note says tell Jack to stop dedicated option-1 pricing, now unnecessary. Hosting communicated in standup, explicit stop-pricing instruction not recorded; **do not keep costing as a required deliverable**. [nt-0004, mt-0004]

## Waiting on others / dependencies
| Person | Outstanding | Latest evidence |
|---|---|---|
| Hyun-woo / Hugo | Security clearance after complete package; no approval date; student-data debug-logging wording in v3 review | mt-0004, em-0013, em-0021 |
| Teo + Kestrow IdP vendor | KSD-20931 group-claim patch, no date; Teo implements release after patch; Pending Vendor, response clocks paused | em-0023, mt-0004 |
| Bartosz | Tenant questions/platform-side load support; tenant provisioning/cert/broker now done | mt-0007, ch-0012; actual tenant tinderbox-kes-01 |
| Jack / ARB | v2 return/approval before event-based build, no date | mt-0004 |
| Dima | Full event-based API **10 Mar conditional on v2** promised 4 Mar; ARB approval before build; dummy generator complete | mt-0004, mt-0007, ch-0013 |
| Ilya | Reference architecture **v4 by end week (5 Mar)**, folding 11 comments; then Mara/Bettina sync; no published v4 yet | mt-0006, ch-0012 |
| Ingrid | Conduct booked first onboarding CHEM 8 Mar, HIST 9 Mar, BIOL 10 Mar, Library Room 2.14 | mt-0007; times unknown, dummy data |
| Emeka | CHEM problem-set and lab-report rubrics | mt-0003 |
| Saanvi | Load execution **3 Mar 10:00**, live tenant/synthetic data, Bartosz platform support | mt-0007; not run yet |
| Greta | Finish tier-1 runbook, especially escalation placeholder; wiki team-only draft | mt-0004 |
| Ramona Szabo | Catering/AV and earlier program risk-register request | ch-0004, nt-0003; no completion |
| Lulu | 45-min Sade/Bart Ngata ownership invite, checking Thu/Fri; replacement canceled Sade 1:1 next week still unknown | ch-0011, ca-0005 |
| Percy | January-close finance actuals, **not FTE inputs (v2 delivered)** | em-0006, em-0011, em-0024 |
| Bettina | Catalog next-week-ish; named tier-2 onboarding owner/service location | ch-0005, em-0021 |
| Juni / Penmarq legal | Three-campus pricing this week; contractual no-training **essays + comments**, no legal answer | mt-0005; VSQ return reported [em-0022] |
| Corwin | Availability of two/three writing-center staff for sandbox; tutors slammed until after midterms | mt-0005; not confirmed staffing |
| Callum | Sandbox issue support directly; access already delivered | em-0022 |
| Scrivelo compliance / Grig | ACR now promised **Fri 5 Mar**, two comparable-campus references still absent. Proposed implementation call Fri 5 Mar 11:00/30 min, invite reported not supplied or accepted; no implementation commitment. Webinar 18 Mar 10:00 Pacific offer, no accepted seats | em-0028 |
| Hannah | LMS API docs including token refresh | mt-0002 |
| Lionel | LMS constraints/equal integration tests; minimum IdP attrs/course-copy verification | mt-0002, mt-0005; **no agreed internal build estimate** despite AI recap [mn-0004] |
| Delphine | Last-year ENGL 101/102 essay volumes | mn-0003 |
| Clement | Issue RFQ after Mara requirements due 9 Mar, supplies boilerplate/evaluation method | em-0030; **route answered: RFQ** |
| Aga / Saltmarren counsel | DSA retention finalization/signature then sample release, no date | em-0017 |
| Aga | Scrivelo DPA marked-up review this week | em-0017 |
| Sol / Sade | All scorecards in; Sol starts 2 reference checks **3 Mar**, Sade decision afterward | nt-0005; neither completed checks nor offer evidenced |
| Hana Kobayashi-Reyes | PIA walkthrough/review and campus-practice follow-up with Yusra | em-0027; Mara questionnaire due 12 Mar, separate from security |
| Niall | Citation checker requirements | nt-0001; no later activity |

## Done / canceled — do not re-open without new input
- One-pager delivered 16 Feb. [em-0004, dc-0001]
- Mats screen 17 Feb; **panel completed 1 Mar 14:00–15:30**. Leans yes. **Scorecards all in by 2 Mar evening** per worker/Sol, after 07:00 automated pending reminder. References next, not hire. [mn-0001, mn-0005, em-0026, nt-0005]
- VSQs sent 16 Feb; Scrivelo returned 24 Feb, Penmarq return reported 1 Mar. Actual attachments unavailable. [em-0003, em-0012, em-0022]
- FTE v1 delivered 18 Feb, **superseded by v2 1 Mar**; modeling must rerun. [em-0006, em-0024, dc-0006]
- Dropped on-campus GPU evaluation 20 Feb; **dedicated hosting option not chosen 1 Mar**, pricing no longer needed. [nt-0002, nt-0004, mt-0004]
- Spec v1 sent 22 Feb, **rejected by ARB 1 Mar**, not approved/usable current contract. [em-0010, mt-0004]
- SSO app registration/KSD-20788 closed 22 Feb, not claims patch. [ch-0003, em-0023]
- Workshop room/first dashboard lines 23 Feb; HIST/BIOL instructors reportedly committed. [ch-0004]
- Scrivelo demo 23 Feb; shortlist 24 Feb; **Penmarq demo 1 Mar**. [mt-0002, mn-0003, mt-0005]
- Connie accepted panel 24 Feb. [mt-0003]
- Deck v1/bios sent 25 Feb, v2 unfinished. [em-0014, dc-0005]
- Vendor scorecard template 26 Feb, no completed scores. [nt-0003]
- Rufus process map delivered by shared-drive reference 26 Feb, full map unavailable. [em-0016]
- Load plan done; dummy generator done 1 Mar; test not run. [ch-0006, mt-0004]
- **11 v3 review comments sent to Ilya 1 Mar 10:12**, no longer owed. [em-0021]
- **Three fresh Tinderbox dashboard lines delivered 1 Mar 17:30**, Ramona acknowledged: shared tenant, ARB wants v2, real data paused. Not deck v2 or risk-register completion. [ch-0008]
- Chargeback paper delivered 2 Mar, all modeling rerun on FTE v2, private review completed; Council one-pager remains owed. [dc-0007, ch-0014, mt-0008]
- Tenant signing cert arrived; provisioning/broker complete before 09:00 2 Mar, tenant tinderbox-kes-01 live; **not real-data clearance or pilot launch**. [mt-0007, ch-0012]
- Saltmarren site visit done 2 Mar, three evaluator interviews, no copied/exported records; DSA/baseline still blocked. [mn-0007]
- Procurement path answered 2 Mar, RFQ required, no repeated demos/VSQs. [em-0030]
- Sade 4 Mar 1:1 occurrence canceled, replacement unknown. [ca-0005]
- Weekly updates 19/26 Feb sent; 5 Mar still owed. [em-0008, em-0018, em-0019]

Personal: dentist moved to 17 Mar, no time/location [nt-0004]; 20 Feb buy-milk completion unknown [nt-0002].
