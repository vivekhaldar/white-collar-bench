# Mara Ilves — durable memory

**Current through 2027-03-02.** Inputs from all 13 supplied dates incorporated; no later events known. Today's **19 artifacts** preserved as sanitized text/DOCX extraction in `memory/sources/`; accidental smoke-test credential omitted.

Latest: Tinderbox tenant **`tinderbox-kes-01` live**, not pilot launch; claims patch still blocked. Mara **v2 spec due 4 Mar**, Dima API **10 Mar conditional on v2**. **PIA due 12 Mar** plus preceding walkthrough is a separate gate alongside security; security package remains **unfinished, unsent draft**. Kettleyard v4 planned **5 Mar**. Chargeback paper/rebase/review done: Mara C, Sade leans B, **no model chosen**. Beyond-Kestrow Tinderbox requires adopting campus chargeback agreement; **no written options to campuses before 12 Mar Council**; one-pager to Sade **10 Mar**. FY28 cost owner/funding line missing.

Saltmarren visit done, no records exported; step 6 and upstream advising waits identified, new data-look/use-case-list actions, DSA/baseline still blocked. Writing tool **RFQ required, requirements 9 Mar**; internal-build scorecard column owed, not Lionel estimate; budget ceiling confidential/value unknown. Mats **all scorecards in**, Sol starts two references **3 Mar**, no hire. **3 Mar offsite all day/no laptops**, bus **07:30**; Ramona covers standup/workshop, Bartosz/Ilya Kettleyard. Load test **3 Mar 10:00**, deck v2 still due **3 Mar noon** (worker plans early). Workshop 4 Mar: 57 registrations, captions/keynote recording arranged. MFA mandatory **15 Mar**, Mara enrollment unknown.

- [Current portfolio and operating rules](memory/PORTFOLIO.md)
- [Commitments, calendar and waiting-on list](memory/ACTIONS.md)
- [Tinderbox and Kettleyard: technical decisions, blockers, history](memory/PLATFORM.md)
- [Saltmarren: writing tool and transfer discovery](memory/SALTMARREN.md)
- [People and aliases](memory/PEOPLE.md)
- [Artifact catalog](memory/CATALOG.md) → durable sanitized source text, including PDF and workbook extractions.

## Answering from this memory
Use the latest dated evidence for current state; preserve older states as history, not simultaneous truths. Cite artifact IDs (e.g. [em-0013], [ch-0006]); consult `memory/sources/<ID>.txt` for exact wording. Distinguish agreed action from suggestion, reported receipt from actual attachment contents, planned event from completed event, and target date from guarantee. Unknown means unknown, not done. Automatic transcripts may contain errors. Calendar times are as supplied (floating local times in ICS; email/transcript metadata generally -08:00).

No credentials, passcodes or meeting join links are retained in the durable files. Mentioned but unsupplied attachments and external shared-drive/recruiting-system files cannot be reconstructed from references alone.
