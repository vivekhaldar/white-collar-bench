# Source catalog

Sanitized durable text/extractions. Cite bracketed artifact IDs. Calendar meeting links/passcodes removed. PDFs extracted as text; workbook values preserved. Missing attachments mentioned in emails are not assumed available. Dates and titles below are manifest metadata, not proof of completion. Sandbox login, temporary password and access URL in em-0022 omitted. dc-0006 preserves workbook formulas and labels derived totals separately.

## 2027-02-15

- **nt-0001** — note — 2027-02-15T08:05:00-08:00 — Portfolio map, spring half — [text](sources/nt-0001.txt)
- **em-0001** — email — 2027-02-15T09:32:00-08:00 — Spring priorities and how I'd like updates — [text](sources/em-0001.txt)
- **ch-0001** — chat — 2027-02-15T11:04:00-08:00 — #tinderbox-core: one-pager for ARB prep — [text](sources/ch-0001.txt)

## 2027-02-16

- **em-0002** — email — 2027-02-16T08:47:00-08:00 — Re: library research assistant — [text](sources/em-0002.txt)
- **em-0003** — email — 2027-02-16T10:18:00-08:00 — Tarrow: vendor security & accessibility questionnaire (writing feedback tool) — [text](sources/em-0003.txt)
- **ca-0001** — calendar — 2027-02-16T14:02:00-08:00 — Invite: Saltmarren site visit - transfer evaluation discovery — [text](sources/ca-0001.txt)
- **dc-0001** — document — 2027-02-16T17:20:00-08:00 — Tinderbox architecture one-pager v1 — [text](sources/dc-0001.txt) — parent em-0004
- **em-0004** — email — 2027-02-16T17:20:00-08:00 — Tinderbox architecture one-pager — [text](sources/em-0004.txt)

## 2027-02-17

- **mt-0001** — transcript — 2027-02-17T10:50:00-08:00 — Tinderbox scope meeting — [text](sources/mt-0001.txt)
- **ca-0002** — calendar — 2027-02-17T11:10:00-08:00 — Invite: Tinderbox daily standup (recurring) — [text](sources/ca-0002.txt)
- **mn-0001** — meeting_notes — 2027-02-17T16:30:00-08:00 — Debrief: phone screen with Mateus Okonedo — [text](sources/mn-0001.txt)

## 2027-02-18

- **em-0005** — email — 2027-02-18T10:30:00-08:00 — Panel for Mateus Okonedo: Mon 1 Mar 14:00-15:30 — [text](sources/em-0005.txt)
- **ch-0002** — chat — 2027-02-18T13:44:00-08:00 — #kettleyard: Tinderbox tenant request — [text](sources/ch-0002.txt)
- **dc-0002** — document — 2027-02-18T16:30:00-08:00 — FY27 campus FTE inputs v1 — [text](sources/dc-0002.txt) — parent em-0006
- **em-0006** — email — 2027-02-18T16:30:00-08:00 — FY27 FTE inputs for the cost model — [text](sources/em-0006.txt)

## 2027-02-19

- **mn-0002** — meeting_notes — 2027-02-19T11:40:00-08:00 — Workshop planning call - notes — [text](sources/mn-0002.txt)
- **em-0007** — email — 2027-02-19T13:15:00-08:00 — Registration open: Teaching with AI workshop, Thu 4 March — [text](sources/em-0007.txt)
- **em-0008** — email — 2027-02-19T16:40:00-08:00 — Weekly update: w/e 19 Feb — [text](sources/em-0008.txt)

## 2027-02-20

- **nt-0002** — note — 2027-02-20T10:20:00-08:00 — Sat note — [text](sources/nt-0002.txt)

## 2027-02-22

- **em-0009** — email — 2027-02-22T06:55:00-08:00 — Reminder: weekly VC updates due Friday 26 Feb — [text](sources/em-0009.txt)
- **dc-0003** — document — 2027-02-22T10:05:00-08:00 — Tinderbox LMS interface spec v1 — [text](sources/dc-0003.txt) — parent em-0010
- **em-0010** — email — 2027-02-22T10:05:00-08:00 — Tinderbox interface spec v1 — [text](sources/em-0010.txt)
- **dc-0004** — document — 2027-02-22T14:30:00-08:00 — Kettleyard Reference Architecture v3 — [text](sources/dc-0004.txt) — parent em-0011
- **em-0011** — email — 2027-02-22T14:30:00-08:00 — Kettleyard reference architecture v3: review please — [text](sources/em-0011.txt)
- **ch-0003** — chat — 2027-02-22T16:12:00-08:00 — #tinderbox-core: SSO app, context API date, option 1 pricing — [text](sources/ch-0003.txt)

## 2027-02-23

- **mt-0002** — transcript — 2027-02-23T11:55:00-08:00 — Scrivelo demo — [text](sources/mt-0002.txt)
- **ch-0004** — chat — 2027-02-23T15:20:00-08:00 — DM Ramona / Mara: room, catering, instructors — [text](sources/ch-0004.txt)

## 2027-02-24

- **em-0012** — email — 2027-02-24T11:40:00-08:00 — Scrivelo: completed questionnaire + pricing — [text](sources/em-0012.txt)
- **mt-0003** — transcript — 2027-02-24T13:45:00-08:00 — Tinderbox evaluation plan review — [text](sources/mt-0003.txt)
- **mn-0003** — meeting_notes — 2027-02-24T16:15:00-08:00 — Notes: shortlist call with Delphine — [text](sources/mn-0003.txt)

## 2027-02-25

- **em-0013** — email — 2027-02-25T10:02:00-08:00 — Re: Tinderbox - pausing real student data — [text](sources/em-0013.txt)
- **dc-0005** — document — 2027-02-25T15:45:00-08:00 — Teaching with AI - deck v1 — [text](sources/dc-0005.txt) — parent em-0014
- **em-0014** — email — 2027-02-25T15:45:00-08:00 — Workshop deck v1 — [text](sources/em-0014.txt)
- **ch-0005** — chat — 2027-02-25T16:44:00-08:00 — DM Bettina / Mara: support handoff — [text](sources/ch-0005.txt)
- **em-0015** — email — 2027-02-25T17:10:00-08:00 — Scrivelo DPA review + Saltmarren DSA — [text](sources/em-0015.txt)

## 2027-02-26

- **ch-0006** — chat — 2027-02-26T09:30:00-08:00 — #tinderbox-core: SSO claims, load test plan, runbook — [text](sources/ch-0006.txt)
- **em-0016** — email — 2027-02-26T11:15:00-08:00 — Transfer evaluation: current process map — [text](sources/em-0016.txt)
- **em-0017** — email — 2027-02-26T13:05:00-08:00 — Re: Scrivelo DPA review + Saltmarren DSA — [text](sources/em-0017.txt)
- **em-0018** — email — 2027-02-26T16:50:00-08:00 — Weekly update: w/e 26 Feb — [text](sources/em-0018.txt)
- **nt-0003** — note — 2027-02-26T17:30:00-08:00 — Fri wrap — [text](sources/nt-0003.txt)

## 2027-03-01

- **em-0019** — email — 06:58 -08:00 — Weekly VC update due 5 March — [text](sources/em-0019.txt)
- **em-0020** — newsletter — 07:12 -08:00 — Lattice Ledger: campus AI procurement; external commentary, not worker commitments or Tarrow policy — [text](sources/em-0020.txt)
- **nt-0004** — note — 07:40 -08:00 — Mon notes — [text](sources/nt-0004.txt)
- **mt-0004** — transcript — 09:45 -08:00 — Tinderbox standup: ARB rejects v1, shared hosting selected — [text](sources/mt-0004.txt)
- **em-0021** — email — 10:12 -08:00 — Mara's 11 Kettleyard v3 comments, request v4 — [text](sources/em-0021.txt)
- **mt-0005** — transcript — 11:50 -08:00 — Penmarq demo — [text](sources/mt-0005.txt)
- **mn-0004** — AI meeting recap — 12:02 -08:00 — Pen Mark demo; erroneous build-estimate action, use transcript — [text](sources/mn-0004.txt)
- **em-0022** — email — 13:24 -08:00 — Penmarq sandbox access + reported VSQ return; attachment unsupplied — [sanitized text](sources/em-0022.txt)
- **ca-0003** — calendar — 13:41 -08:00 — Chargeback review 2 Mar 16:00–16:30 — [sanitized text](sources/ca-0003.txt)
- **ca-0004** — calendar update, sequence 1 — 14:20 -08:00 — Delphine check-in moved to 4 Mar 11:00–11:30 — [sanitized text](sources/ca-0004.txt)
- **ch-0007** — chat — 15:32 -08:00 — Tenant ~80%, signing-cert blocked — [text](sources/ch-0007.txt)
- **mn-0005** — meeting notes — 15:40 -08:00 — Mats panel debrief; scorecards pending — [text](sources/mn-0005.txt)
- **ca-0005** — calendar cancellation, sequence 2 — 16:05 -08:00 — Cancels 4 Mar 15:00 Sade 1:1 occurrence, replacement unknown — [text](sources/ca-0005.txt)
- **em-0023** — automated ticket notification — 16:48 -08:00 — KSD-20931 Pending Vendor — [text](sources/em-0023.txt)
- **ch-0008** — chat — 17:35 -08:00 — Deck v2 due Wed noon; dashboard delivered — [text](sources/ch-0008.txt)
- **ch-0009** — chat — 18:24 -08:00 — Bart Ngata ownership concern; Mara to convene Sade/Bart — [text](sources/ch-0009.txt)
- **dc-0006** — workbook — 19:06 -08:00 — FY27 campus FTE inputs v2, supersedes v1; parent em-0024 — [extraction](sources/dc-0006.txt)
- **em-0024** — email — 19:06 -08:00 — Orrin Valley double-count corrected; rerun v1 models before Sade review — [text](sources/em-0024.txt)

## 2027-03-02

All 19 manifest artifacts preserved; times below received-at metadata (-08:00), not necessarily event times. DOCX extracted including tables (sequential text). ch-0012 accidental smoke-test credential removed; stated rotation intent retained, no proof completion. PIA questionnaire attachment, keynote slides, shared scheduling data and externally referenced invites not supplied.

- **em-0025** — email / IT all-staff notice — 06:30 — MFA mandatory 15 Mar, enrollment instructions/exemptions/help — [text](sources/em-0025.txt)
- **em-0026** — automated ATS email — 07:00 — Mara Mats scorecard pending at morning; superseded evening nt-0005 — [text](sources/em-0026.txt)
- **ch-0010** — chat — 07:45 — Delphine site-visit parking/front desk/10:00 confirmation — [text](sources/ch-0010.txt)
- **em-0027** — email — 08:05 — Hana introduction, PIA questionnaire 12 Mar + preceding 30-min walkthrough; separate privacy/security gates — [text](sources/em-0027.txt)
- **mt-0006** — transcript — 08:32 — ODS leads call; 3 Mar offsite/coverage/logistics, workshop readiness, v4 end-week, roadmap moved to 16 Mar; room account Lulu — [text](sources/mt-0006.txt)
- **ch-0011** — chat — 08:33 — Mara requests 45-min Sade/Bart Ngata ownership meeting, Lulu invite pending — [text](sources/ch-0011.txt)
- **mt-0007** — transcript — 09:35 — Tenant live, API 10 Mar conditional on v2, load test 3 Mar 10:00, onboarding 8–10 Mar, PIA 12 Mar; claims still blocked — [text](sources/mt-0007.txt)
- **mn-0006** — AI recap — 09:48 — Tinderbox standup; wrong Teo name and v3-comment send date, use transcript/em-0021 — [text](sources/mn-0006.txt)
- **em-0028** — email — 10:45 — Scrivelo ACR promise 5 Mar, API docs pending, proposed 5 Mar 11:00 implementation call (not accepted), webinar marketing — [text](sources/em-0028.txt)
- **ch-0012** — chat — 12:40 — Actual tenant tinderbox-kes-01 live, cert/provision done; v4 next; accidental credential omitted — [sanitized text](sources/ch-0012.txt)
- **mn-0007** — meeting notes — 12:45 — Completed Saltmarren site visit, step 6 corroborated, Tillie advising bottleneck/data-look promise, use-case-list action, unsigned DSA — [text](sources/mn-0007.txt)
- **ch-0013** — chat — 12:55 — Dima spec churn concerns, Mara promises stable event v2 Thu 4 Mar — [text](sources/ch-0013.txt)
- **em-0029** — email — 14:02 — Explicit correction of invented Lionel estimate; Mara internal-build scorecard column and named tier-2 requirement — [text](sources/em-0029.txt)
- **em-0030** — email — 14:36 — RFQ route required, requirements 9 Mar; market research valid, budget ceiling confidential/value unknown — [text](sources/em-0030.txt)
- **ch-0014** — chat — 15:31 — Cost-sharing paper delivered, A flat/B consumption/C hybrid on FTE v2, Mara recommends C; Sade 3 bullets/1 risk — [text](sources/ch-0014.txt)
- **dc-0007** — DOCX — 15:31 — Kettleyard cost-sharing options v1, internal draft, model shares/no prices; parent ch-0014 — [extraction](sources/dc-0007.txt)
- **mt-0008** — transcript — 16:40 — Chargeback review, recording starts 16:12 (first 12 min unavailable); Sade leans B/no selection, expansion conditional on chargeback, no campus written options, FY28 funding owner dependency, Sade one-pager 10 Mar; private target unstated — [text](sources/mt-0008.txt)
- **nt-0005** — worker note — 17:52 — Offsite delegation, all Mats scorecards in/Sol references start 3 Mar, security draft incomplete, deck early tomorrow plan — [text](sources/nt-0005.txt)
- **em-0031** — **unsent email draft** — 22:47 — X-Draft true, TODO package/subprocessor attachments, retention sentence unfinished; not submission — [text](sources/em-0031.txt)

