# People, roles, aliases and routing

Current through 2027-03-02. Names must not be merged just because aliases overlap.

## ODS / system office
| Person | Alias / role / relevance | Evidence |
|---|---|---|
| Mara Ilves | Worker; Principal Architect AI & Data, ODS; architecture lead Tinderbox, owner Saltmarren work/chargeback, workshop deck, MLE technical screens; no campus line authority | nt-0001 |
| Dr. Folasade Renwick | **Sade**; Vice Chancellor for Digital Strategy, Mara's boss; sponsor Tinderbox/Kettleyard/workshop/chargeback; **REQ-2207 hiring manager** | nt-0001, em-0001 |
| Ramona Szabo | **Ramona / Mona / @ramona**; Director of Programs; workshop owner, Tinderbox/chargeback programs, risk register request, MLE panel | nt-0001, ch-0004, nt-0003, em-0005 |
| Ilya Marchetti | Principal Architect Data Platform; **Kettleyard owner**, v3 review coordinator, MLE panel platform/serving/production ML | nt-0001, em-0011, em-0005 |
| Lucía Ferreyra | **Lulu**; Sade's ODS Executive Assistant/calendar owner, helps get Bart time; workshop registration form setup, chargeback review booking request | em-0001, mn-0002, nt-0003 |
| Bartosz Zielke | **@bart** in #kettleyard; ODS platform engineer, tenant provisioning and gateway on-call that rotation; **not Bart Ngata** | ch-0002, dc-0004 |
| Hyun-woo Park | **Hugo / @hpark**; Principal Security & Identity; v3 identity/vault/log review and Tinderbox security-review gate | em-0011, em-0013, ch-0006 |
| Bettina Oduya | Principal Product; v3 onboarding/service reviewer, Kettleyard catalog; insists named post-handoff writing-tool tier-2 support owner rather than ODS default | em-0011, ch-0005 |
| Percival Ndiaye | **Percy**; budget director/Director System Budget & Finance, chargeback FTE and forthcoming actuals | nt-0001, em-0006 |
| Marisol Etxeberria | **Sol**; Talent Partner/System HR, sources REQ-2207 and schedules panel; independent scorecard rules | nt-0001, em-0005 |
| Clement Oyelaran | Procurement Officer; **RFQ required**, requirements from Mara 9 Mar; boilerplate/issuance, budget ceiling confidential | em-0030 |
| Agnieszka Wolanin | **Aga** in worker notes; Associate General Counsel, Office of General Counsel; Scrivelo DPA and Saltmarren baseline DSA, retention/signature restrictions | em-0015, em-0017, nt-0003 |

`ODS Team` / `ods-team@tarrow.example` is a **shared monitored team mailbox, not a person** (registration and update reminders). [em-0007, em-0009]

## Kestrow
| Person | Alias / role / relevance | Evidence |
|---|---|---|
| Dr. Bartholomew Ngata | **Bart Ngata**; Kestrow CIO; route campus decisions through office, formal writing to full title/name. Not ODS engineer @bart | em-0001, em-0013 |
| Yusra Haddad | **@yusra**; Director Teaching & Learning Technology (TLT), Tinderbox campus lead/day-to-day, organizer standup | nt-0001, ca-0002, em-0013 |
| Joaquín Sepúlveda | **Jack / @jsep**; Enterprise Architect, ARB chair; hosting options/costing, GPU-capacity input, interface review | ch-0001, mt-0001, nt-0002, ch-0003 |
| Dmitri Halloran | **Dima / @dima**; Software Engineer Yusra's team, LMS/context API builder; **10 Mar conditional on v2**, old 5 Mar dead; Mara v2 promise 4 Mar | mt-0007, ch-0013 |
| Teodor Lisowski | **Teo / @teo**; Identity & Access Administrator, app registration and IdP claims/vendor patch KSD-20931 | em-0004, ch-0003, ch-0006 |
| Ingrid Solberg | Senior Instructional Designer; faculty onboarding/materials, capacity three courses; CHEM/HIST/BIOL booked 8/9/10 Mar, Library Room 2.14 | mt-0001, mt-0007 |
| Emeka Nwosu-Hart | Associate Professor Chemistry, **CHEM 110 instructor/faculty champion**, workshop enthusiast panelist; recruits HIST/BIOL, owes CHEM rubrics | mt-0001, mn-0002, mt-0003 |
| Prof. Constance Wilberforce | **Connie / Prof. Wilberforce**; Professor History; workshop skeptic panelist confirmed 24 Feb, evaluation-plan critic. **Not HIST 214 instructor** (a colleague teaches it) | mn-0002, mt-0003 |
| Saanvi Raghunathan | **@saanvi**; Kestrow SRE, Tinderbox load test owner, synthetic-data run 3 Mar 10:00 | ch-0006, mt-0007 |
| Margarethe Voss | **Greta / @greta**; Service Desk Lead, Tinderbox tier-1 runbook draft | ch-0006 |
| Hana Kobayashi-Reyes | Kestrow **Privacy Officer**, Office of Privacy and Records; joined last week, inherited Tinderbox PIA. Walkthrough before Mara questionnaire due 12 Mar, separate campus clearance in addition to security. **Not Hannah Feld** | em-0027 |

HIST 214 and BIOL 205 instructor names not supplied; Emeka reportedly secured both on 23 Feb. Do not invent names or substitute Connie. [ch-0004, mt-0003]

## Saltmarren, other campuses, external
| Person | Alias / role / relevance | Evidence |
|---|---|---|
| Delphine Arceneaux | **D.** in notes; Saltmarren interim registrar, sponsor WFT and transfer discovery; essay volumes/transcript sample | nt-0001, mn-0003, em-0017 |
| Rufus Adekunle | Saltmarren Transfer Credit Coordinator; process map, attended all 3 evaluator interviews on completed 2 Mar visit | ca-0001, em-0016, mn-0007 |
| Tillie | Saltmarren **advising operations lead**, surname unknown; joined last half-hour visit, reports ~3-week advising wait; Mara promised wait-time data look | mn-0007 |
| Lionel Mbatha | Saltmarren Director IT; vendor demos/LMS constraints, build-on-hub preference, campus support/integration | mt-0002 |
| Niall Fairbrother | Orrin Valley CIO; citation-checker idea/requirements pending; skeptical of chargeback | nt-0001 |
| Ramona Iturbe | **Ramona I.**; Brackwater Associate Dean Libraries, Library RA contact, park until mid-March earliest. **Not Ramona Szabo/Mona** | nt-0001, em-0002 |
| Gregor Lindahl | **Grig**; Scrivelo Learning Higher Ed AE, commercial/pricing/VSQ/references, compliance ACR coordination | em-0003, mt-0002, em-0012 |
| Hannah Feld | Scrivelo Solutions Engineer, demo/integration/API docs | mt-0002 |
| Juniper Hale | **Juni**; Penmarq (spoken **Pen Mark**) AE; pricing this week, legal no-training essays/comments follow-up | em-0003, mt-0005 |
| Callum Ferris | Penmarq Solutions Engineer; demos/integration, delivered sandbox access and reported VSQ; direct sandbox-issue contact | mt-0005, em-0022 |
| Corwin Bellamy-Tate | Saltmarren Writing Center director; Delphine asked him to attend evaluation from now on; tutor use/training, possible sandbox staff, capacity tight until after midterms | mt-0005 |
| Dr. Ines Vardakis | Senior Research Scientist Eskerfield Learning Research Institute; Mara contact, confirmed workshop keynote, evidence on AI feedback/learning | mn-0002, dc-0005 |
| Mateus Okonedo | **Mats**; Staff ML Engineer candidate REQ-2207, screen 17 Feb→panel completed 1 Mar, panel leans yes; all 3 scorecards in 2 Mar evening, Sol starts 2 reference checks 3 Mar, Sade decides afterward; not hired | mn-0001, em-0005, mn-0005, nt-0005 |

Transcript room account **KES-HUDDLE-2B** self-identifies as **Greta** on 1 Mar, not another attendee/person. Unnamed **Speaker 4** discusses load testing; likely Saanvi but unconfirmed. **Bart Z. / @bart** in ch-0007 is Bartosz Zielke; **Bart** in Yusra's ownership DM is Bart Ngata, as Mara explicitly names. [mt-0004, ch-0007, ch-0009]

**Huddlescribe / Huddlescribe Notetaker / Huddlescribe Recaps** is automated, not project owner; Lionel/Mara explicitly repudiate its invented build estimate. 2 Mar recap erroneously dates v3 comments Tuesday (sent Monday 1 Mar). [mt-0005, mn-0004, em-0029, mn-0006, em-0021]
**ODS-SMALL-CONF** in mt-0006 self-identifies as Lulu/Lucía; **Hyunwoo Parks** = Hyun-woo Park, **Betina O'Dwyer / Tina** = Bettina Oduya (transcription variants, not new people). **Teo Lisofsky** erroneous attendee name in mt-0007/mn-0006; speaking Teodor Lisowski and **Teo L (iPad)** switching devices are Teo. **ODS-CONF-4B** meeting room account, no identified speaking person. [mt-0006, mt-0007, mn-0006, mt-0008]
**TarrowRecruit Notifications** is automated ATS, pending reminder 2 Mar morning superseded by evening submitted note. **Tarrow IT Services** all-staff mailbox unmonitored (unlike ODS Team), MFA help to Services Desk. [em-0026, nt-0005, em-0025]
**kyd-ci / @kyd-ci** is channel automation, not person. Staging datasource rename by Bartosz was reverted/resolved 1 Mar, not an ongoing tenant blocker. [ch-0007]
**Kestrow Service Desk / noreply-servicedesk** is automated ticket notification, not Teo himself; Pending Vendor does not mean resolved. [em-0023]
**Lorne Castellan** is Lattice Ledger editor/newsletter sender, no project role/commitment known. Newsletter's procurement advice/survey/op-ed are external assertions, not Tarrow decisions, and do not override Sade's private-review-first instruction. [em-0020, em-0001]

Useful email identifiers retained in source email headers. Meeting joins and passcodes removed; do not reconstruct them.
