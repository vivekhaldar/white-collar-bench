# Commitments register — as of end of 2027-09-14

**Open** means acceptance/assignment evidenced, with no completion/cancellation in supplied inputs. It does not mean checked against external systems. **Requested/tentative** is not an obligation yet. Unspecified dates stay unspecified. Repeated recaps refer to the same work.

## Confirmed open — Amira

| Work | Recipient/collaborator | Accepted/assigned | Due | Evidence / latest state |
|---|---|---|---|---|
| Turn around Fulmar API contract v2 | Adwoa Kocak | 30 Aug | Not stated | Direct offer [mt-0001]; recaps [mn-0001, ch-0013, em-0024, mt-0005]; forwarded old ask [em-0061]; still 'on it' 10 Sep [ch-0060]. No delivered contract. |
| Complete Fulmar privacy impact assessment | Goran Liu | 1 Sep | **14 Sep** | Direct commitment and acknowledgment [ch-0018]. |
| Send Fulmar timeline | Adwoa Kocak | 3 Sep | Not stated | 'I'll send' [mt-0004]. Distinct from rollout checklist already sent. |
| Send operator AI basics workshop slides v2 | Wei Suwannarat | 2 Sep | Not stated | Assigned in cross-plant forum recap [mn-0003]. |
| Send Fulmar action log | Adwoa Kocak; **with Marcelo** | 8 Sep | Not stated | Direct promise [ch-0042, ch-0043]; recap [ch-0048]; worker todo [mn-0012]; reaffirmed 10 Sep [ch-0058]. |
| Scope two-week sprint on tooling wear | Morcliff context; recipient unspecified | 8 Sep | Not stated (two weeks is sprint duration) | Site-visit assignment [mn-0009]; separate-effort decision still pending [ch-0044]. |
| Review Marcelo's Fulmar data dictionary | Marcelo Meijer | 9 Sep | Not stated | Outgoing acceptance [em-0065]. |
| Send Wagtail status slide | Oksana Hoffmann | 9 Sep | Not stated | Direct promise [mt-0007]. Not Marcelo's delivered Fulmar slide. |
| Send Fulmar access request | Oksana Hoffmann | 13 Sep | Not stated | Outgoing 'On it, I'll send' [em-0079]. No delivery. |
| Walk through operator AI basics workshop room plan | Adwoa Kocak | 13 Sep | **15 Sep 14:00–14:30 UTC−06**, invited slot | Direct commitment [ch-0064], Amira-organized placeholder invite; agenda to follow, Adwoa response pending [ca-0009]. Not yet performed. |
| Review Ottavio's Fulmar vendor comparison | Ottavio Bakker | **10 Sep** | Not stated | Tentative 8 Sep [mn-0011] → worker 'yes to review' [nt-0004]. |
| Join panel on visual inspection | Ignacio Choi | 7 Sep | Event date unknown | Direct acceptance [ch-0038]. No event invite supplied. |
| Confirm Fulmar control plan | Adwoa Kocak | 14 Sep | Not stated | Direct 'I'll confirm', Adwoa thanks [mt-0013]. Not the completed test-plan confirmation. |
| Send work instructions selection lessons-learned note | Segun Okeke | **14 Sep 11:00:06** | Not stated | Email request [em-0082], DM 'no problem' [ch-0072] received 16:24. No delivery. Distinct from completed Fulmar lessons update. |

**Immediate dated watch:** Fulmar PIA due **today, 14 September**, no delivery shown; room-plan walkthrough invited for **tomorrow, 15 September**. Ottavio needs AI-use glossary **16 September**, but Amira has not clearly accepted this deadline [ch-0065]. Giorgi's SSO role mapping due **10 September**, now past due with no completion shown (not Amira-owned). Status notes w/e 3 and 10 September already sent; **w/e 17 September requested by end of day 17 September** to Hamish, half-page on moves/slips/leadership needs; extension available by reply. Reminder/recurring request, no new explicit acceptance or delivery. [ch-0018, em-0043, em-0042, em-0074, ca-0009, em-0075]

## Requested / offered / tentative — not yet confirmed

| Work | Proposed owner / requester | State and evidence |
|---|---|---|
| Assemble Fulmar security review package | Amira offered to group | 'I could ... if that's useful?' followed only by generic acknowledgments; no clear acceptance [mt-0003]. |
| Generate synthetic production data set for Fulmar | Oksana | 'Maybe I should' [mt-0003]; 3 Sep recap explicitly says whether Oksana picks it up still open, marks action suggested [mn-0004]. |
| Send Fulmar pilot charter | Thibault; Amira requested | Request only, no promise/delivery [ch-0023]. |
| Confirm work instructions selection decision memo | Amira; Segun requested | 'Good to know' not clear acceptance [ch-0031]. |
| Send AI-use endorsement paper to Hamish | Amira; Hamish via Adwoa | Explicitly 'not agreed yet' [ch-0026]. |
| Send AI-use decision memo to Wei | Amira; Wei via Zawadi | 'Maybe, need to see how the week goes' [ch-0032]. |
| Send operator AI basics workshop registration reminder | Adwoa Kocak, suggested by Kian | Explicitly 'not agreed though' [em-0057]. |
| Send warranty claims session notes | 'Adwoah' (likely Kocak), suggested by Amira | Explicitly 'nothing's agreed'; identity inference not firm from transcript alone [mt-0006]. |
| Review Adwoa safety reporting discovery stakeholder map | Amira, asked by Adwoa | 'Possibly. Can I get back to you on that?' [mt-0007]. |
| Update Fulmar dependency list after comments | Amira, asked by Adwoa | 9 Sep request; no Amira acceptance shown [ch-0052]. |
| Update Fulmar RACI chart after Adwoa Kocak comments | Amira | Worker 'maybe ... not committed yet' 10 Sep [nt-0004]. |
| Reference note for Tevita's predictive maintenance fellowship application | Amira, Tevita raised it | Suggested 10 Sep, reiterated in 14 Sep Wagtail review; uptake still open. Not part of predictive-input summary or an accepted Wagtail task [mn-0014, mn-0017]. |
| Review Adwoa's Fulmar stakeholder map | Amira, asked by Adwoa Kocak | 'maybe, need to see how the week goes' 13 Sep; not accepted. Separate from safety reporting map [ch-0062]. |
| Send AI-use glossary to Ottavio | Amira offered; Adwoa relays need | 13 Sep tentative offer for next week (20–26 Sep) [mt-0011]; 14 Sep Adwoa says Ottavio needs it **16 Sep**. Amira only 'good to know'/'thanks for flagging', no clear deadline acceptance or delivery [ch-0065]. |
| Friday status note w/e 17 Sep | Amira; MDO reminder, recipient Hamish | Recurring request due **EOD 17 Sep**; half-page enough; no explicit new acceptance/delivery [em-0075]. |
| Set up Wagtail staging access for Amira | Batbayar, Amira requested | 14 Sep request; 'following :)' not clear acceptance, no delivery/deadline [ch-0068]. Not Fulmar access request or Galix sandbox. |
| Send workshop attendee list to Adwoa | Amira suggested in 1:1 | **No owner agreed yet**, suggested 14 Sep, not accepted [mn-0016]. |

## Waiting on others — confirmed promises or worker's explicit waiting items

| Owner | Deliverable | Due / current state | Evidence |
|---|---|---|---|
| Giorgi Wisniewska **with Adwoa Kocak** | Fulmar single sign-on role mapping | **10 Sep**, past due as of 14 Sep; no completion/blocker supplied | Initial thanks for offer [ch-0010]; forwarded original promise specifies collaborator [em-0043]. |
| Adwoa Chukwu (Galix) | Galix deep-dive materials | No deadline; still no actual materials | Baseline [nt-0001]; direct offer [ch-0002]; forwarded promise through Kocak [em-0008]; recaps [ch-0011, ch-0024, mn-0004]. |
| Adwoa Kocak | AI-use lessons-learned note | No deadline/delivery | Promise [em-0018]. Not Amira's completed Fulmar lessons-learned update. |
| Kian Ishikawa | AI-use timeline | No deadline/delivery | Offer in forwarded email [em-0025]. |
| Kiran Merriweather | Wilhaven working paper | No deadline/delivery | Direct promise [em-0028]. Catch-up setup completion does not close paper. |
| Segun Okeke **with Giorgi** | Rosia accessibility conformance report | **Blocked: unsigned agreement**, no deadline or signer known | Promise [em-0051]; recap [em-0059]; blocker [ch-0054]. |
| Adwoa Kocak | Fulmar acceptance criteria | No deadline/delivery | Forwarded offer [em-0055]. |
| Marcelo Meijer | Fulmar architecture diagram | No deadline/delivery | Worker notes [mn-0010]. Distinct from Amira's delivered data-flow diagram. |
| Oksana Hoffmann | Fulmar comms plan | No deadline/delivery | Direct promise, accepted with thanks, 13 Sep [mt-0010, mn-0015]. |
| Adwoa Kocak | Operator AI basics workshop refreshments | No deadline/completion | 'yep, on it' 13 Sep [ch-0063]; 14 Sep forward of 13 Sep promise to Wei [em-0086]. Not completion/new task or registration reminder. |
| Adwoa Kocak | Summarize predictive maintenance input for Hamish | **Handed off 13 Sep**, no deadline/delivery; explicit recipient acceptance not shown | Amira announced Adwoa will take it from here [mt-0012], previous Amira acceptance [ch-0056]; Alan corroborates transfer 14 Sep [ch-0067]. |
| Tane Haugen | Tooling wear wait-time export | No deadline/delivery | Adwoa relays sync promise [ch-0057]. |
| Adwoa Kocak | AI-use comment log | No deadline/delivery | Direct promise [mt-0009], recap [mn-0013]. |
| Adwoa Kocak | Fulmar service blueprint | No deadline/delivery | Direct acceptance [mt-0008], transcript spelling 'Adwoah'. |
| Kian Ishikawa | Sandfield changeover planning problem statement | Long-running; no deadline/delivery | [nt-0001]. |
| Rodrigo Oduro | Falhaven shift handover problem statement | Long-running; no deadline/delivery | [nt-0001]. |

### Reported delivered but contents unavailable

- **Tane current safety reporting process map:** promised via Adwoa 31 August [ch-0012, em-0030]; Adwoa reports 'looks like Tane sent you' 7 September [em-0053]. Treat as reported delivered, not firm firsthand receipt. No map content or exact delivery date available. Do not keep it as an unqualified open promise.

## Completed — retain history, do not re-open from old recaps

| Work | Owner → recipient | Completion | Evidence / limits |
|---|---|---|---|
| AI-use risk taxonomy | Amira → Adwoa Kocak | **31 Aug 09:07** | Outgoing 'Here's ... as promised' [em-0010]. Later 17:34 worker todo [nt-0003] conflicts; delivery wins, no new version requested. Actual taxonomy content absent. |
| Fulmar load test plan draft | Ottavio (with Batbayar) | **1 Sep** | Promise [em-0015, ch-0016], direct 'drafted ... earlier today' [ch-0017]. Drafting done, not proof testing performed or plan approved; plan content absent. |
| Fulmar data-flow diagram | Amira → Marcelo | By **3 Sep morning** | Direct 'I sent' at standup [mt-0004], closing request [em-0027]. Diagram itself absent. |
| Fulmar lessons-learned note after Adwoa comments | Amira → Adwoa; latest attached to Hamish status | **2 Sep**, v3 received **10 Sep** | Promise [ch-0022], delivery with v2 [em-0033, dc-0001], acknowledgment [em-0035], confirmations [mn-0006, mt-0005, mn-0012], latest [em-0074, dc-0004]. Updated note still has open questions; update commitment complete. |
| Fulmar rollout checklist | Amira → Adwoa | **3 Sep 13:53** | Promise [mt-0004], outgoing draft [em-0041, dc-0002]. Checklist items not all closed. |
| Friday status note w/e 3 Sep | Amira → Hamish | **3 Sep 17:07**, on due date | Accepted [ch-0003], reminders [em-0001, ch-0008, ch-0019], outgoing [em-0042], worker confirmation [mn-0008]. |
| Fulmar requirements matrix review | Amira → Adwoa | **6 Sep 13:05** | Same-day acceptance [em-0045] and direct completion [ch-0033]. No review comments supplied. |
| Fulmar status slide v2 | Marcelo → Amira | **6 Sep 10:55** | Promise [ch-0027], delivery [em-0047, dc-0003]. |
| AI-use consultation plan | Amira → Kian | **6 Sep 11:39** | Request [ch-0029], direct completion + 'perfect' [ch-0030]. Actual plan content absent. |
| Coffee about visual inspection setup | Amira → Adwoa | **7 Sep** | Worker todo [mn-0007], direct setup confirmation [ch-0039]. Coffee date/attendance unknown. |
| Wilhaven catch-up setup | Amira with Kiran | **8 Sep**, ahead of **17 Sep setup deadline** | Accepted request [ch-0036], direct completion [ch-0046]. Event date/time unknown. |
| Wagtail cutover plan review | Amira → Batbayar | **9 Sep 08:06** | Third-party assignment [ch-0040]; outgoing completion [em-0066]. Actual plan/comments absent. |
| Fulmar test plan confirmation | Amira with Marcelo | **9 Sep 09:20** | Accepted [ch-0045], direct completion + 'perfect' [ch-0051], Batbayar corroboration [ch-0053], 10 Sep status [em-0074]. Do not conflate with load-test drafting. |
| Friday status note w/e 10 Sep | Amira → Hamish | **10 Sep 16:46**, on due date | Reminder [em-0044]; outgoing status [em-0074]. |
| Look into Fulmar export failures | Amira → Batbayar | **14 Sep 12:17** | Took issue at standup [mt-0013], outgoing 'I looked into' [em-0085]. Investigation done; **does not establish fixed/resolved**. |
| Fix Wagtail export failures | Batbayar → Amira | **14 Sep**, reported 16:12 | Promise 14:09 [ch-0070], direct 'I fixed ... earlier today' [ch-0073]. Separate from Fulmar investigation; no validation details. |
| Wagtail Operating Model Review | Oksana owner | **14 Sep**, reported done | Oksana says review done at Fulmar standup [mt-0013]. Completion reported, no output/specific approval supplied. |

### Investigated — resolution unknown

- **Fulmar export failures:** Amira takes the issue at standup [mt-0013] and reports she looked into it to Batbayar [em-0085]. Investigation complete; no explicit Fulmar fix, remaining remedial action or owner supplied. Do not use Batbayar's **Wagtail** fix [ch-0073] to close Fulmar failures.

## Handed off — not completed

- **Predictive maintenance input summary for Hamish:** Amira's 9 September commitment [ch-0056] handed to **Adwoa Kocak** in 13 September leads call [mt-0012]. Not an open Amira task or completed summary; Alan corroborates transfer 14 September [ch-0067]; explicit Adwoa acceptance/delivery not captured. Fellowship reference remains a separate tentative request, reiterated 14 September [mn-0017].

## Cancelled / superseded

- **AI-use principles draft:** worker explicitly drops 13 September, superseded by **approach C glossary decision** [nt-0005]. Closes waiting item [mn-0011], not evidence draft delivered or framework endorsed.

- **Wagtail model allow-list review:** unaccepted request [em-0006, nt-0002] → Amira explicitly drops it **1 September**, duplicate of another ask [em-0023]. No review owed and no completion claimed.
- **Wagtail vault-secrets rotation:** Batbayar accepted 6 September [mn-0005] → handed to platform lead 8 September [ch-0050] → no longer needed/overtaken by events 10 September [mt-0008]. Final status cancelled/superseded, not rotated. Handoff owner's acceptance not established.
- **Fulmar standup instances 2 and 7 September:** cancelled in calendar; not cancellation of series/project. [ca-0003, ca-0004]
