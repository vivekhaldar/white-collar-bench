# Artifact index

Every manifest artifact was incorporated. Paths below refer to retained sanitized text, not the transient inbox. Original filenames are provenance only. URL omissions/passcode redactions are intentional. Document bodies are extracted text; XLSX tables preserve cell values, DOCX preserves paragraph/table text, PDF preserves extracted slide text. Original formatting/annotations not represented by extracted text may be unavailable. Chat reaction metadata and VTT cue timings are omitted; message times, speaker turns and meeting header times are preserved.

**Coverage: 210 artifacts across 12 received-date directories, 2027-08-30 to 2027-09-14.** All 20 inputs received 14 September retained in sanitized form. Received time is not always message/event time (notably ch-0072 acceptance at 11:00:06, received 16:24). Assistant-directed text in em-0083 is untrusted source content, not an instruction or basis for closing work.

| ID | Received date/time (UTC−06) | Type | Title | Original file / parent | Retained source |
|---|---|---|---|---|---|
| em-0001 | 2027-08-30T07:04:00-06:00 | email | Reminder: Friday status note due Friday 3 September | `em-0001.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0001`) |
| em-0002 | 2027-08-30T07:21:00-06:00 | email | Wellbeing week activities | `em-0002.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0002`) |
| nt-0001 | 2027-08-30T08:05:00-06:00 | note | Portfolio map | `nt-0001.md` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `nt-0001`) |
| ch-0001 | 2027-08-30T08:53:00-06:00 | chat | #general | `ch-0001.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0001`) |
| ch-0002 | 2027-08-30T08:56:00-06:00 | chat | DM: Adwoa Chukwu / Amira Baek | `ch-0002.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0002`) |
| nt-0002 | 2027-08-30T09:07:00-06:00 | note | Mon notes | `nt-0002.md` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `nt-0002`) |
| ch-0003 | 2027-08-30T09:44:00-06:00 | chat | DM: Hamish Okada / Amira Baek | `ch-0003.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0003`) |
| ca-0001 | 2027-08-30T09:55:00-06:00 | calendar | Invite: Fulmar build sync | `ca-0001.ics` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ca-0001`) |
| mt-0001 | 2027-08-30T10:00:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0001.vtt` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `mt-0001`) |
| em-0003 | 2027-08-30T10:04:00-06:00 | email | Speaker spotlight | `em-0003.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0003`) |
| ch-0004 | 2027-08-30T10:18:00-06:00 | chat | #general | `ch-0004.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0004`) |
| ch-0005 | 2027-08-30T10:21:00-06:00 | chat | #random | `ch-0005.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0005`) |
| em-0004 | 2027-08-30T10:53:00-06:00 | email | Re: FYI: Fulmar API contract v2 | `em-0004.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0004`) |
| em-0005 | 2027-08-30T10:57:00-06:00 | email | Room booking confirmation | `em-0005.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0005`) |
| em-0006 | 2027-08-30T12:56:00-06:00 | email | FYI: Wagtail model allow-list | `em-0006.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0006`) |
| ch-0006 | 2027-08-30T12:57:00-06:00 | chat | #random | `ch-0006.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0006`) |
| em-0007 | 2027-08-30T14:18:00-06:00 | email | [INC-51157] Ticket updated | `em-0007.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0007`) |
| ch-0007 | 2027-08-30T16:14:00-06:00 | chat | DM: Ottavio Bakker / Amira Baek | `ch-0007.json` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ch-0007`) |
| mt-0002 | 2027-08-30T16:45:00-06:00 | transcript | Catch-up: Amira / Baraka (transcript) | `mt-0002.vtt` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `mt-0002`) |
| ca-0002 | 2027-08-30T17:10:00-06:00 | calendar | Invite: Catch-up: Amira / Vitoria | `ca-0002.ics` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `ca-0002`) |
| em-0008 | 2027-08-30T17:33:00-06:00 | email | Fwd: Galix deep-dive materials | `em-0008.eml` | [sources/2027-08-30.md](sources/2027-08-30.md) (heading `em-0008`) |
| em-0009 | 2027-08-31T08:22:00-06:00 | email | All-staff: building access changes | `em-0009.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0009`) |
| em-0010 | 2027-08-31T09:07:00-06:00 | email | AI-use risk taxonomy | `em-0010.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0010`) |
| ch-0008 | 2027-08-31T09:31:00-06:00 | chat | DM: Hamish Okada / Amira Baek | `ch-0008.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0008`) |
| mn-0001 | 2027-08-31T10:00:00-06:00 | meeting_notes | Recap: Fulmar standup | `mn-0001.md` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `mn-0001`) |
| ch-0009 | 2027-08-31T10:35:00-06:00 | chat | #general | `ch-0009.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0009`) |
| ch-0010 | 2027-08-31T10:59:00-06:00 | chat | #fulmar-core | `ch-0010.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0010`) |
| em-0011 | 2027-08-31T11:28:00-06:00 | email | [Resolved] Elevated latency on file storage | `em-0011.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0011`) |
| ch-0011 | 2027-08-31T13:25:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0011.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0011`) |
| em-0012 | 2027-08-31T13:59:00-06:00 | email | Parking lot resurfacing | `em-0012.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0012`) |
| ch-0012 | 2027-08-31T14:15:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0012.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0012`) |
| ch-0013 | 2027-08-31T14:35:00-06:00 | chat | #fulmar-core | `ch-0013.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0013`) |
| ch-0014 | 2027-08-31T14:39:00-06:00 | chat | #random | `ch-0014.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0014`) |
| ch-0015 | 2027-08-31T14:59:00-06:00 | chat | #random | `ch-0015.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0015`) |
| em-0013 | 2027-08-31T15:49:00-06:00 | email | Scheduled maintenance this weekend | `em-0013.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0013`) |
| em-0014 | 2027-08-31T16:30:00-06:00 | email | Reminder: all-staff meeting Thursday | `em-0014.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0014`) |
| em-0015 | 2027-08-31T17:31:00-06:00 | email | Re: Fulmar load test plan | `em-0015.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0015`) |
| nt-0003 | 2027-08-31T17:34:00-06:00 | note | Tue notes | `nt-0003.md` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `nt-0003`) |
| em-0016 | 2027-08-31T18:30:00-06:00 | email | Open enrollment reminder | `em-0016.eml` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `em-0016`) |
| ch-0016 | 2027-08-31T18:52:00-06:00 | chat | #fulmar-core | `ch-0016.json` | [sources/2027-08-31.md](sources/2027-08-31.md) (heading `ch-0016`) |
| em-0017 | 2027-09-01T07:17:00-06:00 | email | [Investigating] Intermittent sign-in delays | `em-0017.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0017`) |
| mt-0003 | 2027-09-01T09:55:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0003.vtt` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `mt-0003`) |
| em-0018 | 2027-09-01T09:58:00-06:00 | email | Re: AI-use lessons-learned note | `em-0018.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0018`) |
| ch-0017 | 2027-09-01T11:06:00-06:00 | chat | #fulmar-core | `ch-0017.json` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `ch-0017`) |
| ch-0018 | 2027-09-01T12:25:00-06:00 | chat | DM: Amira Baek / Goran Liu | `ch-0018.json` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `ch-0018`) |
| em-0019 | 2027-09-01T13:08:00-06:00 | email | [Scheduled] Network maintenance window | `em-0019.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0019`) |
| em-0020 | 2027-09-01T13:42:00-06:00 | email | Your benefits statement is ready | `em-0020.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0020`) |
| ch-0019 | 2027-09-01T13:44:00-06:00 | chat | DM: Hamish Okada / Amira Baek | `ch-0019.json` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `ch-0019`) |
| em-0021 | 2027-09-01T14:16:00-06:00 | email | Iselmoor Responsible AI Use Framework: moving to endorsement | `em-0021.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0021`) |
| mn-0002 | 2027-09-01T15:30:00-06:00 | meeting_notes | Recap: Catch-up: Amira / Vitoria | `mn-0002.md` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `mn-0002`) |
| em-0022 | 2027-09-01T16:21:00-06:00 | email | Industrial Data Digest: issue 35 | `em-0022.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0022`) |
| em-0023 | 2027-09-01T16:55:00-06:00 | email | Re: Wagtail model allow-list | `em-0023.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0023`) |
| em-0024 | 2027-09-01T17:12:00-06:00 | email | Re: FYI: Fulmar API contract v2 | `em-0024.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0024`) |
| em-0025 | 2027-09-01T18:30:00-06:00 | email | Fwd: AI-use timeline | `em-0025.eml` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `em-0025`) |
| ch-0020 | 2027-09-01T18:51:00-06:00 | chat | DM: Ottavio Bakker / Amira Baek | `ch-0020.json` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `ch-0020`) |
| ch-0021 | 2027-09-01T18:53:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0021.json` | [sources/2027-09-01.md](sources/2027-09-01.md) (heading `ch-0021`) |
| ca-0003 | 2027-09-02T07:54:00-06:00 | calendar | Cancelled: Fulmar standup | `ca-0003.ics` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `ca-0003`) |
| em-0026 | 2027-09-02T08:33:00-06:00 | email | [REQ-19167] Request resolved | `em-0026.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0026`) |
| em-0027 | 2027-09-02T08:58:00-06:00 | email | Re: Fulmar data-flow diagram | `em-0027.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0027`) |
| ch-0022 | 2027-09-02T09:54:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0022.json` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `ch-0022`) |
| em-0028 | 2027-09-02T11:11:00-06:00 | email | Re: Wilhaven working paper | `em-0028.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0028`) |
| em-0029 | 2027-09-02T12:13:00-06:00 | email | [INC-45928] Ticket updated | `em-0029.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0029`) |
| ch-0023 | 2027-09-02T12:29:00-06:00 | chat | #fulmar-core | `ch-0023.json` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `ch-0023`) |
| em-0030 | 2027-09-02T12:36:00-06:00 | email | Fwd: Current safety reporting process map | `em-0030.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0030`) |
| ch-0024 | 2027-09-02T12:51:00-06:00 | chat | DM: Adwoa Chukwu / Amira Baek | `ch-0024.json` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `ch-0024`) |
| mn-0003 | 2027-09-02T14:00:00-06:00 | meeting_notes | Recap: Cross-plant AI forum | `mn-0003.md` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `mn-0003`) |
| em-0031 | 2027-09-02T14:11:00-06:00 | email | [INC-46909] Ticket updated | `em-0031.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0031`) |
| ch-0025 | 2027-09-02T14:14:00-06:00 | chat | #general | `ch-0025.json` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `ch-0025`) |
| em-0032 | 2027-09-02T16:46:00-06:00 | email | Catering menu for next month | `em-0032.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0032`) |
| dc-0001 | 2027-09-02T18:08:00-06:00 | document | Fulmar lessons-learned note after Adwoa's comments v2 | `dc-0001.docx`; parent em-0033 | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `dc-0001`) |
| em-0033 | 2027-09-02T18:08:00-06:00 | email | Fulmar lessons-learned note after Adwoa's comments | `em-0033.eml` | [sources/2027-09-02.md](sources/2027-09-02.md) (heading `em-0033`) |
| em-0034 | 2027-09-03T06:36:00-06:00 | email | [REQ-36368] Request resolved | `em-0034.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0034`) |
| mt-0004 | 2027-09-03T09:55:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0004.vtt` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `mt-0004`) |
| em-0035 | 2027-09-03T10:33:00-06:00 | email | Re: FYI: Fulmar lessons-learned note after Adwoa's comments | `em-0035.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0035`) |
| em-0036 | 2027-09-03T10:48:00-06:00 | email | Room booking confirmation | `em-0036.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0036`) |
| em-0037 | 2027-09-03T11:19:00-06:00 | email | [INC-64319] Ticket updated | `em-0037.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0037`) |
| em-0038 | 2027-09-03T12:09:00-06:00 | email | Wellness credit deadline | `em-0038.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0038`) |
| em-0039 | 2027-09-03T12:12:00-06:00 | email | Re: Wagtail update | `em-0039.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0039`) |
| em-0040 | 2027-09-03T12:40:00-06:00 | email | [INC-56346] Ticket updated | `em-0040.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0040`) |
| dc-0002 | 2027-09-03T13:53:00-06:00 | document | Fulmar rollout checklist (draft) | `dc-0002.xlsx`; parent em-0041 | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `dc-0002`) |
| em-0041 | 2027-09-03T13:53:00-06:00 | email | Fulmar rollout checklist | `em-0041.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0041`) |
| mn-0004 | 2027-09-03T14:15:00-06:00 | meeting_notes | Recap: Office hours with Thibault | `mn-0004.md` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `mn-0004`) |
| ch-0026 | 2027-09-03T15:04:00-06:00 | chat | #ai-use-core | `ch-0026.json` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `ch-0026`) |
| em-0042 | 2027-09-03T17:07:00-06:00 | email | Status note: w/e 3 September | `em-0042.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0042`) |
| em-0043 | 2027-09-03T18:28:00-06:00 | email | Fwd: Fulmar single sign-on role mapping | `em-0043.eml` | [sources/2027-09-03.md](sources/2027-09-03.md) (heading `em-0043`) |
| em-0044 | 2027-09-06T06:56:00-06:00 | email | Reminder: Friday status note due Friday 10 September | `em-0044.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0044`) |
| em-0045 | 2027-09-06T08:06:00-06:00 | email | Adwoa's Fulmar requirements matrix | `em-0045.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0045`) |
| mn-0005 | 2027-09-06T09:55:00-06:00 | meeting_notes | Recap: Fulmar standup | `mn-0005.md` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `mn-0005`) |
| em-0046 | 2027-09-06T10:10:00-06:00 | email | Speaker spotlight | `em-0046.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0046`) |
| ch-0027 | 2027-09-06T10:37:00-06:00 | chat | DM: Marcelo Meijer / Amira Baek | `ch-0027.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0027`) |
| ch-0028 | 2027-09-06T10:50:00-06:00 | chat | DM: Tane Haugen / Amira Baek | `ch-0028.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0028`) |
| dc-0003 | 2027-09-06T10:55:00-06:00 | document | Fulmar status slide v2 | `dc-0003.pdf`; parent em-0047 | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `dc-0003`) |
| em-0047 | 2027-09-06T10:55:00-06:00 | email | Fulmar status slide | `em-0047.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0047`) |
| em-0048 | 2027-09-06T11:21:00-06:00 | email | Event space survey | `em-0048.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0048`) |
| mn-0006 | 2027-09-06T11:30:00-06:00 | meeting_notes | Recap: Fulmar security review | `mn-0006.md` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `mn-0006`) |
| mn-0007 | 2027-09-06T11:45:00-06:00 | meeting_notes | Notes: MDO leads call | `mn-0007.md` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `mn-0007`) |
| ch-0029 | 2027-09-06T11:50:00-06:00 | chat | DM: Kian Ishikawa / Amira Baek | `ch-0029.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0029`) |
| ch-0030 | 2027-09-06T12:00:00-06:00 | chat | DM: Amira Baek / Kian Ishikawa | `ch-0030.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0030`) |
| mn-0008 | 2027-09-06T12:00:00-06:00 | meeting_notes | Notes: Rosia intro call | `mn-0008.md` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `mn-0008`) |
| ch-0031 | 2027-09-06T12:13:00-06:00 | chat | #work-instructions-core | `ch-0031.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0031`) |
| ch-0032 | 2027-09-06T12:40:00-06:00 | chat | DM: Zawadi Quintero / Amira Baek | `ch-0032.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0032`) |
| ch-0033 | 2027-09-06T13:26:00-06:00 | chat | #fulmar-core | `ch-0033.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0033`) |
| ch-0034 | 2027-09-06T16:00:00-06:00 | chat | DM: Oksana Hoffmann / Amira Baek | `ch-0034.json` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `ch-0034`) |
| mt-0005 | 2027-09-06T16:30:00-06:00 | transcript | Fulmar security review (transcript) | `mt-0005.vtt` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `mt-0005`) |
| em-0049 | 2027-09-06T18:24:00-06:00 | email | Reminder: all-staff meeting Thursday | `em-0049.eml` | [sources/2027-09-06.md](sources/2027-09-06.md) (heading `em-0049`) |
| em-0050 | 2027-09-07T06:54:00-06:00 | email | Room booking confirmation | `em-0050.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0050`) |
| em-0051 | 2027-09-07T08:29:00-06:00 | email | Re: Rosia accessibility conformance report | `em-0051.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0051`) |
| ca-0004 | 2027-09-07T08:47:00-06:00 | calendar | Cancelled: Fulmar standup | `ca-0004.ics` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ca-0004`) |
| em-0052 | 2027-09-07T10:19:00-06:00 | email | Industrial Data Digest: issue 36 | `em-0052.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0052`) |
| ch-0035 | 2027-09-07T11:42:00-06:00 | chat | #general | `ch-0035.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0035`) |
| em-0053 | 2027-09-07T11:46:00-06:00 | email | Re: Current safety reporting process map | `em-0053.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0053`) |
| ch-0036 | 2027-09-07T12:01:00-06:00 | chat | DM: Kiran Merriweather / Amira Baek | `ch-0036.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0036`) |
| em-0054 | 2027-09-07T12:02:00-06:00 | email | Room booking confirmation | `em-0054.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0054`) |
| em-0055 | 2027-09-07T12:08:00-06:00 | email | Fwd: Fulmar acceptance criteria | `em-0055.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0055`) |
| ch-0037 | 2027-09-07T12:11:00-06:00 | chat | #general | `ch-0037.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0037`) |
| em-0056 | 2027-09-07T12:19:00-06:00 | email | Room booking confirmation | `em-0056.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0056`) |
| ch-0038 | 2027-09-07T13:19:00-06:00 | chat | DM: Amira Baek / Ignacio Choi | `ch-0038.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0038`) |
| ch-0039 | 2027-09-07T13:50:00-06:00 | chat | DM: Amira Baek / Adwoa Kocak | `ch-0039.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0039`) |
| em-0057 | 2027-09-07T14:01:00-06:00 | email | Re: Operator AI basics workshop registration reminder | `em-0057.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0057`) |
| ca-0005 | 2027-09-07T14:39:00-06:00 | calendar | Invite: Catch-up: Amira / Marcelo | `ca-0005.ics` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ca-0005`) |
| ch-0040 | 2027-09-07T15:27:00-06:00 | chat | #wagtail-core | `ch-0040.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0040`) |
| ch-0041 | 2027-09-07T15:38:00-06:00 | chat | #coffee | `ch-0041.json` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `ch-0041`) |
| mt-0006 | 2027-09-07T16:00:00-06:00 | transcript | Sandfield relationship check-in (transcript) | `mt-0006.vtt` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `mt-0006`) |
| em-0058 | 2027-09-07T18:31:00-06:00 | email | Open enrollment reminder | `em-0058.eml` | [sources/2027-09-07.md](sources/2027-09-07.md) (heading `em-0058`) |
| ch-0042 | 2027-09-08T07:49:00-06:00 | chat | #fulmar-core | `ch-0042.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0042`) |
| ch-0043 | 2027-09-08T10:17:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0043.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0043`) |
| mn-0009 | 2027-09-08T10:30:00-06:00 | meeting_notes | Recap: Morcliff site visit | `mn-0009.md` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `mn-0009`) |
| em-0059 | 2027-09-08T10:50:00-06:00 | email | Re: FYI: Rosia accessibility conformance report | `em-0059.eml` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `em-0059`) |
| em-0060 | 2027-09-08T12:47:00-06:00 | email | Scheduled maintenance this weekend | `em-0060.eml` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `em-0060`) |
| ch-0044 | 2027-09-08T13:20:00-06:00 | chat | #safety-reporting-discovery-core | `ch-0044.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0044`) |
| ch-0045 | 2027-09-08T13:47:00-06:00 | chat | DM: Amira Baek / Marcelo Meijer | `ch-0045.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0045`) |
| ch-0046 | 2027-09-08T13:56:00-06:00 | chat | DM: Amira Baek / Kiran Merriweather | `ch-0046.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0046`) |
| mn-0010 | 2027-09-08T14:00:00-06:00 | meeting_notes | Notes: Catch-up: Amira / Marcelo | `mn-0010.md` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `mn-0010`) |
| em-0061 | 2027-09-08T14:24:00-06:00 | email | Fwd: Fulmar API contract v2 | `em-0061.eml` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `em-0061`) |
| mn-0011 | 2027-09-08T14:35:00-06:00 | meeting_notes | Notes: Wagtail platform sync | `mn-0011.md` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `mn-0011`) |
| em-0062 | 2027-09-08T14:52:00-06:00 | email | Room booking confirmation | `em-0062.eml` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `em-0062`) |
| ch-0047 | 2027-09-08T15:04:00-06:00 | chat | #general | `ch-0047.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0047`) |
| em-0063 | 2027-09-08T16:19:00-06:00 | email | [Scheduled] Network maintenance window | `em-0063.eml` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `em-0063`) |
| ch-0048 | 2027-09-08T16:31:00-06:00 | chat | #fulmar-core | `ch-0048.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0048`) |
| ch-0049 | 2027-09-08T17:31:00-06:00 | chat | #random | `ch-0049.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0049`) |
| ch-0050 | 2027-09-08T18:30:00-06:00 | chat | #wagtail-core | `ch-0050.json` | [sources/2027-09-08.md](sources/2027-09-08.md) (heading `ch-0050`) |
| em-0064 | 2027-09-09T06:36:00-06:00 | email | Room booking confirmation | `em-0064.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0064`) |
| em-0065 | 2027-09-09T07:53:00-06:00 | email | Re: Marcelo's Fulmar data dictionary | `em-0065.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0065`) |
| em-0066 | 2027-09-09T08:06:00-06:00 | email | Re: Batbayar's Wagtail cutover plan | `em-0066.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0066`) |
| em-0067 | 2027-09-09T08:27:00-06:00 | email | [Investigating] Intermittent sign-in delays | `em-0067.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0067`) |
| ch-0051 | 2027-09-09T09:49:00-06:00 | chat | DM: Amira Baek / Marcelo Meijer | `ch-0051.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0051`) |
| mt-0007 | 2027-09-09T09:55:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0007.vtt` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `mt-0007`) |
| ch-0052 | 2027-09-09T10:13:00-06:00 | chat | #fulmar-core | `ch-0052.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0052`) |
| mn-0012 | 2027-09-09T10:15:00-06:00 | meeting_notes | Notes: Fulmar security review | `mn-0012.md` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `mn-0012`) |
| ch-0053 | 2027-09-09T10:44:00-06:00 | chat | DM: Batbayar Galbraith / Amira Baek | `ch-0053.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0053`) |
| ca-0006 | 2027-09-09T11:29:00-06:00 | calendar | Invite: Catch-up: Amira / Adwoa | `ca-0006.ics` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ca-0006`) |
| ch-0054 | 2027-09-09T13:09:00-06:00 | chat | #work-instructions-core | `ch-0054.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0054`) |
| em-0068 | 2027-09-09T13:19:00-06:00 | email | Room booking confirmation | `em-0068.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0068`) |
| ch-0055 | 2027-09-09T14:38:00-06:00 | chat | #general | `ch-0055.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0055`) |
| ch-0056 | 2027-09-09T14:41:00-06:00 | chat | DM: Hamish Okada / Amira Baek | `ch-0056.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0056`) |
| em-0069 | 2027-09-09T15:04:00-06:00 | email | [INC-78782] Ticket updated | `em-0069.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0069`) |
| ch-0057 | 2027-09-09T16:38:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0057.json` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `ch-0057`) |
| em-0070 | 2027-09-09T18:11:00-06:00 | email | Call for proposals closes Wednesday 22 September | `em-0070.eml` | [sources/2027-09-09.md](sources/2027-09-09.md) (heading `em-0070`) |
| ch-0058 | 2027-09-10T09:33:00-06:00 | chat | DM: Marcelo Meijer / Amira Baek | `ch-0058.json` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `ch-0058`) |
| em-0071 | 2027-09-10T09:48:00-06:00 | email | Re: Fulmar pilot to four lines | `em-0071.eml` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `em-0071`) |
| mn-0013 | 2027-09-10T10:00:00-06:00 | meeting_notes | Recap: Catch-up: Amira / Adwoa | `mn-0013.md` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `mn-0013`) |
| mt-0008 | 2027-09-10T10:00:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0008.vtt` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `mt-0008`) |
| mt-0009 | 2027-09-10T10:00:00-06:00 | transcript | Catch-up: Amira / Adwoa (transcript) | `mt-0009.vtt` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `mt-0009`) |
| ch-0059 | 2027-09-10T13:01:00-06:00 | chat | #coffee | `ch-0059.json` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `ch-0059`) |
| ch-0060 | 2027-09-10T13:54:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0060.json` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `ch-0060`) |
| ch-0061 | 2027-09-10T14:13:00-06:00 | chat | #random | `ch-0061.json` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `ch-0061`) |
| em-0072 | 2027-09-10T15:48:00-06:00 | email | [Resolved] Elevated latency on file storage | `em-0072.eml` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `em-0072`) |
| em-0073 | 2027-09-10T16:05:00-06:00 | email | Room booking confirmation | `em-0073.eml` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `em-0073`) |
| mn-0014 | 2027-09-10T16:15:00-06:00 | meeting_notes | Recap: Catch-up: Amira / Thibault | `mn-0014.md` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `mn-0014`) |
| dc-0004 | 2027-09-10T16:46:00-06:00 | document | Fulmar lessons-learned note after Adwoa's comments v3 | `dc-0004.docx`; parent em-0074 | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `dc-0004`) |
| em-0074 | 2027-09-10T16:46:00-06:00 | email | Status note: w/e 10 September | `em-0074.eml` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `em-0074`) |
| nt-0004 | 2027-09-10T17:46:00-06:00 | note | Fri notes | `nt-0004.md` | [sources/2027-09-10.md](sources/2027-09-10.md) (heading `nt-0004`) |
| em-0075 | 2027-09-13T06:59:00-06:00 | email | Reminder: Friday status note due Friday 17 September | `em-0075.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0075`) |
| ca-0007 | 2027-09-13T07:39:00-06:00 | calendar | Invite: Rosia intro call | `ca-0007.ics` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ca-0007`) |
| nt-0005 | 2027-09-13T07:47:00-06:00 | note | Mon notes | `nt-0005.md` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `nt-0005`) |
| em-0076 | 2027-09-13T09:45:00-06:00 | email | Speaker spotlight | `em-0076.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0076`) |
| mn-0015 | 2027-09-13T09:55:00-06:00 | meeting_notes | Recap: Fulmar standup | `mn-0015.md` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `mn-0015`) |
| mt-0010 | 2027-09-13T09:55:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0010.vtt` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `mt-0010`) |
| mt-0011 | 2027-09-13T10:45:00-06:00 | transcript | Fulmar / work instructions selection sync (transcript) | `mt-0011.vtt` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `mt-0011`) |
| ch-0062 | 2027-09-13T11:29:00-06:00 | chat | DM: Adwoa Kocak / Amira Baek | `ch-0062.json` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ch-0062`) |
| em-0077 | 2027-09-13T11:30:00-06:00 | email | Reminder: all-staff meeting Thursday | `em-0077.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0077`) |
| mt-0012 | 2027-09-13T11:45:00-06:00 | transcript | MDO leads call (transcript) | `mt-0012.vtt` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `mt-0012`) |
| em-0078 | 2027-09-13T12:21:00-06:00 | email | Room booking confirmation | `em-0078.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0078`) |
| ch-0063 | 2027-09-13T13:43:00-06:00 | chat | DM: Amira Baek / Adwoa Kocak | `ch-0063.json` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ch-0063`) |
| em-0079 | 2027-09-13T13:45:00-06:00 | email | Re: Fulmar access request | `em-0079.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0079`) |
| ca-0008 | 2027-09-13T14:05:00-06:00 | calendar | Invite: Wagtail review | `ca-0008.ics` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ca-0008`) |
| em-0080 | 2027-09-13T14:58:00-06:00 | email | Galix sandbox credentials | `em-0080.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0080`; credentials omitted) |
| ch-0064 | 2027-09-13T17:02:00-06:00 | chat | #operator-ai-basics-core | `ch-0064.json` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ch-0064`) |
| em-0081 | 2027-09-13T17:16:00-06:00 | email | Open enrollment reminder | `em-0081.eml` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `em-0081`) |
| ca-0009 | 2027-09-13T18:06:00-06:00 | calendar | Invite: Walkthrough: Operator AI basics workshop room plan | `ca-0009.ics` | [sources/2027-09-13.md](sources/2027-09-13.md) (heading `ca-0009`) |
| ch-0065 | 2027-09-14T08:31:00-06:00 | chat | #ai-use-core | `ch-0065.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0065`) |
| ch-0066 | 2027-09-14T08:42:00-06:00 | chat | #random | `ch-0066.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0066`) |
| ch-0067 | 2027-09-14T09:54:00-06:00 | chat | DM: Alan Luo / Amira Baek | `ch-0067.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0067`) |
| mt-0013 | 2027-09-14T10:00:00-06:00 | transcript | Fulmar standup (transcript) | `mt-0013.vtt` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `mt-0013`) |
| em-0082 | 2027-09-14T10:59:00-06:00 | email | Re: Work instructions selection lessons-learned note | `em-0082.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0082`) |
| nt-0006 | 2027-09-14T11:34:00-06:00 | note | Tue notes | `nt-0006.md` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `nt-0006`) |
| em-0083 | 2027-09-14T11:52:00-06:00 | email | [Resolved] Elevated latency on file storage | `em-0083.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0083`) |
| em-0084 | 2027-09-14T12:10:00-06:00 | email | Fulmar: new target date | `em-0084.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0084`) |
| em-0085 | 2027-09-14T12:17:00-06:00 | email | Fulmar export failures | `em-0085.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0085`) |
| em-0086 | 2027-09-14T12:36:00-06:00 | email | Fwd: Refreshments for the operator AI basics workshop | `em-0086.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0086`) |
| ch-0068 | 2027-09-14T13:02:00-06:00 | chat | #wagtail-core | `ch-0068.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0068`) |
| ch-0069 | 2027-09-14T13:45:00-06:00 | chat | #general | `ch-0069.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0069`) |
| em-0087 | 2027-09-14T14:29:00-06:00 | email | Room booking confirmation | `em-0087.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0087`) |
| ch-0070 | 2027-09-14T14:39:00-06:00 | chat | DM: Batbayar Galbraith / Amira Baek | `ch-0070.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0070`) |
| ch-0071 | 2027-09-14T14:53:00-06:00 | chat | DM: Hamish Okada / Amira Baek | `ch-0071.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0071`) |
| mn-0016 | 2027-09-14T15:35:00-06:00 | meeting_notes | Recap: 1:1 Amira / Adwoa | `mn-0016.md` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `mn-0016`) |
| mn-0017 | 2027-09-14T15:45:00-06:00 | meeting_notes | Recap: Wagtail review | `mn-0017.md` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `mn-0017`) |
| ch-0072 | 2027-09-14T16:24:00-06:00 | chat | DM: Segun Okeke / Amira Baek | `ch-0072.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0072`) |
| ch-0073 | 2027-09-14T16:39:00-06:00 | chat | DM: Batbayar Galbraith / Amira Baek | `ch-0073.json` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `ch-0073`) |
| em-0088 | 2027-09-14T18:38:00-06:00 | email | Industrial Data Digest: issue 37 | `em-0088.eml` | [sources/2027-09-14.md](sources/2027-09-14.md) (heading `em-0088`) |
