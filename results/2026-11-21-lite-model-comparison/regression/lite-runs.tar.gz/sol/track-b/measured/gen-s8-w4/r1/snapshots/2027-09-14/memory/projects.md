# Portfolio — current through 2027-09-14

Baseline map, aliases, owners, sponsors and targets: [nt-0001]. All dates below are 2027. Fulmar's target changed on 13 and again on 14 September; other targets remain last-known baseline targets.

## Fulmar

**Aliases:** Project Fulmar / warranty claims pilot / Ivycrest pilot. AI warranty claims analyzer at Ivycrest Distribution Center on Wagtail. Owner Ottavio Bakker; sponsor Hamish Okada; baseline target **1 November** → **Friday 12 November** on 13 September → **Wednesday 24 November** in Ottavio's 14 September email. Latest target is 24 November; reason for either slip not specified. [nt-0001, mt-0010, mn-0015, em-0084]

- **Current stage: security review**, moved from build on 1 September. [nt-0001, ch-0020]
- **Scope decision 10 September:** agreed to limit pilot to **four lines**. The baseline already described four lines; treat the email as confirmation/explicit limit, not evidence of a numerical reduction from a different scope. [em-0071, nt-0001] Hamish reiterated the Friday agreement on 14 September; Amira agrees. This is not a new scope change. [ch-0071]
- **14 September:** Amira commits to **confirm Fulmar control plan with Adwoa Kocak**, no deadline/delivery. Amira takes **Fulmar export failures** at standup, then emails Batbayar at 12:17 that she **looked into** them: investigation done, **fix/resolution not established**. Thin documentation mentioned in standup. Do not merge with Batbayar's separately named Wagtail export fix. [mt-0013, em-0085, ch-0070, ch-0073]
- **Open confirmed Amira work:** API contract v2 (accepted 30 August, reiterated 10 September); timeline to Adwoa Kocak; action log to Adwoa with Marcelo; review Marcelo's data dictionary; review Ottavio's vendor comparison (accepted only in 10 September worker note); privacy impact assessment to Goran Liu **by 14 September**; access request to Oksana (accepted 13 September, no deadline). [mt-0001, ch-0060, mt-0004, ch-0042, ch-0058, em-0065, nt-0004, ch-0018, em-0079]
- **Other requests/offers not yet confirmed:** Amira offered to assemble security review package; Thibault asked for pilot charter (no acceptance/delivery shown); Adwoa requested dependency-list update; RACI chart update is explicitly tentative. Oksana's synthetic production data set remains a suggestion, not an assigned commitment. Adwoa's **Fulmar stakeholder-map** review request 13 September received 'maybe, need to see how the week goes'; not accepted, distinct from Morcliff stakeholder-map request. [mt-0003, ch-0023, ch-0052, nt-0004, mn-0004, ch-0062]
- **Waiting:** Giorgi to set up single sign-on role mapping with Adwoa Kocak **by 10 September**; past due as of 14 September, no completion/blocker supplied. Marcelo to send architecture diagram; Adwoa Kocak to send acceptance criteria and service blueprint; Oksana to send **comms plan**, promised 13 September with no deadline/delivery. [ch-0010, em-0043, mn-0010, em-0055, mt-0008, mt-0010, mn-0015]
- **Completed:** Ottavio drafted load test plan 1 September (with Batbayar named in original promise); Amira sent Marcelo data-flow diagram by 3 September; rollout checklist sent to Adwoa 3 September; Adwoa's requirements matrix reviewed 6 September; test plan confirmed with Marcelo 9 September; lessons-learned comments update delivered 2 September and latest version attached 10 September; Marcelo status slide delivered 6 September. [em-0015, ch-0017, mt-0004, em-0041, dc-0002, ch-0033, ch-0051, em-0033, dc-0001, em-0074, dc-0004, em-0047, dc-0003]
- **Risks:** flagship timelines tight in 3 September status note; generic timeline/overcommitment concerns in reviews. The 10 September status note says **nothing new this week**, not that earlier risks or Wagtail capacity blocker were resolved. [em-0042, mt-0003, mt-0005, em-0074, em-0039]

### Fulmar document state (delivery ≠ all underlying work complete)

- **Lessons-learned v2**, Amira, 2 September, attached to Adwoa email. Feedback incorporated where possible; two sections still being drafted. Communications reworded; training appendix; accessibility two options/no preference; security carried over. Open: post-project maintenance owner; council submission need. [dc-0001, em-0033]
- **Lessons-learned v3**, Amira, 10 September, parent w/e status email to Hamish. Title still Fulmar, but document project field and purpose say **Manufacturing Digital Office** (label inconsistency). Scope unchanged; feedback incorporated where possible; shared glossary. Communications unchanged; training two options/no preference; security pilot group only; data needs unit input. Open: realistic usage assumptions; fallback if dependency slips. Latest received version, not evidence of approval or full closure. [dc-0004, em-0074]
- **Rollout checklist draft**, 3 September: Support rota open/new; Accessibility review open/new; Comms in review/waiting on another team; Access open/carried over; Testing open/waiting on another team; Training in review/see notes; Integration in review/carried over; Documentation open/carried over. [dc-0002]
- **Status slide v2**, Marcelo, 6 September: scope unchanged; two sections drafting; timeline aligned to glossary; communications appendix; security to confirm; governance draft/comments welcome. Open: council need and unit hosting shared components. Actual slide content retained; no architecture/data-flow attachment provided. [dc-0003]

## Wagtail

**Aliases:** platform / common platform / Wagtail platform. Shared data platform for plant projects. Owner Oksana Hoffmann; sponsor Hamish; baseline onboarding tenants. [nt-0001]

- **Current stage: hardening**, from 6 September. [ch-0034]
- **Last explicit blocker:** gateway capacity limits, 3 September. No later explicit resolution. Generic 'mostly on track' 9 September does not close it. [em-0039, mt-0007]
- **Review held per recap:** 14 September 15:00–15:45 (UTC−06), Oksana, Amira, Adwoa Kocak and Quentin listed. Wagtail focus; Tevita fellowship reference still suggested, not accepted (Tevita mentioned as raising it but not listed as attendee). Overlaps Amira/Adwoa 1:1 15:05–15:35; automated notes do not resolve actual attendance. Original invite responses pending; no explicit operating-model agenda. [ca-0008, mn-0017, mn-0016]
- **Wagtail export failures:** Batbayar promises fix at 14:09 on 14 September, then reports **fixed earlier today** at 16:12. Completed by his report; distinct from Fulmar investigation and not proof gateway-capacity blocker cleared. [ch-0070, ch-0073, em-0039]
- **Wagtail staging access:** Amira asks Batbayar 14 September; his 'following :)' is not clear acceptance or delivery. Separate from Amira's Fulmar access request to Oksana and Galix sandbox. [ch-0068, em-0079, em-0080]
- Amira owes Oksana a Wagtail status slide, accepted in 9 September standup. Batbayar cutover-plan review completed 9 September. [mt-0007, em-0066]
- Model allow-list review was only requested, never accepted in worker's 30 August note; explicitly **dropped 1 September as duplicate of another ask**. [nt-0002, em-0006, em-0023]
- Vault-secrets rotation: Batbayar offered 6 September → handed to **platform lead** 8 September → **no longer needed/overtaken by events** 10 September. This is cancelled/superseded, not completed. Platform lead likely Oksana by role, but handoff message does not name the new owner or establish their acceptance. [mn-0005, ch-0050, mt-0008, nt-0001]

## Work Instructions Tool Selection (WITS)

**Aliases:** work instructions bake-off / Rosia-Galix evaluation / WITS selection. Amira owner; Kamau Greco sponsor; Ivycrest; baseline **waiting on vendor questionnaires**, target **25 October**. No stage change or vendor selection evidenced. [nt-0001]

- Segun Okeke requested Amira confirm selection decision memo with him 6 September; 'good to know' is not clear acceptance. [ch-0031]
- Segun **with Giorgi** promised Rosia accessibility conformance report 7 September; reiterated 8 September. **Blocked 9 September waiting on an unsigned agreement**. No delivery or agreement signer identified. [em-0051, em-0059, ch-0054]
- **Rosia intro-call invite:** 16 September 14:00–15:00 (UTC−06), Adwoa Kocak organizer, Amira invited/response pending. No outcome or report delivery shown. [ca-0007]
- **New accepted task:** send Segun **work instructions selection lessons-learned note**. Email request 14 September, DM acceptance 'no problem' at **11:00:06** (DM received 16:24). No deadline/delivery; not the completed Fulmar lessons-learned update. Email quotes Amira's 13 September request for WITS status update, but supplies no substantive status. [em-0082, ch-0072]
- Keep this report and decision memo distinct from Galix scrap-analysis diligence and Fulmar vendor comparison.

## Morcliff Safety Reporting Discovery (MSRD)

**Aliases:** Morcliff discovery / safety reporting work / MSRD discovery. Amira owner; Hamish sponsor; Morcliff Plant; baseline target **18 October**. [nt-0001]

- Stage: planning → **site visit 6 September** → **pivot 8 September** → **analysis 14 September**, per worker note. No evidence of separate tooling-wear effort decision or sprint scoping completion. [ch-0028, ch-0044, nt-0006]
- Explicit next decision: **whether tooling wear becomes its own effort**. Not yet decided/separate project. [ch-0044]
- Amira assigned to **scope a two-week sprint on tooling wear**, in 8 September site-visit recap. No deadline/result shown. [mn-0009]
- Tane to send tooling-wear wait-time export, communicated via Adwoa 9 September. [ch-0057]
- Current safety reporting process map: Tane promise via Adwoa on 31 August; Adwoa says 'looks like Tane sent you' 7 September. Reported delivered, but no actual map/attachment or precise send date in inputs. [ch-0012, em-0030, em-0053]
- Adwoa stakeholder-map review requested 9 September; Amira said 'Possibly. Can I get back to you'; **not accepted**. [mt-0007]

## Iselmoor Responsible AI Use Framework

**Aliases:** AI framework / framework / responsible-use framework. Amira owner; Hamish sponsor; plant-wide centrally drafted, widely consulted; target **29 October**. [nt-0001]

- **Endorsement**, moved from consultation 1 September and confirmed in 3 September status note. No endorsement approval evidenced. [em-0021, em-0042]
- Completed: AI-use risk taxonomy sent to Adwoa Kocak 31 August (later same-day todo is stale/conflicting, no evidence of new revision ask); consultation plan sent to Kian 6 September. [em-0010, nt-0003, ch-0030]
- **13 September decision:** use **approach C** for AI-use glossary. Approach C's content/rationale not supplied. **Principles draft dropped**, superseded by this decision; no longer waiting on it, not delivered/completed. [nt-0005, mn-0011]
- Amira offered to send Ottavio the **AI-use glossary sometime next week** on 13 September (20–26 September by date); only 'uh-huh' followed. **14 September:** Adwoa says Ottavio needs it **by 16 September**, earlier than offered window. Amira says 'good to know'/'thanks for flagging', not clear acceptance. Treat 16 September as requested need-by date, **not an agreed Amira deadline**. Approach C details and glossary delivery unknown. Mixed Fulmar/work-instructions meeting does not change glossary's AI-use identity. [mt-0011, ch-0065]
- Waiting: Adwoa Kocak lessons-learned note (1 September), comment log (10 September promise); Kian timeline (1 September offer). No deliveries shown. [em-0018, mn-0013, mt-0009, em-0025]
- Hamish endorsement-paper ask relayed by Adwoa **not agreed yet**. Wei decision memo ask via Zawadi: Amira 'maybe, need to see how the week goes'. Both remain unaccepted. [ch-0026, ch-0032]

## Operator AI Basics Workshop

**Aliases:** workshop / Sandfield workshop / operator AI basics session. Owner Adwoa Kocak; Hamish sponsor; Amira owns slides; Sandfield Distribution Center; baseline target **18 October**. [nt-0001]

- **Delivery**, per worker note 14 September; previously logistics from 1 September. Stage change does not prove workshop held/completed or move 18 October target. [ch-0021, em-0042, nt-0006]
- **Attendee list:** 14 September Amira/Adwoa 1:1 suggests Amira send Adwoa the list, **no owner agreed yet**. Not a commitment. [mn-0016]
- Amira to send **Wei slides v2**, confirmed in 2 September forum recap; no deadline/delivery supplied. [mn-0003]
- Adwoa sending registration reminder is only Kian's suggestion, explicitly not agreed. [em-0057]
- **Refreshments:** Adwoa Kocak confirmed 'yep, on it' 13 September; 14 September forward quotes her 13 September email promise to Wei, not a new task or completion. No deadline. Distinct from reminder. [ch-0063, em-0086]
- **Room-plan walkthrough:** Amira committed to walk Adwoa through it 13 September; invite sent for **15 September 14:00–14:30 (UTC−06)**. Amira organizer, Adwoa invitee/response pending; placeholder, agenda to follow. Scheduled, not performed; not a change to workshop's 18 October target or a link to generic room bookings. [ch-0064, ca-0009]

## Wagtail Operating Model Review

**Aliases:** operating model review / ops model draft / Wagtail operating model. Owner Oksana; Hamish sponsor; reviewers include Adwoa and Tane/Morcliff. **Done**, reported by Oksana at 14 September Fulmar standup, superseding **in revision** from 31 August. No deliverable or specific approval outcome supplied. Distinct from Wagtail platform hardening, afternoon Wagtail review and cancelled model allow-list ask. [nt-0001, nt-0003, mt-0013]

## Wilhaven Partnership

**Aliases:** Wilhaven relationship / Wilhaven. Amira owner; Hamish sponsor; ongoing with Wilhaven Industrial Research Center and Ivycrest. [nt-0001]

- Kiran Merriweather promised working paper 2 September; no delivery shown. [em-0028]
- Kiran requested catch-up be set up **by Friday 17 September**, Amira accepted 7 September and confirmed it was set up **8 September**. Exact scheduled meeting date/time not supplied; setup deadline is not meeting date. [ch-0036, ch-0046]

## Predictive Maintenance Input Round

Amira owner; Hamish sponsor; collecting plant input (Rodrigo/Falhaven listed). Task **summarize predictive maintenance input for Hamish**: Amira accepted 9 September, then **handed to Adwoa Kocak** in 13 September MDO leads call ('Adwoa will take it from here'). Alan Luo corroborates transfer to Kocak 14 September; Amira acknowledges. No longer Amira-owned; no due date/delivery or explicit Adwoa acceptance of handoff shown. [ch-0067] Portfolio owner remains baseline Amira; task handoff does not establish project-owner change. [nt-0001, ch-0056, mt-0012]

Separate tentative task: reference note for **Tevita Rosales's predictive maintenance fellowship application**, suggested at 10 September Thibault catch-up and reiterated in 14 September Wagtail review, uptake still open. Not accepted; not part of input-summary commitment or necessarily a Wagtail project task. [mn-0014, mn-0017]

## Last-known placeholders / quiet work (no new stage evidence)

- **Sandfield Changeover Planning Idea:** Kian owner, Hamish sponsor; waiting on Kian's problem statement. [nt-0001]
- **Falhaven Shift Handover Idea:** Rodrigo owner, Hamish sponsor; waiting on Rodrigo's problem statement. [nt-0001]
- **Galix Scrap Analysis Diligence:** Amira owner, Hamish sponsor; in diligence; initial enthusiasm, no later diligence-stage decision evidenced. New sandbox setup is project-unspecified (see below). Waiting on **Adwoa Chukwu**, not Adwoa Kocak, for Galix deep-dive materials. Offered 30 August, reiterated via multiple channels through 3 September. Forwarded promise is not delivery; no materials in inputs. [nt-0001, ch-0002, em-0008, ch-0011, ch-0024, mn-0004]
- **Galix sandbox access:** Nikhil Teixeira, Solutions Engineer at Galix Labs, reports access set up 13 September; asks temporary password changed at first login; sandbox resets Sunday nights. No login/change evidence. Credentials not retained. Email does not specify WITS vs scrap diligence, and access does not deliver Chukwu's materials. [em-0080]
- **Production Scheduling Learning Series:** Adwoa Kocak owner, Hamish sponsor; with Wilhaven/Ivycrest; quiet/no sessions booked as of baseline; no later change. [nt-0001]

## Visual inspection / other emerging work

- Worker todo to set up coffee with Adwoa about **visual inspection**, 6 September; **set up 7 September**. Meeting itself not evidenced/date unknown. [mn-0007, ch-0039]
- Amira accepted joining **Ignacio Choi's panel on visual inspection** 7 September; date/organization/delivery unknown. Do not merge with coffee setup. [ch-0038]
- Notes from warranty claims session: Amira hoped Adwoa ('Adwoah' in automatic transcript) would send them; explicitly **nothing agreed**. Likely Kocak from context, not certain from transcript alone. [mt-0006]
