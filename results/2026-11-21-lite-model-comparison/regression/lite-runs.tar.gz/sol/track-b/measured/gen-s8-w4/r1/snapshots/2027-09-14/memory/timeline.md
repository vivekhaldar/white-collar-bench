# Chronology, calendar and logistics

Current date: **2027-09-14**. Input received timestamps generally use UTC−06:00. Calendar timestamps ending Z are UTC; converted local times below use that source offset (not an inferred named timezone).

## Significant project/commitment changes

### 30 August
- Worker records initial 13-project portfolio and roles; Fulmar build, four lines, 1 November target; Wagtail onboarding; work instructions waiting questionnaires; Morcliff planning; AI framework consultation; workshop planning; ops model out for review. [nt-0001]
- Amira commits API contract v2 at Fulmar standup and status note w/e 3 September to Hamish. Oksana allow-list request remains unaccepted. Galix Chukwu materials promised, forwarded by Kocak, not delivered. [mt-0001, ch-0003, nt-0002, em-0006, ch-0002, em-0008]

### 31 August
- Amira sends AI-use risk taxonomy to Kocak at 09:07; later todo contradictory/stale. Ops model **in revision**. [em-0010, nt-0003]
- Giorgi role mapping due 10 September; Tane process-map promise; Ottavio load-test plan promise with Batbayar. [ch-0010, ch-0012, em-0015]

### 1 September
- Ottavio reports load-test plan drafted. Amira commits PIA by 14 September to Goran. Security-review package and synthetic-data proposals remain offers. [ch-0017, ch-0018, mt-0003]
- AI framework **endorsement**; Fulmar **security review**; workshop **logistics**. [em-0021, ch-0020, ch-0021]
- Amira drops Wagtail allow-list as duplicate. Adwoa AI lessons-learned note promise; Kian timeline offer. [em-0023, em-0018, em-0025]

### 2 September
- Fulmar standup cancelled, covered in leads call. [ca-0003]
- Amira accepts lessons-learned update and delivers v2 to Adwoa; forum assigns slides v2 to Wei. Kiran working paper promised. [ch-0022, em-0033, dc-0001, mn-0003, em-0028]
- Marcelo requests data-flow diagram; Amira requests charter from Thibault, acceptance not shown. [em-0027, ch-0023]

### 3 September
- Amira says data-flow diagram sent; promises rollout checklist and timeline to Adwoa. Sends checklist draft at 13:53. [mt-0004, em-0041, dc-0002]
- Wagtail **gateway capacity limits** blocker. [em-0039]
- Hamish endorsement-paper request not agreed. Synthetic data still suggested; Galix materials promise reaffirmed. [ch-0026, mn-0004]
- Status w/e 3 September sent at 17:07: workshop logistics; AI endorsement; flagship timeline risk. [em-0042]

### 6 September
- Amira accepts then completes requirements-matrix review; Marcelo delivers status slide v2; consultation plan sent to Kian. [em-0045, ch-0033, em-0047, dc-0003, ch-0030]
- Morcliff **site visit**; Wagtail **hardening**. [ch-0028, ch-0034]
- Batbayar vault rotation assignment; coffee about visual inspection todo. Work-instructions memo request; Wei AI memo not accepted. [mn-0005, mn-0007, ch-0031, ch-0032]

### 7 September
- Fulmar standup cancelled because people out. [ca-0004]
- Segun/Giorgi Rosia conformance report promised. Adwoa reports Tane map sent. Fulmar acceptance criteria offer from Adwoa. [em-0051, em-0053, em-0055]
- Wilhaven catch-up setup accepted with deadline 17 September; visual inspection panel accepted; coffee with Adwoa set up. [ch-0036, ch-0038, ch-0039]
- Amira cutover review assignment relayed; workshop reminder remains suggested; warranty notes remain unagreed. [ch-0040, em-0057, mt-0006]

### 8 September
- Amira action log promise with Marcelo; test plan confirmation accepted. Wilhaven catch-up **set up**. [ch-0042, ch-0043, ch-0045, ch-0046]
- Morcliff **pivot**: two-week tooling-wear sprint scoping assigned; decide if tooling wear becomes separate effort. [mn-0009, ch-0044]
- Marcelo architecture diagram promise; vendor comparison still tentative; waiting on Adwoa AI principles draft. [mn-0010, mn-0011]
- Batbayar vault rotation handed to platform lead. [ch-0050]

### 9 September
- Amira data-dictionary review accepted; cutover review and test-plan confirmation complete. Wagtail status-slide promise. [em-0065, em-0066, ch-0051, ch-0053, mt-0007]
- Stakeholder map review not accepted; dependency list update requested without acceptance. [mt-0007, ch-0052]
- Rosia report **blocked by unsigned agreement**. Predictive-input summary accepted; Tane wait-time export promise relayed. [ch-0054, ch-0056, ch-0057]

### 10 September
- Action log and API contract still open/reaffirmed. Fulmar **four-line limit agreed**. [ch-0058, ch-0060, em-0071]
- Vault rotation **no longer needed/overtaken**. Adwoa accepts Fulmar service blueprint and AI comment log. [mt-0008, mt-0009, mn-0013]
- Fellowship reference still suggested. Status w/e 10 September sent 16:46 with lessons update/test-plan confirmation, no new risks; attached lessons note v3. [mn-0014, em-0074, dc-0004]
- Worker accepts vendor comparison review; RACI update remains tentative. [nt-0004]

### 13 September
- Worker chooses **approach C** for AI-use glossary, drops principles draft as superseded; approach details not provided. [nt-0005]
- Fulmar target moves **1 November → Friday 12 November**; Oksana promises comms plan. Standup recap and transcript corroborate. [mn-0015, mt-0010]
- AI-use glossary to Ottavio next week only offered; Fulmar stakeholder-map review only 'maybe'. [mt-0011, ch-0062]
- Amira hands predictive maintenance input summary to **Adwoa Kocak**, no delivery or explicit Adwoa acceptance captured. [mt-0012]
- Adwoa confirms workshop refreshments; Amira accepts room-plan walkthrough and sends 15 September invite. [ch-0063, ch-0064, ca-0009]
- Amira commits Fulmar access request to Oksana. Galix sandbox setup reported by Nikhil, no project-specific purpose/login evidenced; credentials omitted. [em-0079, em-0080]
- New status reminder due EOD 17 September; Rosia/Wagtail invites and Sunday 19 September room booking received. [em-0075, ca-0007, ca-0008, em-0078]

### 14 September
- Fulmar target moves **12 November → Wednesday 24 November**, per Ottavio 12:10 email; Friday four-line agreement reiterated by Hamish, not a new reduction. [em-0084, ch-0071]
- Worker moves Morcliff discovery to **analysis** and operator workshop to **delivery**. Neither means completed; no target changes stated. [nt-0006]
- Oksana reports **Wagtail Operating Model Review done** at Fulmar standup. Amira commits Fulmar control-plan confirmation with Adwoa. [mt-0013]
- Amira takes Fulmar export failures at standup, reports **looked into** to Batbayar at 12:17. Not proof of a fix. Separately, Batbayar commits **Wagtail export failures fix** 14:09, reports fixed earlier today at 16:12. [mt-0013, em-0085, ch-0070, ch-0073]
- Segun requests work-instructions lessons-learned note by email and DM 10:59; Amira accepts **11:00:06**. DM received 16:24, not time of acceptance. No delivery/deadline; separate from Fulmar note. [em-0082, ch-0072]
- Adwoa relays Ottavio's AI-use glossary need-by **16 September**; Amira only acknowledges, no agreed deadline. Alan corroborates predictive-input summary handoff to Kocak. [ch-0065, ch-0067]
- Amira asks Batbayar for Wagtail staging access 12:30; no clear acceptance. Forwarded refreshments email repeats Adwoa's 13 September promise, not delivery. [ch-0068, em-0086]
- Wagtail review recap keeps fellowship reference tentative; overlapping 1:1 keeps workshop attendee-list task suggested/no owner agreed. [mn-0017, mn-0016]
- File-storage latency resolved per status email, not evidence of project export/capacity fixes. Room 2.14 confirmed for 23 September. [em-0083, em-0087]

## Calendar evidence and caveats

| Artifact | Event | Source local time (UTC−06) | Status / caveat |
|---|---|---|---|
| ca-0001 | Fulmar build sync, Ottavio organizer; Marcelo/Giorgi/Amira invitees | 1 Sep 10:00–10:30 (16:00–16:30Z) | Invite only; attendance/completion not established. |
| ca-0002, mn-0002 | Amira/Vitoria catch-up | 1 Sep 15:00–15:30 (21:00–21:30Z) | Meeting recap: general discussion, no new items. |
| ca-0003 | Fulmar standup instance | 2 Sep 09:30–09:55 | **Cancelled**, covered in leads call; recurrence instance only. |
| ca-0004 | Fulmar standup instance | 7 Sep 09:30–09:55 | **Cancelled**, a few people out; same series UID as 2 Sep. |
| ca-0005, mn-0010 | Amira/Marcelo catch-up | 8 Sep 13:00–14:00 (19:00–20:00Z) | Calendar duration **60 min**, description says '30 minutes'; retain discrepancy. Worker notes timestamp 14:00 give diagram follow-up. |
| ca-0006, mn-0013, mt-0009 | Amira/Adwoa Kocak catch-up | 10 Sep 09:30–10:00 (15:30–16:00Z) | Recap and transcript support comment-log promise. Recap says next Tuesday usual time, not a booked invite. |

### Recent invites (future responses pending; 14 September review has recap)

| Artifact | Event | Source local time (UTC−06) | Status / caveat |
|---|---|---|---|
| ca-0007 | Rosia intro call | **16 Sep 14:00–15:00** (20:00–21:00Z) | Adwoa Kocak organizer, Amira required invitee/NEEDS-ACTION. Description 'Catch-up'. |
| ca-0008, mn-0017 | Wagtail review | **14 Sep 15:00–15:45** (21:00–21:45Z) | Recap lists Oksana, Amira, Adwoa and Quentin. Fellowship reference still suggested; no explicit operating-model agenda. Overlaps 1:1 below; invite itself had NEEDS-ACTION. |
| ca-0009 | Operator AI basics workshop room-plan walkthrough | **15 Sep 14:00–14:30** (20:00–20:30Z) | Amira organizer, Adwoa Kocak required invitee/NEEDS-ACTION. Placeholder, agenda to follow. Amira commitment [ch-0064]; not workshop itself. DTSTAMP 14 Sep 00:06Z = received 13 Sep 18:06 local, not a date discrepancy. |

**Other meeting evidence:**
- 14 Sep Fulmar standup **09:35–10:00** [mt-0013]; Amira/Adwoa 1:1 **15:05–15:35** [mn-0016] overlaps Wagtail review **15:00–15:45** [mn-0017]. Both automated recaps list Amira and Adwoa; actual attendance/timing unresolved. Tevita is described as raising a reference note in Wagtail recap but absent from attendee list; do not infer he attended.
- 13 Sep Fulmar standup 09:30–09:55 [mn-0015, mt-0010]; Fulmar/work-instructions selection sync 10:00–10:45 [mt-0011]; MDO leads call 11:00–11:45 [mt-0012].
- 30 Aug Fulmar standup 09:35–10:00 [mt-0001]; 31 Aug 09:35–10:00 [mn-0001]; 1 Sep 09:30–09:55 [mt-0003]; 3 Sep 09:30–09:55 [mt-0004]; 6 Sep 09:30–09:55 [mn-0005]; 9 Sep 09:30–09:55 [mt-0007]; 10 Sep 09:35–10:00 [mt-0008]. The 10 Sep standup overlaps the 09:30–10:00 Adwoa catch-up; automated inputs do not resolve actual attendance/timing. Don't fabricate rescheduling.
- 30 Aug Amira/Baraka 16:00–16:45: thin documentation, absent users, finance views, but no identified project or new task. [mt-0002]
- 2 Sep cross-plant AI forum 13:00–14:00: workshop slides assignment. [mn-0003]
- 3 Sep Thibault office hours 13:30–14:15 with Rodrigo: synthetic-data suggestion and Galix materials promise. [mn-0004]
- 6 Sep Fulmar security review notes **11:00–11:30** [mn-0006] vs transcript **16:00–16:30** [mt-0005], with different attendee lists; do not merge as one accurately timed meeting. Both corroborate lessons update done.
- 7 Sep Sandfield relationship check-in 15:30–16:00 with Kian: warranty session notes not agreed. [mt-0006]
- 8 Sep Morcliff visit recap 10:00–10:30 with Amira/Adwoa: next Wednesday usual time (likely 15 Sep by date, no explicit booking/time supplied). [mn-0009]
- 10 Sep Thibault catch-up 15:30–16:15: reference note suggested. [mn-0014]

## Forward dates and administrative information

No room confirmation below supplies a time or project purpose. Multiple rooms on a day are **not** proven replacements or conflicts; no cancellation evidence. Policy: cancel at least **24 hours ahead** if plans change.

| Booking date | Room(s), supporting artifact |
|---|---|
| 4 Sep (past) | 2.14 [em-0005] |
| 11 Sep (past) | 3B [em-0036]; Atrium [em-0056]; 4.02 [em-0068] |
| **15 Sep** | 4.02 [em-0050]; 2.14 [em-0054]; 3B [em-0073] |
| **17 Sep** | 4.02 [em-0062]; Atrium [em-0064] |
| **19 Sep (Sunday)** | 3B [em-0078]; no time/purpose supplied |
| **23 Sep (Thursday)** | 2.14 [em-0087]; no time/purpose supplied |

- 11 Sep **20:00–23:00** IT maintenance: VPN/shared drives/self-service portal may unavailable, no action needed. [em-0060]
- 14 Sep **22:00–02:00** network maintenance (window crosses into 15 Sep); some services up to 20 min unavailable; affected file storage/SSO/video meetings partial. [em-0063]
- Earlier notices: 8 Sep 20:00–23:00 IT maintenance [em-0013]; 9 Sep 22:00–02:00 network maintenance [em-0019]. Subject 'this weekend' in IT mail is not more authoritative than body dates.
- Platform incident updates: investigating 1 Sep [em-0017], investigating 9 Sep [em-0067]; 10 Sep resolved/services normal [em-0072]; latest **14 Sep resolved/services normal** for elevated file-storage latency, affecting file storage/SSO/video meetings (partial), summary within five business days [em-0083]. Different incident IDs are absent: don't assert all notices concern the same incident. Earlier resolved update 31 Aug [em-0011]. This general service status does not explicitly resolve Wagtail gateway-capacity blocker.
- Building access: original 31 Aug notice said next Monday (**6 Sep**) north badge-reader replacement, main entrance until further notice [em-0009]. **13 Sep repeat notice says 'from next Monday' (20 Sep inferred)** with same main-entrance instruction [em-0077]. Subject 'all-staff meeting Thursday' does not match body and supplies no meeting time. Retain conflicting start dates; no completion or explicit reschedule supplied.
- Parking resurfaced over two weekends, east overflow lot; weekends not dated. 6 Sep all-staff-reminder subject actually contains parking notice, not a new meeting time. [em-0012, em-0049]
- Earlier all-staff reminder: Thursday 12:30, from 31 Aug notice (2 Sep inferred from weekday); no attendance proof. [em-0014]
- Event-space survey closed **10 Sep**; no worker response evidence. [em-0048]
- Regional Digital Services Summit proposals close **22 Sep**; talks/panels/workshops welcome. Newsletter, **no Amira submission commitment** and not necessarily Ignacio's panel. [em-0070]
- Open enrollment until **30 September (end of month)**, latest 13 Sep reminder asks review elections in benefits portal; no worker action evidenced [em-0016, em-0058, em-0081]; wellness-credit claims end of quarter [em-0038]; benefits statement available [em-0020]. Automated reminders, not promises by worker.

- Adwoa Kocak plans **remote, online all day 14 September**, stated 13 Sep. [ch-0063]
- Giorgi says parking permits renew next month (**October**, inferred), no specific deadline/policy supplied. [mt-0010]
- 13 Sep speaker spotlight describes a session on pilots people adopt; informational, no registration/speaking commitment. [em-0076]
- Galix sandbox reset **every Sunday night**; Nikhil requests temporary password changed at first login. No first-login/change evidence; credentials not retained. [em-0080]

- 14 Sep Goran reports east-side elevator out again; no repair/return-to-service date. [ch-0066]
- Amira and Segun report slow shared drive morning 14 Sep (DM at 11:04–11:06), preceding resolved status email at 11:52. Do not infer this caused a missed deliverable. [ch-0072, em-0083]
- Batbayar says he caught only first half of all-hands; no meeting time or Amira attendance established. Hamish's generic 'did the link work' / Amira 'yep' does not establish PIA or other task completion. [ch-0070, ch-0071]
- 14 Sep Industrial Data Digest issue 37 covers SSO, service desks and vendor demos; informational, no assigned action. [em-0088]

## IT tickets (last known only; not project blockers by inference)

| Artifact | Ticket | Status | Summary / update |
|---|---|---|---|
| em-0007 | INC-51157 | Awaiting user | Software install; confirm issue fixed. |
| em-0026 | REQ-19167 | Resolved | Docking station undetected; replacement hardware ordered. |
| em-0029 | INC-45928 | Assigned | Printer queue stuck; replacement hardware ordered. |
| em-0031 | INC-46909 | Awaiting user | Docking station undetected; replacement hardware ordered. |
| em-0034 | REQ-36368 | Resolved | Shared drive permissions; asks confirm fixed. |
| em-0037 | INC-64319 | In progress | Docking station undetected; no further action needed. |
| em-0040 | INC-56346 | Assigned | VPN drops hourly; technician assigned. |
| em-0069 | INC-78782 | In progress | Software install; replacement hardware ordered. |

Ticket status and last-update text can appear inconsistent; preserve both rather than assume closure or response. Social chat/newsletters are available in the evidence archive but are not treated as project decisions.
