# People and entities

Worker **Amira Baek**, Iselmoor Industries, Manufacturing Digital Office (MDO). The inputs do not give Amira's formal job title. [nt-0001]

## Roles and relationships

Baseline roles and project associations below are from [nt-0001] unless an additional ID is noted.

| Person | Role / organization | Relevant connection |
|---|---|---|
| Hamish Okada | VP Digital Operations, MDO | Sponsor for most portfolio work; recipient of Friday status notes and predictive-maintenance input summary. Work instructions sponsor is Kamau, not Hamish. [em-0042, em-0074, ch-0056] |
| Adwoa **Kocak** | Director of Digital Programs, MDO | Frequent internal counterpart; workshop/learning-series owner; Fulmar requirements/comments/action log/timeline; AI framework drafts/logs. |
| Ottavio Bakker | Production Planning Lead, Ivycrest Distribution Center | Fulmar owner; load-test plan drafting with Batbayar; vendor comparison Amira accepted to review; announces 12 November then **24 November** target; glossary recipient needing it 16 Sep (Amira deadline not accepted). [em-0015, nt-0004, mt-0010, em-0084, ch-0065] |
| Giorgi Wisniewska | Shift Supervisor, Ivycrest | Fulmar SSO role mapping with Kocak; Rosia accessibility report with Segun. [em-0043, em-0051] |
| Oksana Hoffmann | Principal, Data Platform, MDO | Wagtail and operating-model owner; cancelled allow-list ask; hardening/capacity updates. Platform lead handoff likely refers to her, but not explicitly named. [ch-0050] |
| Marcelo Meijer | Principal, OT Security, MDO | Fulmar security counterpart; requested data-flow diagram; status slide delivered; architecture diagram promised; data dictionary review and test-plan confirmation. [em-0027, em-0047, mn-0010, em-0065, ch-0051] |
| Batbayar Galbraith | Data Platform Engineer, MDO | Load-test plan collaborator; Wagtail cutover plan author; vault-secrets task offered then handed off/cancelled. [em-0015, em-0066, mn-0005, ch-0050, mt-0008] |
| Thibault Kowalski | Product Lead, Operator Tools, MDO | Fulmar participant; pilot charter requested from him, no promise shown; office hours/catch-ups. [ch-0023, mn-0004, mn-0014] |
| Kamau Greco | Plant Manager, Ivycrest | Work Instructions Tool Selection sponsor, Fulmar review participant. |
| Segun Okeke | Account Executive, Rosia Analytics | Work instructions vendor counterpart; report promised with Giorgi, blocked by unsigned agreement. [em-0051, ch-0054] |
| Adwoa **Chukwu** | Account Executive, Galix Labs | Promised Galix deep-dive materials. Different person from Kocak. [em-0008, ch-0024] |
| Nikhil Teixeira | Solutions Engineer, Galix Labs | Reports Amira's sandbox access set up; first-login password change instruction and Sunday-night resets. No specific project assignment in email. Credentials omitted. [em-0080] |
| Tane Haugen | Quality Engineering Lead, Morcliff Plant | Safety reporting discovery, process-map promise/reported delivery; tooling-wear wait-time export. [ch-0012, em-0053, ch-0057] |
| Quentin Ribeiro | Process Engineer, Morcliff Plant | Safety reporting discovery participant. |
| Kian Ishikawa | Continuous Improvement Lead, Sandfield Distribution Center | Changeover idea owner/problem statement; AI framework endorsement update/timeline/consultation plan; workshop counterpart. [em-0021, em-0025, ch-0030] |
| Zawadi Quintero | MES Administrator, Sandfield | AI/workshop counterpart; relays Wei decision-memo request. [ch-0032] |
| Wei Suwannarat | Controls Engineer, Sandfield | Workshop slides v2 recipient; requested AI-use decision memo via Zawadi (unaccepted). [mn-0003, ch-0032] |
| Rodrigo Oduro | Logistics Manager, Falhaven Assembly | Shift handover idea owner/problem statement; predictive maintenance input participant. |
| Kiran Merriweather | Senior Research Scientist, Wilhaven Industrial Research Center | Working paper promise; catch-up setup by 17 Sep request (setup complete 8 Sep). Role in signature [em-0028]; catch-up [ch-0036, ch-0046]. |
| Tevita Rosales | Dorbury Components (formal role unknown) | Cross-plant AI forum attendee; fellowship reference request only tentative. [mn-0003, mn-0014] |
| Alan Luo | Role/organization not specified | Corroborates predictive-input summary transfer from Amira to Adwoa Kocak 14 Sep; no role inferred from FYI. [ch-0067] |
| Goran Liu | Role/organization not specified | Amira's Fulmar PIA commitment recipient, due 14 Sep. [ch-0018] |
| Ignacio Choi | Role/organization not specified | Visual inspection panel organizer/counterpart; Amira accepted joining. [ch-0038] |
| Vitoria Sadeghi | Sandfield Distribution Center (formal role unknown) | 1 Sep catch-up; recap says no new items. [ca-0002, mn-0002] |
| Baraka Chevalier | Role/organization not specified | 30 Aug generic catch-up; discussion subject not identified; social/office chats. [mt-0002] |
| Aroha Ricci | Events Coordinator, Iselmoor | Room booking confirmations, event-space survey. [em-0036, em-0048, em-0073] |
| Sipho Smit | Conference Organizer | Summit call for proposals/newsletter; no submission commitment. [em-0003, em-0070] |
| Agus Phiri | Newsletter sender (formal role unknown) | Industrial Data Digest; informational only. [em-0022, em-0052] |

## Latest availability and responsibility updates — 14 September

- Alan confirms predictive summary transfer to Kocak; no delivery/explicit Kocak acceptance. [ch-0067]
- Batbayar promises then reports **Wagtail export failures fixed**; Wagtail staging-access request only acknowledged 'following :)'. Amira separately reports investigating **Fulmar** export failures. [ch-0070, ch-0073, ch-0068, em-0085]
- Oksana reports operating-model review done. Amira accepts control-plan confirmation with Kocak. [mt-0013]
- Segun receives Amira's acceptance to send **work instructions selection lessons-learned note**, no deadline/delivery. Existing Rosia report still last-known blocked. [ch-0072, em-0082, ch-0054]

### Retained 13 September availability/assignment evidence

- Adwoa **Kocak** is handed predictive maintenance input summary for Hamish; explicit acceptance not captured [mt-0012]. Confirms workshop refreshments [ch-0063], room-plan walkthrough invitee [ca-0009], Rosia intro-call organizer [ca-0007]. Plans remote/online all day **14 September** [ch-0063].
- Oksana promises Fulmar comms plan [mt-0010, mn-0015], is recipient of Amira's accepted access-request task [em-0079], organizes Wagtail review [ca-0008].

## Name/handle disambiguation

- **Tavo** is Ottavio Bakker: email signature 'Cheers, Tavo' identifies full name/role [em-0015]; DM manifest identifies Ottavio though user string says Tavo [ch-0007].
- **Adwoa / @adwoa** in internal core channels and `dm-adwoa-amira` normally refers to **Kocak**, supported by participants/artifact titles and email context. **Adwoa** in `dm-adwoac-amira` refers to **Chukwu**, supported by titles [ch-0002, ch-0024]. Don't collapse people based only on first name.
- **'Adwoah'** automatic transcript spelling refers to Kocak where counterpart/speaker is clear [mt-0005, mt-0008]. In warranty-claims-session-notes suggestion [mt-0006], no surname is spoken: Kocak likely from context, but retain uncertainty.
- **Thibault K.** in automatic transcript is consistent with listed attendee Thibault Kowalski [mt-0007].
- Chat reactions were not retained in the normalized evidence archive; acknowledgments in message text are retained. Neither reactions nor generic 'noted/good to know' by themselves establish acceptance/completion.

## Organizational distinctions

- Iselmoor Industries → MDO; Ivycrest Distribution Center (Fulmar/work instructions); Morcliff Plant (safety reporting/tooling-wear pivot); Sandfield Distribution Center (workshop/changeover idea); Falhaven Assembly (shift handover/predictive input); Dorbury Components (Tevita). [nt-0001, mn-0003]
- **Rosia Analytics** and **Galix Labs** are vendor candidates in work instructions. **Galix scrap-analysis diligence** is separate from that evaluation. [nt-0001]
- **Wilhaven Industrial Research Center** is external research partner; relationship and quiet production-scheduling learning series are separate portfolio items. [nt-0001, em-0028]
