# Despina Pereira — working memory

**Current through 2027-02-23 (task's today).** Organization: Lanhurst University System, Office of Academic Technology (OAT). Inputs covered: February 8–12, 15–19 and 22–23, 2027; 218 artifacts.

## Read first
- [Current portfolio](memory/portfolio.md): project identities, owners, sponsors, latest stage, decisions and dependencies.
- [Commitment ledger](memory/commitments.md): open, tentative, completed and cancelled items; attribution conflicts and due dates.
- [People](memory/people.md): roles and identity disambiguation.
- [Schedule and notices](memory/schedule.md): invitations, future room bookings, maintenance and administrative dates.
- [Evidence index](memory/artifacts.json): artifact IDs, date, channel, title, durable evidence location.
- `memory/YYYY-MM-DD.md`: retained source text, in arrival order, labeled by original artifact ID and received timestamp. Emails retain sender/recipient and quoted history; chats retain speaker/timestamp and reply indices, with handles/reactions in a metadata appendix (Feb 22–23 chats retain JSON metadata inline); notes/transcripts/calendar text retained. `memory/dc-0001.md` contains the workbook's sheet and cell values; `memory/dc-0002.md` retains the Axolotl stakeholder map v1 paragraphs and table.

## Answering rules
Cite original input artifact IDs (e.g. `[ch-0041, em-0079]`), not just these summary filenames. Later explicit updates supersede earlier ones; do not turn offers, requests, suggestions, reactions, "maybe", or "back on" into completion. Meeting assistants and transcripts may be inaccurate: use explicit first-person statements and direct correspondence to resolve conflicts, and disclose unresolved attribution. A sent-document claim establishes delivery, not its contents when no actual document was supplied. Original portfolio targets are retained as targets, not promises or proof of completion. Do not infer that every room reservation is a learning-series session or that a meeting's title determines every action's project.

Latest changes: Fennel is in **hardening** [em-0091]; Course Assistant Tool Selection is moving into **contracting** [ch-0075]. Axolotl target is now **April 7**, per automatic recap [mn-0012]. Despina turned around API contract v2 [ch-0072] and completed looking into slow page loads, **not proof of a fix** [em-0095]. Liisa fixed captioning stale cache [ch-0077]. New recap-assigned sends: captioning test plan to Karim, Axolotl support model to Losa and Axolotl timeline to Andres [mn-0012]; Despina promises AI-use consultation plan to Andres [mt-0011]. Fennel access request remains **an unsent draft with attachment missing** [em-0097]. Requested dates: Fennel checklist Feb 24 [ch-0078], Nathaniel's Axolotl map Feb 25 [ch-0071]. Decision-memo walkthrough invite remains Feb 25 [ca-0010]; Friday note due Feb 26 [em-0081].

No evidence after February 23 is known. No completion evidence means **not known complete**, not necessarily overdue or unperformed. Source join links/passcodes and all URLs have been omitted conservatively; do not reconstruct them. The inbox is ephemeral; these files are the retained record.
