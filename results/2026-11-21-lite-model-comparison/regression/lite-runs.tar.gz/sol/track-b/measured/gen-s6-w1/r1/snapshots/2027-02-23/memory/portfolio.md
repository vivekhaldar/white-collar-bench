# Current portfolio — 2027-02-23

Baseline identities, participants, owners, sponsors and targets: **nt-0001** (Feb 8). "Me" is Despina Pereira. Unless explicitly updated below, owner/sponsor/target remain baseline, and stage is merely last observed.

## Axolotl
Aliases: Project Axolotl, lab safety training pilot, Dorcliff pilot. AI lab safety tutor at Dorcliff State College, hosted on Fennel. Owner **Losa Moretti**; sponsor **Jurgen Dvorak**; original target **March 30**, now **April 7** per Feb 23 automatic recap (no direct confirmation or reason supplied). [mn-0012] Team: Losa, Andres Erdem, Nathaniel Cartwright, Karim Navarro, Liisa Babic, Tomas Deng, Carys Laurent, Lindiwe Baek, Jurgen. [nt-0001]
- **Now in build**, Feb 19 meeting recap; previously scoping. [mn-0010]
- **Agreed to limit pilot to five courses**, explicit worker decision Feb 18 (five also in baseline). No course names supplied. [ch-0054, nt-0001]
- Pilot course list moved from proposed Losa action Feb 10 to official Losa assignment Feb 11, then **Jurgen took over Feb 12 and sent it Feb 15**. [mn-0003, em-0020, ch-0028, em-0043]
- Delivery completed: API contract v1, retention confirmation with Liisa, acceptance criteria to Liisa, help-desk script to Liisa, comms plan to Andres Erdem, accessibility audit from Tomas to Karim, lessons-learned confirmation with Andres. See ledger for dated proof. [ch-0018, ch-0019, ch-0027, ch-0031, ch-0039, ch-0045, ch-0055, em-0067]
- **Liisa shared architecture diagram with Despina Feb 22**; contents not supplied. **Despina sent stakeholder map v1 to Andres Erdem Feb 22**, attachment retained. It is a generic working document, not a named stakeholder list: dependencies unconfirmed, training to be confirmed, council escalation and shared-component hosting unresolved. [ch-0066, em-0089, dc-0002]
- **Despina completed looking into Axolotl slow page loads Feb 23** after taking ownership Feb 22. This completes the investigation action, **not proof the latency was fixed**; no findings supplied. [mt-0008, em-0095]
- **Axolotl API contract v2 turned around Feb 23**, direct Despina report to Tomas. Contents absent. [em-0086, ch-0072]
- Feb 23 recap assigns Despina **send support model to Losa** and **send Axolotl timeline to Andres**; no due dates or deliveries. These are separate from Losa's support playbook and Fennel timeline-update possibility. [mn-0012]
- **Nathaniel needs Axolotl stakeholder map by Thu Feb 25**, Andres relays; worker thanks him, not explicit acceptance. Feb 22 soft send remains unfulfilled to Nathaniel; sending to Andres does not satisfy it. Karim also requests **Axolotl rollout checklist**, unanswered, no deadline. [mn-0011, em-0089, ch-0071, ch-0076]
- **Despina commits to walk Liisa through Axolotl decision memo**; Feb 25 14:00–14:30 Pacific invite sent, not proof walkthrough happened. Memo contents absent; distinct from AI-use decision memo. [ch-0068, ca-0010]
- Lindiwe can send Despina Axolotl access request; still only an offer, not known delivered. Distinct from Despina's Fennel access request draft to Andres. [mt-0008, em-0097]
- Still awaiting / not known complete: solution brief to Tomas; Lindiwe's status slide review; cutover plan to Andres; test plan to Liisa; tenant provisioning and vendor comparison from Liisa; requirements matrix from Karim; LMS integration notes from platform engineer (likely Carys). Losa owns support playbook and load test plan in Feb 19 recap. [em-0032, ch-0009, em-0046, mn-0009, ch-0044, em-0061, ch-0034, ch-0051, mn-0010]
- Change request: Losa working session Feb 17 agenda to send it; Losa said picking back up, not delivery. [ca-0008, ch-0049]
- Evaluation rubric from Losa remains **tentative**, not confirmed. Faculty survey from Andres **no longer needed** Feb 18; RACI chart from Andres **no longer needed** Feb 16. [em-0027, ch-0055, nt-0007]
- Feb 12 standup cancelled, not a cancellation of the project. [ca-0007]

## Fennel
Aliases: platform, common/shared platform, Fennel platform. Shared AI platform, owner **Liisa Babic**, sponsor **Aiko Venkataraman**, originally onboarding tenants; **now hardening Feb 23**, direct Liisa update. No dated overall target. [nt-0001, em-0091]
- **Tenant onboarding guide published Feb 19 by Liisa** after Feb 9 working-session invite and Feb 18 "moving again" update. [ca-0003, ch-0052, em-0077]
- Axolotl tenant: Feb 9 chat attributes provisioning to Despina, but **Liisa explicitly says she agreed to provision it** Feb 10; Liisa says back on Feb 16. Treat Liisa as operative owner; no provisioned/completed evidence. [ch-0013, em-0018, ch-0044]
- **Dorcliff SSO broker configured** by Carys, reported Feb 12. [ch-0024, mt-0004]
- **Model allow-list reviewed** by Despina Feb 15; Losa corroborates Feb 17. [em-0035, ch-0031, em-0062]
- Gateway rate limits: recap assigns setting to Carys, Despina starts testing Feb 16; ownership of setting versus testing should not be collapsed, no completion evidence. [mn-0007, ch-0046]
- Integration spec update after Andres's comments is **not agreed**, repeatedly through Feb 19. Timeline update after Nathaniel's comments **still not agreed Feb 22**. Andres's Fennel LMS integration notes review **not accepted yet** Feb 18. [nt-0005, nt-0006, em-0049, ch-0053, ch-0062, mt-0006, em-0066, mt-0009, ch-0058]
- Feb 22 Andres requests dependency-list review; no acceptance or list contents. Despina offers to send Andres Fennel access request and review his Fennel course roster export; acknowledged, not completion. **Feb 23 access-request email is explicitly a draft (X-Draft: true), attachment not yet added; not sent.** Access request is distinct from Lindiwe's Axolotl access request. [em-0083, ch-0069, em-0097]
- Andres requests **Fennel rollout checklist by Wed Feb 24**; Despina has not accepted/responded. Distinct from Karim's Axolotl rollout checklist. [ch-0078]

## Course Assistant Tool Selection
Aliases: course assistant bake-off, Linel/Zenia evaluation, CATS selection. University of Corrgate; competitors Linel Learning and Zenia Labs. Owner **Tariq Okeke**, sponsor **Aiko**, target **March 16**. People: Tariq, Andres Erdem, Karli Banda, Sipho Costa, Wei Rossi. [nt-0001]
- **Moving into contracting Feb 23**, explicit Tariq update supersedes procurement Feb 22 and scoring Feb 8–12. No selected vendor/winner, signed contract, purchase or completion supplied. [em-0006, em-0033, ch-0070, ch-0075]
- Despina committed Feb 9 to circulate scorecard, reminded Feb 12; no delivery evidence. [ch-0010, em-0031]
- Zenia customer references: Feb 9 Tariq identifies **Andres Garnier, Zenia account executive**, as collecting two; Feb 10 Wei shorthand "Andres" is ambiguous, not Andres Erdem by default. Feb 12 worker note says possible repeat collection **not confirmed**. No references delivered. [ch-0014, ch-0017, nt-0004]
- Sipho asks Despina to answer after-hours support question Feb 19; no response/acceptance yet; actual question detail not supplied. [em-0073]
- Feb 12 status risks: vendor answers outstanding; which vendors/answers not specified. [em-0033]

## Dorcliff Captioning Discovery
Aliases: Dorcliff discovery, captioning work, DCD discovery. Owner **Losa**, sponsor **Aiko**, target **March 9**; team Andres Erdem, Nathaniel, Karim. [nt-0001]
- **Pivot phase** Feb 10, next step **decide whether transcript intake becomes its own effort**, echoed Feb 12 status. It is not established that a separate project was approved. [ch-0020, em-0033]
- Despina offered to **scope two-week transcript intake sprint** Feb 11 recap (Axolotl standup context, substantively linked to discovery pivot). No output/approval evidence. [mn-0005]
- Nathaniel promised transcript intake wait-time export Feb 12 and captioning discovery findings summary Feb 19; neither known delivered. [ch-0029, ch-0065]
- **Captioning discovery test plan to Karim**: Feb 23 email requests it, same-day automatic Axolotl standup recap says Despina is picking it up and assigns send. No direct acceptance or delivery supplied; classify as recap-assigned. Separate from Axolotl test plan to Liisa. [em-0092, mn-0012]
- Despina requests **captioning discovery dashboard access from Liisa** Feb 23; no acceptance or setup evidence. [em-0094]
- **Liisa fixed captioning discovery stale cache Feb 23 17:52**, after 13:33 promise; Despina thanks her. This does not establish dashboard access, project completion or resolution of Axolotl latency. [ch-0073, ch-0077]
- Feb 9 site visit had no new captured actions. [mn-0002]

## Linel Enterprise Agreement
Aliases: Linel deal/renewal. Single Linel agreement for all campuses instead of campus-by-campus deals. Owner **Wei Rossi**, sponsor **Aiko**, original target **March 10**. [nt-0001]
- **Signed and complete Feb 16**, Wei direct update; worker Feb 19 status confirms complete. Contract terms, actual signed document, volume-tier details are not supplied. [ch-0033, ch-0041, em-0079]
- Sipho sending volume tiers was **never agreed**, per Feb 8–10 messages. Agreement completion does not establish this separate material was sent. [ch-0005, ch-0006, ch-0008, em-0009, em-0014]

## Lanhurst Responsible AI Use Framework
Aliases: AI framework, framework, responsible-use framework. Owner **Despina**, sponsor **Aiko**, target **March 22**, team Andres Erdem, Tariq, Karli. [nt-0001]
- **Consultation** since Feb 15, formerly drafting. [ch-0032]
- **Decision Feb 22: use approach A for the AI-use glossary.** Worker note does not define approach A, alternatives or rationale; do not invent them. [nt-0008]
- AI-use risk taxonomy requested from Andres Erdem Feb 11; **sent Feb 18**. [mn-0006, ch-0059]
- Despina committed to send Andres AI-use comment log Feb 16, reconfirmed Feb 18; not known sent. [ch-0047, ch-0056]
- Review Andres's AI-use decision memo **not accepted** ("I'll think about it" transcript Feb 17). [mn-0008, mt-0007]
- **Despina commits to send Andres AI-use consultation plan** in Feb 23 1:1; no deadline or delivery. Nearby blocker discussion says depends on other teams; Despina expects Finance to have views, not confirmed Finance input. [mt-0011]

## Fennel Operating Model Review
Aliases: operating model review, ops model draft, Fennel operating model. Owner **Liisa**, sponsor **Aiko**, participants Andres Erdem, Losa, no target supplied. [nt-0001]
- **Done Feb 22**, direct Liisa update, acknowledged by Despina; supersedes revision Feb 8. This closes the project, not proof of every earlier document delivery or meeting. No final operating-model contents supplied. [nt-0002, ch-0067]
- Historical unverified subitems, no longer active project chasing absent renewed request: Liisa's draft v3 delivery; review-session booking (offered Feb 10, back on Feb 17); Losa's review comments. No individual completion evidence. [em-0015, mt-0002, em-0053, ch-0030]
- Review Andres Erdem's summary of changes was **tentative**; comparison table **requested**, not accepted/sent. No renewed requirement after project completion. [mt-0005, em-0059, ch-0067]

## Thesis Formatting Input Round
Aliases: thesis formatting input/round. Owner **Despina**, sponsor **Aiko**; collecting campus input, Andres Erdem and Leila Dang involved, Norstead State College. No overall target. [nt-0001]
- Leila working session invited Feb 16 09:00–09:45 Pacific; invite alone proves no input delivery. [ca-0005]
- Norstead input **requested by Friday Feb 19 but not agreed Feb 15**. Leila subsequently commits via forward Feb 18 to send it "again"; no received input proof. Friday date is requested deadline, not explicitly reaccepted in forward. [ch-0037, em-0072]
- Rosalind's thesis-formatting panel invitation relayed by Haruto: Despina deferred, no acceptance. [ch-0035]

## Glencombe Partnership
Owner **Despina**, sponsor **Aiko**; ongoing relationship/introductions/catch-ups/favours with Glencombe Center for Digital Pedagogy, Losa and Andres Erdem. No later explicit stage update. [nt-0001]
- Related cross-portfolio favours: Tomas's syllabus panel joined, Milena introduced to Oluwaseun for alumni outreach, research-computing reading list sent to Oluwaseun. Do not infer these constitute formal Glencombe milestones. [em-0040, ch-0050, em-0069]
- Feb 23 Despina **offers** a reference note for Lindiwe's alumni outreach fellowship application and to introduce Liisa to "Andres" for research computing. Neither known done; introduction target identity uncertain (transcript conversation itself is with Andres Erdem). These are not confirmed formal Glencombe milestones. [mt-0011]
- Oluwaseun ("Seun", @oluwaseun) promises Despina **lab safety training session notes**; not delivered, session identity unspecified. Keep distinct from Friederike's research-computing session notes and from formal Axolotl milestones. [ch-0074]

## Norstead Admissions Triage Idea
Owner **Leila Dang**, sponsor **Aiko**, placeholder waiting on a problem statement. Despina already asked Leila for it at baseline; **still no later evidence of delivery/activity**. [nt-0001]

## Linel Alumni Outreach Diligence
Aliases Linel deep dive/alumni outreach diligence. Owner **Despina**, sponsor **Aiko**; stalled in baseline, waiting on **Sipho's Linel deep-dive materials**. No later explicit project stage or material delivery. Milena/Oluwaseun alumni outreach intro completed, but no evidence it revives the Linel diligence itself. [nt-0001, em-0056, ch-0050]

## Room Booking Learning Series
Aliases learning series/room booking talks. Faculty series with Glencombe, owner **Andres Erdem**, sponsor **Aiko**, Haruto involved; Calderhaven/Glencombe. Baseline quiet, no sessions. [nt-0001]
- **Revived Feb 19**, direct Andres update. No session dates/content supplied; unrelated booking confirmations must not be treated as series sessions. [ch-0061]

## Leadership reporting and risks
- Friday status notes to Aiko due EOD Feb 12 and Feb 19; both **sent on respective dates**, 15:51 and 16:43 Pacific; Feb 22 recap corroborates Feb 19 send, not a new obligation. **Next note due EOD Friday Feb 26**, half page covering movement, slips and leadership needs; no send evidence yet. [em-0002, ch-0003, ch-0021, em-0033, em-0037, em-0079, mt-0010, em-0081]
- Feb 12: discovery next-step decision, CATS scoring, vendor answers outstanding. [em-0033]
- Feb 19: syllabus panel joined, Milena/Oluwaseun introduction completed, Linel agreement complete; "timelines on the flagship are tight". **Flagship not explicitly identified**, no precise slip/new target supplied. [em-0079]
