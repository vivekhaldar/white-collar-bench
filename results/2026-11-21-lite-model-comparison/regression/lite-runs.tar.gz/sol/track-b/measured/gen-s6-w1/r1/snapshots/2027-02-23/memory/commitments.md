# Commitment ledger — current through 2027-02-23

Unless stated, **no due date is supplied**. Open means no completion/cancellation evidence in available inputs. Requests, offers and tentative ideas are distinguished from agreed work. IDs point into the dated evidence files via artifacts.json.

## Despina's open committed / assigned work
| Item | Recipient / collaborator | Evidence and confidence |
|---|---|---|
| Send Axolotl solution brief | Tomas Deng | Offer Feb 8 ch-0001; assigned recap Feb 9 mn-0001; Tomas Feb 12 em-0032 calls it an offer. No send evidence. Track open offered/assigned work, not stronger explicit acceptance. |
| Circulate course assistant selection scorecard | Tariq / selection participants | Despina "sure, can do" Feb 9 ch-0010; Feb 12 em-0031 reminder. |
| Scope two-week transcript intake sprint | No explicit recipient | Feb 11 mn-0005 recap: worker offered/action assigned. Two weeks is sprint scope, not an explicit delivery deadline. |
| Send Axolotl cutover plan | Andres Erdem | Despina "will send" Feb 16 em-0046; same-day request em-0048. |
| Send AI-use comment log | Andres Erdem | Accepted Feb 16 ch-0047; reconfirmed Feb 18 ch-0056. |
| Send Axolotl test plan | Liisa Babic | Feb 18 mn-0009 auto recap records worker offer/action; no sent proof. |
| Test gateway rate limits for Fennel tenants | Carys Laurent | Feb 16 ch-0046 worker starts testing; setting rate limits assigned to Carys in mn-0007. No completion known. |
| Send captioning discovery test plan | Karim Navarro | em-0092 Feb 23 request; mn-0012 automatic recap says worker picking it up/action assigned. No direct worker acceptance or delivery; not the Axolotl test plan. |
| Send Axolotl support model | Losa Moretti | mn-0012 Feb 23 automatic recap assigns worker send. No direct acceptance/delivery. Not Losa's support playbook. |
| Send Axolotl timeline | Andres Erdem | mn-0012 Feb 23 automatic recap assigns worker send. No direct acceptance/delivery. Not Fennel timeline update. |
| Send AI-use consultation plan | Andres Erdem | mt-0011 Feb 23 explicit worker "Let me send you"; thanked; no delivery. |
| Walk Liisa through Axolotl decision memo | Liisa Babic | Feb 22 ch-0068 explicit promise; ca-0010 invite for **Feb 25 14:00–14:30 Pacific**. Invitation sent, walkthrough not known done. |
| Send Friday status note w/e Feb 26 | Aiko Venkataraman | em-0081 weekly reporting reminder: **EOD Friday Feb 26**; half page on movement, slips, leadership needs. No delivery or extension known. |

## Incoming / other people's open commitments
| Owner | Item | Evidence / progression |
|---|---|---|
| Liisa Babic | Provision Axolotl tenant on Fennel | Feb 9 ch-0013 says Despina will do it; Feb 10 em-0018 Liisa explicitly agrees herself; Feb 16 ch-0044 "back on". Operative owner Liisa, not completed. |
| Liisa | Share Axolotl vendor comparison with Despina | Feb 17 em-0061 "I will share". |
| Losa Moretti | Send Axolotl change request to Despina | Feb 16 ca-0008 working-session agenda Feb 17; Feb 17 ch-0049 picking back up. Invite agenda alone is weaker than delivery/acceptance. |
| Losa | Write Axolotl support playbook | Feb 19 mn-0010 recap, action assignment. "Has it" means owns action, not written. |
| Losa | Draft Axolotl load test plan | Feb 19 mn-0010 recap, offer/action. |
| Karim Navarro | Send Axolotl requirements matrix to Despina | Feb 15 ch-0034 Lindiwe relays assignment. |
| Platform engineer (likely Carys Laurent) | Share Axolotl LMS integration notes with Despina | Feb 18 ch-0051 Andres relays by role; nt-0001 identifies Carys as platform engineer. Identity inferred, not directly named here. Distinct from Andres's Fennel LMS notes review. |
| Nathaniel Cartwright | Send transcript intake wait-time export to Despina | Feb 12 ch-0029 explicit promise. |
| Nathaniel | Share captioning discovery findings summary with Despina | Feb 19 ch-0065 "will share ... with you". Do not read @despina as owner. |
| Carys Laurent | Set gateway rate limits for Fennel tenants | Feb 16 mn-0007 recap assignment; Despina testing ch-0046 not proof Carys completed setting. |
| Friederike Agyeman | Send research computing session notes to Despina | Feb 11 em-0024 forward of explicit promise; Feb 15 ch-0038 back on. Not the reading-list attachment (dc-0001). |
| Leila Dang | Send Norstead thesis-formatting input to Despina again | Feb 15 ch-0037 request by Friday Feb 19 not agreed; Feb 18 em-0072 forward now promises sending again. No received input. Requested date has not explicitly been reaccepted. |
| Oluwaseun Demir (Seun) | Send lab safety training session notes to Despina | ch-0074 Feb 23 explicit promise, thanked; no send. Session not identified; distinct from Friederike's research-computing notes. |
| Andres Garnier (Zenia account executive) | Collect two Zenia customer references | Feb 9 ch-0014 Tariq relays assignment; Feb 10 ch-0017 Wei says "Andres". Feb 12 nt-0004 says possible repeat collection not confirmed. Original relayed assignment remains not known complete; repeat is only tentative. |

## Requests / possibilities — do not treat as accepted commitments
| Possible owner | Item | Last evidence / status |
|---|---|---|
| Despina | Review Lindiwe's Axolotl status slide | ch-0009 Feb 9; request unanswered by worker. |
| Despina | Answer Sipho's after-hours support question on CATS | em-0073 Feb 19; request only. Question's actual specifics absent. |
| Despina | Update Fennel integration spec after Andres Erdem's comments | nt-0005 Feb 15 maybe; nt-0006, em-0049 Feb 16 not agreed; ch-0053 Feb 18 "maybe"; ch-0062 Feb 19 still not agreed. |
| Despina | Update Fennel timeline after Nathaniel's comments | mt-0006 Feb 17 maybe; em-0066 Feb 18 not agreed; mt-0009 Feb 22 explicitly still nothing agreed. |
| Despina | Review Andres's Fennel dependency list | em-0083 Feb 22 request only; no list contents provided. |
| Despina | Send Fennel access request to Andres Erdem | ch-0069 Feb 22 offer acknowledged; em-0097 Feb 23 **unsent draft, X-Draft: true, attachment not yet added**. Not delivered; contents of actual request unknown. Distinct from Lindiwe's Axolotl access request. |
| Despina | Review Andres Erdem's Fennel course roster export | ch-0069 Feb 22 "i can review" offer, thanked; not reviewed in evidence. |
| Despina | Send Axolotl stakeholder map to Nathaniel | mn-0011 Feb 22 soft; ch-0071 Feb 23 Andres relays need **by Thu Feb 25**. Worker thanks him, not explicit acceptance. Not completed by send to Andres em-0089. |
| Despina | Send Axolotl rollout checklist | ch-0076 Feb 23 Karim request only; no deadline/acceptance. Distinct from Fennel checklist. |
| Despina | Send Fennel rollout checklist to Andres | ch-0078 Feb 23 @andres request **by Wed Feb 24**; no worker response/acceptance. Likely Andres Erdem per role/handle; not Zenia's Garnier. |
| Liisa | Set up captioning discovery dashboard access for Despina | em-0094 Feb 23 worker request; no Liisa acceptance/setup. Cache fix does not establish access. |
| Despina | Write reference note for Lindiwe's alumni outreach fellowship application | mt-0011 Feb 23 "I could ... if that's useful" offer; no completion, due date or application details. Transcript "Lin diwe" likely Lindiwe Baek. |
| Despina | Introduce Liisa to Andres for research computing | mt-0011 Feb 23 "I can introduce" offer; no introduction proof. Target surname not given; conversation is with Andres Erdem but target identity unresolved. |
| Lindiwe Baek | Send Axolotl access request to Despina | mt-0008 Feb 22 "I can send" offer; not known sent. |
| Despina | Review Andres's AI-use decision memo | mn-0008 suggested; mt-0007 Feb 17 request and "I'll think about it"; not accepted. |
| Despina | Review Andres's Fennel LMS integration notes | ch-0058 Feb 18 "let me check and get back to you". |
| Despina | Join Rosalind's thesis-formatting panel | ch-0035 Feb 15 Haruto relay; worker "can I come back to you". No full identity/date of Rosalind. |
| Losa | Send Axolotl evaluation rubric to Despina | em-0027 Feb 12 "might", nothing confirmed. |
| Sipho Costa | Send Linel volume tiers to Despina | ch-0005, ch-0006, ch-0008 Feb 8: could/happy to/not agreed; em-0009 Feb 9 and em-0014 Feb 10 explicitly not agreed. Repeated mentions do not create agreement. |
| Andres Garnier | Collect Zenia references again | nt-0004 Feb 12 possible, not confirmed; separate from Feb 9 relayed original assignment. |

## Baseline long-running waits, no later updates
- **Leila Dang → Despina:** admissions triage problem statement already requested; waiting, no receipt or confirmed promise recorded. [nt-0001]
- **Sipho Costa → Despina:** Linel deep-dive materials for alumni outreach diligence; waiting, no receipt recorded. Not the volume tiers. [nt-0001]

## Completed / delivered (do not keep chasing)
| Date (2027) | Item and responsible person | Evidence |
|---|---|---|
| Feb 10 12:49 Pacific | Despina confirmed Axolotl retention schedule with Liisa | ch-0016 request → ch-0018 done. Actual retention terms absent. |
| Feb 10 13:35 | Despina wrote Axolotl API contract v1 | em-0010 request → ch-0019 wrote. Contract contents absent. |
| Feb 11 21:01 | Despina sent Axolotl acceptance criteria to Liisa (earlier joint promise with Andres) | ch-0026 promise → ch-0027 sent, acknowledged. Actual criteria absent. |
| Feb 12 | Carys configured Dorcliff Fennel SSO broker | ch-0024 promise → mt-0004 first-person report. |
| Feb 12 15:51 | Despina sent Aiko Friday status note w/e Feb 12 | em-0002/ch-0003 due/accepted, ch-0021 reminder → em-0033 actual email. |
| Feb 15 morning | Despina reviewed Fennel model allow-list | em-0035 promise → ch-0031 completed; em-0062 later corroboration. |
| Feb 15 09:33:53 | Despina sent Liisa Axolotl help-desk script | em-0030 request → ch-0031 sent. |
| Feb 15 12:35 email | Despina joined Tomas's syllabus-review panel | mt-0003 offer/mn-0004 suggestion → nt-0003 Feb 11 acceptance → em-0040 joined; em-0079 confirms. No panel content/date details beyond report. |
| Feb 15 16:27 | Despina sent Andres Erdem Axolotl comms plan | em-0041 request → ch-0039 sent/acknowledged; ch-0042, ch-0060 later recaps same event, not new obligations. |
| Feb 15 17:31 | Jurgen sent Despina Axolotl pilot course list | mn-0003 suggested Losa → em-0020 official Losa → ch-0028 handoff Jurgen → em-0043 sending. No list contents supplied. |
| Feb 16 | Wei reports Linel Enterprise Agreement signed and complete | ch-0033 contract review Feb 15 → ch-0041 signed/complete; em-0079 corroborates. |
| Feb 16 15:34 report | Tomas sent Karim Axolotl accessibility audit earlier that day | mn-0007 assignment → ch-0045 sent. Audit findings absent. |
| Feb 17 earlier than 16:26 | Despina introduced Milena to Oluwaseun for alumni outreach | em-0056 request → ch-0050 completed/acknowledged; em-0079 confirms. |
| Feb 18 12:58 | Despina confirmed Axolotl lessons-learned note with Andres | mn-0009 action → ch-0055 confirmed; em-0067 received. Note content absent. |
| Feb 18 14:11 | Despina sent Oluwaseun research-computing reading list | ch-0048 expectation → em-0069 sending, attachment dc-0001. Attachment is a final-version tracker, not substantive bibliography. |
| Feb 18 17:46 | Andres Erdem sent Despina AI-use risk taxonomy | mn-0006 request → ch-0059 sent. Taxonomy content absent. |
| Feb 19 14:14 email | Liisa published Fennel tenant onboarding guide | ca-0003 agenda → ch-0052 moving again → em-0077 published. Guide contents absent. |
| Feb 19 16:43 | Despina sent Aiko Friday status note w/e Feb 19 | em-0037 reminder → em-0079 actual note; mt-0010 Feb 22 recap confirms same send. |
| Feb 22 09:17 report | Liisa shared Axolotl architecture diagram with Despina | em-0042 agreement → em-0054 back on → ch-0066 done, acknowledged. Diagram contents absent. |
| Feb 22 11:30 report | Liisa reports Fennel Operating Model Review done | ch-0067 direct project completion, acknowledged; not proof all historical subitems were delivered. |
| Feb 22 18:21 | Despina sent Andres Erdem Axolotl stakeholder map v1 | ch-0069 offer acknowledged → em-0089 sending with dc-0002 attached. Does **not** establish delivery to Nathaniel. |
| Feb 23 10:13 report | Despina turned around Axolotl API contract v2 for Tomas | em-0086 offer → ch-0072 direct done report. Contents not supplied; distinct from v1. |
| Feb 23 14:31 | Despina looked into Axolotl slow page loads | mt-0008 ownership → em-0095 direct done report. **Investigation complete; no claim the underlying problem was fixed or findings supplied.** |
| Feb 23 17:52:15 report | Liisa fixed captioning discovery stale cache | ch-0073 13:33 promise → ch-0077 just fixed, worker thanked. Does not establish dashboard access or Axolotl latency fix. |

## Cancelled / no longer needed
- Axolotl **RACI chart from Andres**: tentative Feb 15 nt-0005; worker Feb 16 says no longer needed nt-0007. No send needed.
- Axolotl **faculty survey from Andres**: Feb 15 ch-0036 not agreed; worker Feb 18 cancels need ch-0055. No send needed.
- Feb 12 09:30–09:55 Pacific **Axolotl standup cancelled** ca-0007; applies to this occurrence only, not project or other meetings.

## Closed project — individual historical subitems unverified
**Fennel Operating Model Review is done Feb 22 [ch-0067].** Remove these from active project chasing, but do not call each completed:
- Liisa sending draft v3 [em-0015]: no actual draft retained.
- Liisa booking review session [mt-0002, em-0053]: no booking date or session-held proof.
- Losa sharing review comments [ch-0030]: no delivery proof.
- Despina reviewing Andres's summary of changes [mt-0005]: tentative only.
- Despina sending Andres comparison table [em-0059]: request only.

## Attachment details and boundaries
**dc-0001** (Feb 18, accompanying em-0069) is titled Reading list on research computing (final), sheet Tracker, version final, OAT, prepared by Despina. Rows: 01 Documentation—in review/new this version; 02 Testing—done; 03 Integration—not started/carried over; 04 Accessibility review—not started/waiting on another team; 05 Sign-off—not started/waiting on another team. This establishes the **document's** tracker state, not completion states of Axolotl/Fennel generally. It contains no actual reading citations. Other promised documents' contents remain unknown unless explicitly retained below.

**dc-0002** (Feb 22, attached to em-0089) is **Axolotl stakeholder map v1**, prepared by Despina, dated Feb 22. Actual document retained in `memory/dc-0002.md`. Summary: scope unchanged from previous version (previous version not supplied); other-team dependencies noted but unconfirmed; terminology follows shared glossary. Table: Support—agreed at last review; Training—to be confirmed; Costs—aligned with shared glossary; Data—unchanged from previous version. Open questions: whether it needs to go to council; which unit hosts shared components. No named stakeholders, actual costs, host identity or council decision supplied. These are document assertions, not independently verified project-wide completion states.
