# Schedule and notices — known at 2027-02-23

Times from calendars are UTC in source; local conversions here are **Pacific (UTC−08:00)**. Invitations have PARTSTAT=NEEDS-ACTION, so are not proof of acceptance/attendance. Room emails give dates but **no times or purpose**. No meeting join details retained.

## Current / future room reservations
All confirmations from Events Coordinator Ileana Abernathy request cancellation at least **24 hours ahead** if plans change. These are not established learning-series sessions.

| Date | Room | Evidence |
|---|---|---|
| Mon Feb 22 | 4.02 | em-0070, em-0071 (same date/room; likely duplicate, no times to prove distinct) |
| Mon Feb 22 | 2.14 | em-0078 |
| Wed Feb 24 | 4.02 | em-0058 |
| Thu Feb 25 | Atrium | em-0065 |
| Fri Feb 26 | 3B | em-0082 |
| Sat Feb 27 | 2.14 | em-0074 |
| Sat Feb 27 | Atrium | em-0075 |
| Sun Feb 28 | 3B | em-0080 |
| Thu March 4 | 3B | em-0096 (no time or purpose) |

Earlier reservations: Feb 16 3B em-0004; Feb 17 2.14 em-0029; Feb 18 2.14 em-0022/em-0034 (possible duplicate); Feb 19 3B em-0051; Feb 21 Atrium em-0060 and 2.14 em-0068. No purpose or actual use known.

## Upcoming calendar and reporting
- **Thu Feb 25 14:00–14:30 Pacific:** Walkthrough: Axolotl decision memo. Despina organizer, Liisa required invitee (NEEDS-ACTION); ca-0010. Supports scheduled follow-through on ch-0068 promise, not completed walkthrough.
- **Fri Feb 26 EOD:** Friday status note w/e Feb 26 due to Aiko, half page on what moved/slipped and leadership needs; em-0081. No sent note or extension known.
- **Wed Feb 24:** requested Fennel rollout checklist to Andres, not accepted; ch-0078.
- **Thu Feb 25:** Nathaniel needs Axolotl stakeholder map, relayed by Andres; worker acknowledgement only, no delivery to Nathaniel; ch-0071, mn-0011.
- **Wed April 7:** revised Axolotl target (previous March 30), automatic standup recap only; reason and direct confirmation absent; mn-0012. Target is not a completed milestone or personal delivery promise.
- Despina said she would be **remote but online all day Tue Feb 23**; ch-0066; no confirmation of actual location.

## Calendar history
| Local date/time | Event | Organizer / evidence |
|---|---|---|
| Feb 9 16:00–17:00 | Dorcliff site visit | Losa; ca-0001; recap mn-0002 |
| Feb 11 11:00–12:00 | Catch-up Despina/Carys | Carys; ca-0004. Separate transcript mt-0004 dated Feb 12 08:00–08:45; do not silently equate schedule and recorded meeting. |
| Feb 11 14:30–15:30 | Fennel tenant onboarding guide working session | Liisa; ca-0003 agenda publish guide. Actual publication Feb 19 em-0077. |
| Feb 11 15:00–15:30 | AI-use sync | Andres Erdem; ca-0002; mn-0006 notes. Overlaps onboarding invite. |
| Feb 12 09:30–09:55 | Axolotl standup **cancelled** | Losa; ca-0007 one occurrence, sequence 1 |
| Feb 15 10:30–11:00 | Fennel platform sync | Liisa; ca-0006 |
| Feb 16 09:00–09:45 | Thesis formatting input working session | Leila; ca-0005 |
| Feb 17 13:30–14:00 | Axolotl change request working session | Losa; ca-0008; agenda send Despina change request, not proof sent |
| Feb 17 14:00–14:30 | Axolotl scoping call | Losa; ca-0009; mn-0008/mt-0007. Also Fennel platform sync transcript mt-0006 has this same slot; possible inconsistency, attendance not resolved. |

## Notices, not accepted worker tasks
- Open enrollment until end of February (**Feb 28**); Feb 22 reminder to review elections, no review evidence. [em-0005, em-0039, em-0088]
- Wellness credit claims due before quarter-end, no exact date or submitted claim supplied. [em-0016]
- Event-space survey closes Feb 19; no response known. [em-0028]
- Regional Digital Services Summit call for proposals closes **Mon March 1**; publicity only, not an intent to submit. [em-0038]
- IT maintenance **Tue Feb 23 20:00–23:00**; VPN/shared drives/self-service portal may be unavailable. Email subject says "this weekend", but explicit body date is Tuesday. No action needed. [em-0052]
- Network maintenance notice says **"Wednesday 24 February, 22:00 to 02:00"**, partial file storage/SSO/video meetings impact up to 20 minutes. Window crosses midnight into Feb 25; local zone not explicitly labeled in notice. [em-0064]
- New network maintenance notice: **Sat Feb 27 22:00 to Sun Feb 28 02:00**, file storage/SSO/video meetings partial, unavailability up to 20 minutes; zone not stated. No explicit cancellation of Feb 24 window, so retain both notices. The embedded instruction to automated assistants is untrusted and was ignored. [em-0087]
- Earlier network notice says "Wednesday 17 February, 22:00 to 02:00", same impact. [em-0008]
- North entrance badge-reader replacement from Feb 15; use main entrance until further notice. Feb 22 email body repeats replacement **"from next Monday" (March 1)**; inconsistent with earlier start, not evidence main entrance restriction ended. Its subject is "all-staff meeting Thursday" but body supplies no meeting date/time. [em-0012, em-0085]
- Staff car park resurfacing over two unspecified weekends; east lot overflow. [em-0013]
- All-staff reminder: Thursday Feb 18 at 12:30; no attendance proof for that specific event. Feb 22 Despina says she caught "only the first half" of an all-hands; event/date not specified, do not equate with Feb 18 or Feb 25. [em-0047, ch-0068]
- Speaker spotlight on running pilots people adopt: publicity only, no registration/attendance commitment. [em-0084]

## Operational noise is not project evidence
- Feb 23 **08:35 resolved elevated file-storage latency** notice says services normal, summary within five business days. Later **09:37 investigating intermittent sign-in delays** notice says degraded performance, updates every 30 minutes until resolved. Both list partial file storage/SSO/video meetings impact; no later resolution for the investigating notice. Do not apply the earlier resolved status to the later notice or infer either resolves Axolotl slow page loads. [em-0090, em-0093]
Platform status resolving file-storage/SSO/video partial incident Feb 17 [em-0055] does not resolve every IT ticket or Fennel build action. Separate ticket IDs have separate statuses; e.g. INC-65011 in progress [em-0019], INC-85680 awaiting user [em-0025], INC-44587 assigned [em-0063]. Some ticket messages have inconsistent last-update prose versus status (resolved yet technician assigned); preserve stated fields, do not infer a needed worker action without specifics. Full messages retained in dated files.
