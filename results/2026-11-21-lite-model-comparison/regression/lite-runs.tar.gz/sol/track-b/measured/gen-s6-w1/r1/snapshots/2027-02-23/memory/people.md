# People and identity resolution

Roles below come from worker's portfolio map **nt-0001**, unless otherwise cited.

| Person | Role / organization | Context |
|---|---|---|
| Despina Pereira (@despina) | Worker; Office of Academic Technology, Lanhurst University System | Owns AI-use framework, Glencombe partnership, thesis input round, Linel alumni diligence. Email authorship and nt-0001 identify "me". |
| Aiko Venkataraman (@aiko) | Associate Provost for Academic Technology, OAT | Sponsor of all listed projects except Axolotl; receives Friday notes. |
| Andres Erdem (@andres; often "Andres") | Head of Learning Services, OAT | Learning-series owner; broad collaborator. Do not confuse with Zenia's Andres Garnier. |
| Losa Moretti (@losa) | Director, Teaching & Learning Technology, Dorcliff State College | Owns Axolotl and captioning discovery. |
| Jurgen Dvorak (@jurgen) | Chief Information Officer, Dorcliff State College | Axolotl sponsor; took pilot-course-list handoff from Losa. |
| Nathaniel Cartwright (@nathaniel) | Site Reliability Engineer, Dorcliff State College | Transcript-intake export and captioning findings; Fennel timeline comments. |
| Karim Navarro (@karim) | Instructional Designer, Dorcliff State College | Axolotl requirements matrix; audit recipient. |
| Liisa Babic (@liisa) | Lead, Cloud Platforms, OAT | Owns Fennel; operating model review reported done Feb 22 ch-0067. Shared Axolotl architecture diagram ch-0066; decision-memo walkthrough invitee ch-0068/ca-0010. |
| Tomas Deng (@tomas) | Information Security Manager, OAT | Solution brief recipient, accessibility audit sender, syllabus-review panel. |
| Carys Laurent (@carys) | Platform Engineer, OAT | Dorcliff SSO broker; gateway limits; likely unnamed platform engineer sharing Axolotl LMS integration notes (ch-0051), but inferred. |
| Lindiwe Baek (@lindiwe) | Product Owner, Student Systems, OAT | Requested status slide review, relayed Karim requirements matrix. |
| Tariq Okeke (@tariq; "Tariq") | Director of Institutional Research, University of Corrgate | CATS owner; scorecard requester and framework consultation update. |
| Karli Banda (@karli) | Instructional Designer, University of Corrgate | CATS/framework collaborator. |
| Sipho Costa (@sipho) | Account Executive, Linel Learning | Volume-tier offer, deep-dive materials wait, after-hours support question. |
| Wei Rossi (@wei) | Procurement Officer, System Procurement, Lanhurst University System | Linel agreement owner, signed/complete report. |
| Leila Dang (@leila) | Registrar, Norstead State College | Admissions triage owner; thesis input contact. |
| Haruto Vaughan (@haruto) | Dean of Libraries, Calderhaven University | Learning-series collaborator; relayed Rosalind panel invitation. |
| Andres Garnier | Account Executive, Zenia | Tariq explicitly identifies full name/employer in ch-0014. Zenia two customer references. Wei's ch-0017 shorthand "Andres" insufficient to reassign to Erdem. |
| Friederike Agyeman | Calderhaven University; role unknown | Research-computing session notes promised em-0024, resumed ch-0038; mn-0010 attendee. |
| Katerina Teixeira | Calderhaven University; role unknown | Feb 10 catch-up mn-0004/mt-0003. Recap includes Tomas but transcript attendee list does not; do not assert his attendance as certain. |
| Oluwaseun Demir | Lanhurst email affiliation; job title unknown | Named recipient em-0069, reading list; Milena introduction ch-0050, alumni outreach. **"Seun" / @oluwaseun** in ch-0074 promises lab safety session notes. Do not infer department/role. |
| Milena Mayfield | Norstead State College email affiliation; role unknown | Alumni introduction request em-0056; Leila thesis input forward em-0072. |
| Rosalind | Surname, role, organization unknown | Thesis-formatting panel invitation via Haruto ch-0035; worker deferred. |
| Ileana Abernathy | Events Coordinator | Booking confirmations (em-0004 and others). |
| Efua Dubois | Conference Organizer | Summit publicity/CFP em-0038; no worker commitment to submit. |
| Mpho Figueroa | Newsletter sender; role unknown | Campus Systems Weekly em-0050. |

## Organization aliases
- **OAT** = Office of Academic Technology; worker's team within **Lanhurst University System**. [nt-0001]
- **Dorcliff** = Dorcliff State College; lab safety and captioning work. [nt-0001]
- **Corrgate** = University of Corrgate; course assistant selection. [nt-0001]
- **Norstead** = Norstead State College; thesis input and admissions idea. [nt-0001]
- **Calderhaven** = Calderhaven University; Haruto, Katerina, Friederike affiliations. [nt-0001, mt-0003, em-0024]
- **Glencombe** = Glencombe Center for Digital Pedagogy. [nt-0001]
- **Linel** = Linel Learning; **Zenia** = Zenia Labs. [nt-0001]

## Other ambiguous phrasing
- AI-use comment log reminders in ch-0047 and ch-0056 refer to the same Tuesday commitment to send Andres the log: one open action, not multiple sends.
- "Andres's comments" in Fennel spec requests refers to Andres Erdem, corroborated by ch-0062; not Zenia's Andres.
- Meeting titles may mix projects (e.g. AI-use decision memo in Axolotl scoping call). Classify the action by subject, not meeting title.
- Automatic transcripts explicitly warn speaker names/spellings may be inaccurate; surname-free references require supporting context.
- Feb 22 ch-0069 labels the correspondent only "Andres" / @andres; manifest names Andres Erdem, and em-0089 explicitly sends the same Axolotl stakeholder map to **Andres Erdem**. Fennel access request / course roster export offers in that DM belong to Erdem, not Zenia's Garnier.
- mn-0011's "our learning services head" is likely Andres Erdem by nt-0001 role; standup note does not spell out the name. Its soft map send is to Nathaniel, distinct from the explicit Andres send in em-0089.
- mt-0008 transcribes "Des pina" as recipient of Lindiwe's access request; context resolves this to Despina, not another person.
- Feb 23 mt-0011 "Lin diwe" likely refers to Lindiwe Baek, proposed reference-note beneficiary; application details absent. The proposed Liisa introduction is to "Andres" without surname: transcript's interlocutor is Andres Erdem, but it is unclear whether he is also the introduction target. Do not silently identify target as Erdem or Garnier.
- Feb 23 ch-0071 and ch-0078 use "Andres" / @andres on Axolotl/Fennel core channels; likely Andres Erdem given role and previous handle usage, not Zenia's account executive. No new full-name statement in those two chats.
