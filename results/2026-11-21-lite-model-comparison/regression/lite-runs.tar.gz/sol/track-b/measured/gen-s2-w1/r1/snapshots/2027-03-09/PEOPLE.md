# People and organizations

## Worker and core roles
Worker is **Dina Ricci**, Vercliff Digital Service (DS), City of Vercliff. Her exact formal job title is not supplied. She owns pothole selection, Fennel funding model, Talton relationship and Marmara code-enforcement diligence; owns workshop slides (`nt-0001`, email sender/recipient records).

Roles below are explicit in `nt-0001` unless another ID is given.

| Person / aliases | Role / organization | Relevant relationship or responsibility |
|---|---|---|
| Imani Navarro; Imani, Imany, @imani; 'delivery director' / 'our delivery director' | Director of Delivery, Vercliff DS | Workshop owner; reported workshop complete and new AI in public service Peer Network follow-on (em-0086; network owner not explicit); funding-model cost model sent (em-0097), status slide (mt-0018), chargeback scenarios (nt-0010) and Fennel help-desk script (ch-0084) pending; metrics-definition review requester (em-0100); **not Imani Quaye @imaniq**; Fennel onboarding guide owner after Cassandra handoff (em-0026); test-plan, records discovery confirmations; permit-intake intro to Tendai (ch-0038). mt-0011's delivery-director reference resolves to Imani, who responds. |
| Kayode Whitfield; Kayode, @kayode | Chief Digital Officer, Vercliff DS | Sponsor of most portfolio work except Mistral/pothole selection; weekly leadership status recipient (em-0037, em-0074); funding memo recipient (ch-0064). |
| Cassandra Yilmaz; Cassandra, @cassandra; 'platform lead' | Principal, Platform Engineering, Vercliff DS | Fennel owner; Mistral tenant provisioner; transferred guide to Imani (em-0026, ch-0024); allow-list/accessibility review counterpart; promised Fennel architecture diagram (mt-0018), Mistral equity-review walkthrough invitee (ca-0009). |
| Thibault Sahin; Thibault, @thibault | Platform Engineer, Vercliff DS | Fennel SSO broker and tenant rate limits (em-0016, ch-0050); Mistral decision memo reassigned to him (em-0068); Dina accepted sending him Mistral vendor comparison via Naoko (ch-0077); gateway rate limits still block Dina (em-0092), timeout errors explicitly fixed 9 Mar (ch-0085). |
| Bilal Kahananui; Bilal, @bilal | Chief Information Security Officer, Vercliff DS | Received Mistral brief; charter comments dependency; training outline requested review (mt-0003); access-request update requested by 10 Mar (em-0094), distinct from pilot charter; benefits-screening panel host (ch-0011, ch-0025). |
| Mei Obi; Mei, @mei | Product Lead, Resident Services, Vercliff DS | Mistral team; recap of unagreed workshop room-plan request (mt-0007). |
| Yael Ellery; Yael, @yael; 'Nordale lead'; 'Yael’s iPhone' | Program Manager, Nordale Department of Transportation | Mistral owner; pilot-center list/rollout checklist/action log responsibilities; requester of Fennel RACI review (ch-0007, ch-0020 identify Nordale lead); evaluation rubric v2 sent 8 March (em-0090, dc-0005); rollout checklist now in Dina's use (ch-0074). |
| Xiaoling Taufa; Ling, @xiaoling | Department Director, Nordale Department of Transportation | Mistral sponsor; received Mistral RACI chart (ch-0051). |
| Rudo Thornbury; Rudo, Rudo T., @rudo | Records Manager, Nordale Department of Transportation | Received Fennel status slide; intended recipient of Yael's Mistral action log. |
| Naoko Sandoval; Naoko, @naoko | Web Coordinator, Nordale Department of Transportation | Mistral test plan recipient; service blueprint sender promised (em-0051). |
| Alejandro Carmichael | Department Director, Selfell Public Works | Pothole selection sponsor. |
| Tendai Santos; Tendai, @tendai; 'Selfell lead' in workshop room-plan request | Customer Service Manager, Selfell Public Works | Inspection advisory and parking idea owner; parking statement/Selfell use-case list owed; reports pothole questionnaires phase. Room-plan 'Selfell lead' resolves via ch-0028 and mt-0007. |
| Catrin Kuznetsova; Catrin, @catrin | Records Manager, Selfell Public Works | Inspection options note and workshop run sheet owed; workshop speaker brief/registration list tentative. |
| Nomvula Jansen; Nomvula, @nomvula | Web Coordinator, Selfell Public Works | Received pothole requirements; offered workshop feedback form. |
| Hiba Jaber; Hiba, @hiba | Operations Manager, Ivyworth Housing Services | Records discovery owner; asked to countersign data-sharing agreement (nt-0005). |
| Niamh Kovalenko | Business Analyst, Ivyworth Housing Services | Possible baseline data pull, not confirmed (nt-0007). |
| Meera Chebet; Meera, @meera | Chief of Staff, Ormmarsh Parks and Recreation | Learning-series connection; reported code-enforcement diligence stalled (ch-0059). |
| Anh Novotny | Account Executive, Ethura Systems | Ethura deep-dive materials requested, outstanding (nt-0001). |

## Other contacts with limited role evidence
- **Imani Quaye**, Imani / **@imaniq**: full name from 9 March manifest title, handle/channel `ch-0081`; promises inspection-scheduling session notes involving **Torthen Civic**, accepted by Dina, not delivered. Role/employing organization and relationship to Selfell unknown. **Do not merge with Imani Navarro (@imani)** or assign Navarro's commitments to her.
- **Magdalena Shapiro**, Magda / **@magdalena**: full name from 9 March manifest title, alias/handle `ch-0082`; offered pothole reporting session notes, Dina accepted, not delivered. Role/organization and exact project relationship unknown.
- **Siti Montoya**, Siti / Sity / @siti: Marmara Labs affiliation explicit in `mt-0010`, calendar organizer/email domain `ca-0003`, `em-0060`; exact job title unknown. Relayed Imani reference request (`ch-0004`); met Dina 3 March; committed to return Marmara pothole security questionnaire (`em-0060`, `mt-0016`).
- **Esi Petrosyan**: **Solutions Engineer, Ethura Systems**; set up Dina's sandbox access, requests password change at first login, reset every Sunday night (`em-0089`). Not proof Anh's deep-dive materials delivered; credentials omitted.
- **Nathaniel Fenwick**, @nathaniel: exact title/organization unknown. Dina reviewed his Marmara diligence notes (`ch-0005`, `ch-0006`).
- **Penelope Fuentes**, @penelope: Talton-related contact, sender domain talton-research.example in forward (`em-0065`); exact title/legal employing organization unknown. Working paper promise (`ch-0035`) and catch-up request (`em-0065`); catch-up on hold awaiting her response (`ch-0076`).
- **Freja Mutasa**, @freja: **Budget Director**, exact department unknown; will rebase funding usage forecast (`ch-0060`); also chat participant (`ch-0068`).
- **Waian Nakamura**: **Department Director at Ivyworth**, exact department title beyond that not stated; possible parking-analytics reading-list recipient (`mt-0002`).
- **Bogdan Quinlan**, @bogdan: office-hours contact; exact role/organization not supplied (`mt-0002`, `mt-0016`).
- **Kenji Wekesa**: Penport Library Services attendee at cross-department forum, title unknown (`mt-0004`).
- **Tuan Hendriks**: Events Coordinator; room confirmations, catering and event-space survey (`em-0018`, `em-0029`, `em-0030`, later room emails).
- **Yasmin Colombo**: Conference Organizer; Regional Digital Services Summit promotional mail/CFP (`em-0015`, `em-0054`, `em-0079`). No personal agreement to speak or submit a proposal.
- **Aylin Kocak**: Civic Tech Bulletin newsletter sender; exact role unknown (`em-0049`).
- DS Shared Inbox: shared team mailbox, weekly status reminders (`em-0001`, `em-0044`); other notification senders are IT Service Desk, Platform Status Page, Internal Communications, Benefits Enrollment Notices.

## Organization boundaries
- **City of Vercliff / Vercliff Digital Service**: worker's city/team; Fennel shared platform and coordination across departments (`nt-0001`).
- **Nordale Department of Transportation**: Mistral pilot, Yael/Ling/Rudo/Naoko; contributes funding-model inputs (`nt-0001`).
- **Selfell Public Works**: pothole tool selection, workshop, inspection scheduling and parking analytics (`nt-0001`).
- **Ivyworth Housing Services**: records requests discovery (`nt-0001`); formerly blocking unsigned agreement is with Ivyworth (`ch-0045`); stopped/superseded by approach C decision 8 March (`nt-0008`), not signed.
- **Ormmarsh Parks and Recreation**: code-enforcement diligence and learning series; Meera (`nt-0001`).
- **Marmara Labs / Ethura Systems**: candidate vendors for Selfell pothole tool; also baseline code-enforcement diligence organizations. The two project threads must not be conflated (`nt-0001`, `em-0057`, `em-0060`, `ch-0059`).
- **Talton Institute for Public Service Design**: ongoing partnership and library learning-series collaborator (`nt-0001`); Talton relationship also part of new workshop follow-on Peer Network (`em-0086`). Keep existing partnership, learning series, and new network distinct.
- **Penport Library Services**: represented by Kenji at AI forum (`mt-0004`); no separate worker project established.
- **Torthen Civic**: involved in Imani Quaye's inspection-scheduling session notes (`ch-0081`); exact organization type, employer linkage and relation to Selfell advisory unknown.
- **Digital Steering Committee**: context for Fennel funding work; no scheduled meeting date or decision supplied (`nt-0001`).
