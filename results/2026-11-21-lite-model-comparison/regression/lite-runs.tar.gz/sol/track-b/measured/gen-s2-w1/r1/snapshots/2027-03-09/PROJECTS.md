# Project state — as of 2027-03-09

Owners, sponsors, baseline scope, aliases and targets below come from `nt-0001`, unless noted. Dates are in 2027. See COMMITMENTS.md for the full task ledger and sources/INDEX.md for original evidence.

## Mistral / service request triage pilot / Nordale pilot
- AI service-request triage pilot at Nordale Department of Transportation, hosted on Fennel. Owner Yael Ellery; sponsor Xiaoling Taufa (Ling). Last-known stage **scoping**; target **19 March** (`nt-0001`). No subsequent explicit stage change or launch evidence.
- **Scope decision 4 March: limit the pilot to three service centers**; Yael and Imani reacted affirmatively, Cassandra acknowledged (`ch-0062`). This matches baseline scope rather than demonstrating an expansion/reduction from another approved scope. Center names unknown; Yael agreed to send their list on 24 February, with no delivery seen (`ch-0021`).
- Mistral tenant provisioning: Cassandra committed on 23 February (`ch-0017`); Dina said tenant looked fine on her side on 24 February (`em-0023`). This supports that dependency being usable from Dina's perspective, not general security approval.
- Solution brief sent to Bilal **22 February** (`em-0004`, `em-0005`), repeatedly corroborated (`ch-0016`, `mt-0006`, `ch-0036`). The 5 March status repeats this achievement (`em-0074`), not necessarily a new send. Latest available brief is **v2 dated 5 March**, prepared by Dina; document metadata labels Project as Vercliff Digital Service. Indicative/rounded figures; assumptions need checking before sign-off; data covers pilot group only; timeline out of scope; scope and usage assumptions still open (`dc-0003`). No substantive architecture/API specification is supplied.
- Risk register confirmed with Imani **25 February** (`ch-0019`, `em-0027`); corroborated in `ch-0029`, `em-0037`, `mt-0006`, `ch-0040`, `ch-0042`, `em-0074`. Not reopened in these inputs.
- Test plan v1 prepared by Imani, sent to Naoko **27 February** (`em-0040`, `em-0043`, `dc-0002`). Scope unchanged; integration reworded; communications unchanged; timeline has two options with no preference; costs aligned with glossary. Usage realism and current scope still open (`dc-0002`). This is distinct from the **Fennel test plan**, which was reopened.
- RACI chart sent to Ling **3 March**, receipt acknowledged (`ch-0046`, `ch-0051`). Requirements matrix sent to Imani **4 March**, acknowledged (`em-0055`, `ch-0061`). Support model sent to Imani **4 March** (`nt-0006`, `em-0066`). Contents of these deliverables are not present.
- Decision memo: Dina promised to send Yael on 3 March (`mt-0009`), then **transferred to Thibault 5 March** because he was closer to it (`em-0068`). No delivery to Yael confirmed.
- Rollout checklist: previously waiting on Yael (`nt-0004`, `ch-0052`, `ch-0070`); **Dina is now working from it and says it covers what she needed, 8 March** (`ch-0074`, edited text). This resolves the waiting item without a known send time or supplied checklist contents.
- **Architecture diagram sent to Imani 9 March**, Dina explicitly reports sending and Imani reacts +1 (`ch-0080`); contents absent. Still open from Dina: write API contract v1 for Yael (`em-0010`); update charter after Bilal's comments (`mt-0003`, charter comments not known received); dependency list to Cassandra (`ch-0039`); one-page summary to Imani (`mt-0008`); stakeholder map to Cassandra (`nt-0007`). Incoming service blueprint from Naoko remains promised (`em-0051`, `mt-0014`); action log from Yael to Rudo remains promised (`ch-0056`). Training-outline review for Bilal remains **unaccepted/tentative** (`mt-0003`).
- **Change request v1 sent to Imani 8 March** (`em-0082`, `dc-0004`), prepared by Dina. Scope unchanged; training agreed at last review; support reworded after feedback; communications aligned with glossary; security needs unit input. Assumptions in appendix require checking before sign-off; open questions: which unit hosts shared components, and whether council routing is needed. No final approval implied.
- **Vendor comparison:** Dina offered it to Cassandra in the morning (`ch-0073`, no Cassandra acceptance); **accepted sending it to Thibault** after Naoko relayed his expectation in the evening (`ch-0077`). No delivery. Keep recipients distinct; no explicit reassignment from Cassandra.
- **Equity impact review walkthrough for Cassandra** is Dina's self-assigned task (`nt-0009`); Dina organized 11 March 14:00–14:30 (-07:00) invitation (`ca-0009`), acceptance/attendance not yet established. Review contents unknown.
- **New access-request update request from Bilal 9 March, wanted by tomorrow (10 March)** after his comments (`em-0094`); no Dina acceptance/completion, and actual comments absent. Distinct from the older pilot-charter commitment. Dina also requested **Mistral dashboard access from Cassandra** 9 March; Cassandra answered small talk but did not accept the access request (`ch-0083`). Do not conflate with earlier tenant provisioning.
- Tentative: retention schedule to Yael, 'try ... no promises' (`mt-0017`; Yaell = Yael); **Imani now relays Yael's need by Thursday 11 March** (`ch-0078`), but no Dina firm acceptance. Rudo's offer to share the **Mistral accessibility review** remains tentative ('maybe I should') at 9 March standup (`mt-0019`); distinct from Cassandra's Fennel review.
- Mistral duplicate-notifications investigation is an **automatic recap-only action**, lower confidence: 8 March pothole-selection check-in recap (`mn-0003`) and 9 March Mistral review recap (`mn-0005`) both assign Dina; still no direct acceptance or completion corroboration.
- Timeline concerns and thin documentation noted 24 February (`mt-0003`); 26 February status said flagship timelines tight (`em-0037`). 5 March status says no new risks but still reports Ivyworth blockage (`em-0074`); it does not erase prior timeline concerns. Avoid attributing generic transcript remarks as specific new blockers.

## Fennel / shared AI platform / common platform
- Shared platform on which department projects build. Owner Cassandra Yilmaz, sponsor Kayode Whitfield; stage **onboarding tenants**, no explicit stage change (`nt-0001`).
- **Test plan re-confirmed with Imani 8 March**: Dina explicitly says she just confirmed it and Imani thanks her (`ch-0075`). Previously confirmed 25 February (`nt-0003`, `ch-0023`, `em-0037`, `ch-0033`), then reopened 2 March because reviewed version was stale (`em-0052`). Renewed confirmation closes that reopened task; no plan text/version or overall platform sign-off supplied.
- **Tenant onboarding guide owner changed Cassandra → Imani 25 February** (`em-0026`, `ch-0024`). Cassandra's earlier promise was to publish it (`ch-0015`, working-session agenda `ca-0001`); publication still unconfirmed. Do not continue chasing Cassandra as owner.
- Model allow-list review is Dina's accepted commitment for Cassandra, agreed 23 February (`ch-0010`, `ch-0012`, `em-0035`); no review completion seen.
- Yael's Fennel RACI-chart review request still unaccepted (`ch-0007`, clarified `ch-0020`); distinct from the delivered **Mistral RACI chart**.
- Status slide sent to Rudo **25 February** (`mn-0001` automatic task recap, directly completed by `em-0031`; attached draft `dc-0001`). Draft notes: pilot-group data only; training appendix referenced; security draft/comments welcome; users out of scope. Unconfirmed dependencies; council routing and realistic usage assumptions open (`dc-0001`). No final sign-off evidence.
- Thibault assigned to configure Nordale SSO broker (`em-0016`); resumed work 24 February (`em-0020`), not complete. Thibault also to set gateway rate limits for Fennel tenants (`ch-0050`); **Dina chased 9 March and explicitly says she is blocked until they land** (`em-0092`), no completion seen.
- **Timeout errors fixed 9 March, Thibault explicitly reports** (`ch-0085`), following his offer that afternoon (`em-0099`). Dina thanks him and says a link worked; no independent retest details or proof this resolves gateway rate limits/SSO.
- Imani Navarro promised Dina the **Fennel help-desk script 9 March**, accepted with thanks (`ch-0084`), not received. Imani also requested Dina review her **Fennel metrics definition** (`em-0100`), no acceptance or review completion.
- **Evaluation rubric v2 received from Yael 8 March** (`em-0090`, `dc-0005`), completing her 5 March offer (`ch-0067`). Prepared by Yael. Scores 1 (poor)–5 (strong): total cost weight 20, A/B 3/3; requirements fit 15, 5/4; integration effort 20, 5/4; accessibility 20, 3/4; security posture 10, 5/2. Sheet reports weighted totals **A 345, B 300** (raw score×weight sums); listed weights sum to **85**, not 100. Options A/B identities and any approved selection unknown; these are Fennel scores, not Marmara/Ethura pothole scores.
- Incoming: Imani's data dictionary still pending (`ch-0049`); **Cassandra accepted sending Dina the Fennel architecture diagram 8 March** (`mt-0018`), not yet delivered. Distinct from Dina's outgoing Mistral diagram.
- **6 March request** via Yael: Dina review Cassandra's Fennel accessibility review; no acceptance/delivery yet (`em-0077`).

## Pothole Reporting Tool Selection / PRTS / Marmara–Ethura bake-off
- Dina owns selection for Selfell Public Works; sponsor Alejandro Carmichael; Marmara Labs and Ethura Systems are candidates; target **5 April** (`nt-0001`).
- **Moved gathering requirements → questionnaires 3 March**, Tendai reporting (`em-0057`).
- Automatic 9 March 1:1 recap assigns Dina **review of Imani's pothole reporting selection decision memo** (`mn-0004`); lower confidence, no direct acceptance/completion or memo contents. Does not establish selected vendor or a new phase.
- **Magdalena Shapiro (Magda, @magdalena) offered pothole reporting session notes**, Dina accepted 9 March (`ch-0082`, manifest identity); not received, organization and exact project linkage unknown.
- Requirements list sent to Nomvula **22 February**, receipt acknowledged (`ch-0001`, `ch-0002`); later recaps `ch-0008`, `ch-0009`, `ch-0014`, `em-0037` do not create new tasks.
- **Siti Montoya to return Marmara security questionnaire**, promised 4 March (`em-0060`, corroborated `mt-0016`). Still waiting, not returned. Do not confuse with stalled Marmara **code enforcement** diligence.
- Ethura deep-dive materials requested from Anh Novotny remain outstanding since baseline (`nt-0001`). **Ethura sandbox access set up 8 March** by Esi Petrosyan, Solutions Engineer; change temporary password at first login; sandbox resets every Sunday night (`em-0089`; credentials not retained). This does not prove login/testing or receipt of Anh's materials; email does not explicitly identify which vendor-work thread the sandbox serves. No product selection, pothole comparative score or completed questionnaire supplied.

## Ivyworth Records Requests Discovery / IRRD / records requests work
- Owner Hiba Jaber, sponsor Kayode; target **14 April** (`nt-0001`).
- **Moved planning → site visit 2 March** (`nt-0005`); unsigned Ivyworth data-sharing agreement blocked work (`ch-0045`, `em-0074`). **8 March Dina decided to use approach C for the records discovery opportunity list and explicitly stopped pursuing the agreement, superseded by that decision** (`nt-0008`). Close the agreement loop as superseded, not signed/completed. Approach C contents and impact on site-visit scope/timing are unknown; do not claim full discovery unblocked or completed.
- **Process map confirmed with delivery director Imani 9 March**, Dina explicitly reports completion (`em-0098`). History: accepted 3 March (`mt-0011`), blocked waiting on agreement 4 March (`mt-0013`), agreement superseded 8 March (`nt-0008`). Map contents absent; confirmation does not prove full discovery complete.
- Site visit agenda sent to Imani **2 March**, Dina's explicit statement with Imani acknowledgment (`mn-0002`, `mt-0008`).
- **Interview guide confirmed with Imani 6 March**, request/acceptance `ch-0071`, completion `em-0080`. This completed task did **not** itself resolve the agreement; the later approach C decision supersedes that agreement loop (`nt-0008`), not the whole discovery.
- **Findings summary requested by Imani 9 March** (`em-0095`); automatic 1:1 recap says Dina is picking it up (`mn-0004`), but no direct acceptance/delivery. Imani's observation-notes review request remains tentative (Dina: maybe, see how week goes) (`mt-0015`). Niamh pulling baseline data remains possible, not confirmed (`nt-0007`). No site-visit findings, process-map text or interview-guide attachment available.

## Fennel Funding Model / recharge / funding options
- Dina owns, Kayode sponsors; cross-department Fennel funding ahead of Digital Steering Committee, with Nordale inputs; target **12 April** (`nt-0001`).
- **Moved collecting inputs → options 22 February**, Dina reporting; mostly waiting on other teams (`mt-0001`). No chosen funding option or numeric forecast provided.
- **Funding options memo sent to Kayode 9 March at 14:49 (-07:00)**, explicit delivery email (`em-0096`); memo contents absent, no approved funding choice implied. Historical revised deadline was Tuesday 16 March, formerly 9 March (`ch-0064`, edited text; original 15 March must not be used). A 5 March working-session agenda (`ca-0007`) was not proof of that day's delivery.
- **Freja Mutasa (Budget Director) to rebase usage forecast**, reported by Imani 4 March (`ch-0060`); pending.
- Imani promised Dina a **funding-model status slide 8 March** (`mt-0018`); not yet received. Distinct from the Fennel platform status slide Dina sent Rudo 25 February.
- **Cost model sent by Imani 9 March** (`em-0097`), directly completing the share action in automatic 1:1 recap (`mn-0004`); contents/numbers absent. **Chargeback scenarios incoming from Imani**, Dina's 9 March note (`nt-0010`); still waiting, distinct from cost model/status slide.
- Options review held 3 March (`ca-0005`, `mt-0012`). Transcript only recaps Imani–Tendai introduction; no options decision recorded.

## AI in Public Service Workshop / Selfell workshop
- **Complete / closed as reported by owner Imani 8 March** (`em-0086`). Former baseline target **19 March**, owner Imani, sponsor Kayode; caseworkers at Selfell; Dina owned slides (`nt-0001`). Exact delivery date, final venue/schedule and slide delivery not supplied.
- **Moved logistics → delivery 24 February** (`ch-0022`). Stage 'delivery' is not evidence event already happened.
- Dina to convert workshop questions into FAQ, committed 25 February (`mt-0004`); individual task completion/cancellation not reported by project closure.
- Imani's post-event survey supplied **26 February** (`ch-0027`, `em-0034`). Despite its title, this does not prove an event occurred. Contents absent.
- Catrin accepted sending run sheet **2 March** (`ch-0047`), still waiting. Nomvula offered feedback form **3 March** (`ch-0057`, recapped `ch-0066`); **explicitly resumed it 9 March** (`ch-0079`), not yet supplied. This reactivates the individual task, not the closed workshop project. Imani to share session outline, reported **6 March** (`ch-0072`), not yet supplied.
- Tentative/unaccepted: Dina sending Tendai room plan (`ch-0028`, `mt-0007` explicitly nothing agreed); Catrin sending speaker brief (`ch-0043` not agreed); Catrin registration list (`ch-0063` not confirmed). Generic room-booking notifications establish no final venue/schedule. Owner's 8 March closure is explicit project-completion evidence, but does not individually complete every remaining deliverable.

## AI in public service Peer Network
- **New follow-on to the completed AI in Public Service Workshop**, announced by Imani **8 March** (`em-0086`). Ongoing; keeping Talton relationship warm through introductions, catch-ups and favours.
- No explicit owner, sponsor, target, members, meetings or Dina-specific deliverables supplied. Do not assume it replaces the existing Talton Partnership or inherits all workshop tasks.

## Inspection Scheduling Advisory
- Light-touch Selfell advice; owner Tendai, sponsor Kayode; no deliverables of DS's own in baseline (`nt-0001`).
- Catrin options note: initially possible 22 February (`nt-0002`), **confirmed commitment 26 February**, Dina made it official and Catrin acknowledged (`ch-0031`). Still awaiting note.
- **Imani Quaye (@imaniq) promised inspection-scheduling session notes involving Torthen Civic 9 March**, Dina accepted (`ch-0081`, manifest full name); not received. This is not Imani Navarro (@imani). Exact relationship to Selfell advisory unknown; do not merge organizations.
- Related personal favour: reference for Imani's inspection-scheduling fellowship application written/received **23 February** (`ch-0004`, `ch-0013`, `ch-0018`, corroborated `mt-0005`). Not a remaining task or a new DS advisory deliverable.

## Talton Partnership
- Dina owns warm ongoing relationship (introductions/catch-ups/favours), Kayode sponsors; Talton Institute for Public Service Design (`nt-0001`).
- Penelope Fuentes promised Talton working paper **27 February** (`ch-0035`), not received.
- Penelope asked Dina to arrange a Talton catch-up, forwarded by Imani **4 March** (`em-0065`); **Dina put it on hold 8 March until she hears back from Penelope** (`ch-0076`). Waiting on response, not scheduled; no date or missing response details provided.

## Selfell Parking Analytics Idea
- Owner Tendai, sponsor Kayode; **waiting on problem statement**, no newer stage/target (`nt-0001`).
- Tendai promised to send Dina problem statement in 22 February message forwarded 24 February (`em-0017`); still no delivery.
- Dina conditionally offered reading list to **Waian Nakamura, Ivyworth Department Director**, if useful (`mt-0002`); not an accepted firm commitment. Distinct from asking Tendai for Selfell's problem statement.
- Tendai also offered Selfell use-case list, accepted by Dina **27 February** (`ch-0034`); pending, purpose/project not explicitly specified.

## Marmara Code Enforcement Diligence
- Dina owns, Kayode sponsors; Ormmarsh Parks and Recreation, Marmara Labs and Ethura Systems (`nt-0001`).
- **In diligence → stalled 4 March**, Meera explicitly says nothing moving (`ch-0059`). No resumption after that.
- Nathaniel Fenwick's diligence notes reviewed **23 February** (`ch-0005`, `ch-0006`). Review completion does not mean overall diligence complete. No note contents supplied.

## Library Help Learning Series
- Imani owns, Kayode sponsors; caseworker library-help talks with Talton; associated Ormmarsh and Meera. **Quiet, no sessions booked** (`nt-0001`); no newer inputs.

## Cross-project relationship favour
- Dina agreed **1 March** to introduce Imani to Tendai for **permit intake** (`ch-0038`, recapped `mt-0012`). Still open. This is not the completed inspection-scheduling fellowship reference, nor proof a new permit-intake project was created.
