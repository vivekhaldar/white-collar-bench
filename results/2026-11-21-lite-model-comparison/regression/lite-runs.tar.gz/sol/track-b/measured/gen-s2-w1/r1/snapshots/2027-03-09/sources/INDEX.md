# Source index

All 233 input artifacts received 2027-02-22 through 2027-03-09 are preserved as sanitized text in daily files. PDF, DOCX and XLSX text was extracted; credentials, calendar access details and URLs were removed. Titles are not evidence of body contents.

| ID | Received | Channel | Title | Archive |
|---|---|---|---|---|
| em-0001 | 2027-02-22T07:02:00-07:00 | email | Reminder: Friday status note due Friday 26 February | [2027-02-22](2027-02-22.md) |
| em-0002 | 2027-02-22T07:16:00-07:00 | email | [Resolved] Elevated latency on file storage | [2027-02-22](2027-02-22.md) |
| em-0003 | 2027-02-22T07:20:00-07:00 | email | [INC-71022] Ticket updated | [2027-02-22](2027-02-22.md) |
| em-0004 | 2027-02-22T07:44:00-07:00 | email | Re: Mistral solution brief | [2027-02-22](2027-02-22.md) |
| nt-0001 | 2027-02-22T08:05:00-07:00 | note | Portfolio map | [2027-02-22](2027-02-22.md) |
| ch-0001 | 2027-02-22T08:26:00-07:00 | chat | DM: Nomvula Jansen / Dina Ricci | [2027-02-22](2027-02-22.md) |
| em-0005 | 2027-02-22T08:39:00-07:00 | email | Re: Mistral solution brief | [2027-02-22](2027-02-22.md) |
| em-0006 | 2027-02-22T09:08:00-07:00 | email | Open enrollment reminder | [2027-02-22](2027-02-22.md) |
| ch-0002 | 2027-02-22T09:19:00-07:00 | chat | DM: Dina Ricci / Nomvula Jansen | [2027-02-22](2027-02-22.md) |
| ch-0003 | 2027-02-22T09:21:00-07:00 | chat | #random | [2027-02-22](2027-02-22.md) |
| em-0007 | 2027-02-22T09:48:00-07:00 | email | [Investigating] Intermittent sign-in delays | [2027-02-22](2027-02-22.md) |
| mt-0001 | 2027-02-22T09:55:00-07:00 | transcript | Mistral standup (transcript) | [2027-02-22](2027-02-22.md) |
| em-0008 | 2027-02-22T11:51:00-07:00 | email | [Scheduled] Network maintenance window | [2027-02-22](2027-02-22.md) |
| em-0009 | 2027-02-22T13:04:00-07:00 | email | All-staff: building access changes | [2027-02-22](2027-02-22.md) |
| em-0010 | 2027-02-22T13:43:00-07:00 | email | Re: Mistral API contract v1 | [2027-02-22](2027-02-22.md) |
| em-0011 | 2027-02-22T17:33:00-07:00 | email | Wellness credit deadline | [2027-02-22](2027-02-22.md) |
| nt-0002 | 2027-02-22T17:39:00-07:00 | note | Mon notes | [2027-02-22](2027-02-22.md) |
| ca-0001 | 2027-02-22T18:14:00-07:00 | calendar | Invite: Working session: Fennel tenant onboarding guide | [2027-02-22](2027-02-22.md) |
| em-0012 | 2027-02-22T18:34:00-07:00 | email | Scheduled maintenance this weekend | [2027-02-22](2027-02-22.md) |
| em-0013 | 2027-02-23T08:14:00-07:00 | email | [INC-43691] Ticket updated | [2027-02-23](2027-02-23.md) |
| ca-0002 | 2027-02-23T08:58:00-07:00 | calendar | Cancelled: Mistral standup | [2027-02-23](2027-02-23.md) |
| em-0014 | 2027-02-23T11:13:00-07:00 | email | [REQ-15707] Request resolved | [2027-02-23](2027-02-23.md) |
| ch-0004 | 2027-02-23T11:19:00-07:00 | chat | DM: Siti Montoya / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0005 | 2027-02-23T11:44:00-07:00 | chat | DM: Dina Ricci / Nathaniel Fenwick | [2027-02-23](2027-02-23.md) |
| ch-0006 | 2027-02-23T12:11:00-07:00 | chat | DM: Dina Ricci / Nathaniel Fenwick | [2027-02-23](2027-02-23.md) |
| ch-0007 | 2027-02-23T12:52:00-07:00 | chat | #fennel-core | [2027-02-23](2027-02-23.md) |
| ch-0008 | 2027-02-23T13:30:00-07:00 | chat | DM: Nomvula Jansen / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0009 | 2027-02-23T13:43:00-07:00 | chat | #pothole-reporting-core | [2027-02-23](2027-02-23.md) |
| ch-0010 | 2027-02-23T14:19:00-07:00 | chat | #fennel-core | [2027-02-23](2027-02-23.md) |
| ch-0011 | 2027-02-23T14:36:00-07:00 | chat | DM: Bilal Kahananui / Dina Ricci | [2027-02-23](2027-02-23.md) |
| em-0015 | 2027-02-23T14:51:00-07:00 | email | Speaker spotlight | [2027-02-23](2027-02-23.md) |
| ch-0012 | 2027-02-23T15:36:00-07:00 | chat | DM: Yael Ellery / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0013 | 2027-02-23T15:44:00-07:00 | chat | DM: Dina Ricci / Imani Navarro | [2027-02-23](2027-02-23.md) |
| em-0016 | 2027-02-23T15:58:00-07:00 | email | Re: Fennel SSO broker for Nordale | [2027-02-23](2027-02-23.md) |
| ch-0014 | 2027-02-23T16:25:00-07:00 | chat | DM: Catrin Kuznetsova / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0015 | 2027-02-23T17:02:00-07:00 | chat | DM: Cassandra Yilmaz / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0016 | 2027-02-23T17:14:00-07:00 | chat | DM: Thibault Sahin / Dina Ricci | [2027-02-23](2027-02-23.md) |
| ch-0017 | 2027-02-23T17:44:00-07:00 | chat | #mistral-core | [2027-02-23](2027-02-23.md) |
| ch-0018 | 2027-02-23T18:34:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-02-23](2027-02-23.md) |
| em-0017 | 2027-02-24T07:41:00-07:00 | email | Fwd: Parking analytics problem statement | [2027-02-24](2027-02-24.md) |
| mt-0002 | 2027-02-24T08:45:00-07:00 | transcript | Office hours with Bogdan (transcript) | [2027-02-24](2027-02-24.md) |
| em-0018 | 2027-02-24T09:57:00-07:00 | email | Event space survey | [2027-02-24](2027-02-24.md) |
| mt-0003 | 2027-02-24T10:00:00-07:00 | transcript | Mistral standup (transcript) | [2027-02-24](2027-02-24.md) |
| em-0019 | 2027-02-24T11:05:00-07:00 | email | Wellbeing week activities | [2027-02-24](2027-02-24.md) |
| em-0020 | 2027-02-24T11:26:00-07:00 | email | Re: Fennel SSO broker for Nordale | [2027-02-24](2027-02-24.md) |
| ch-0019 | 2027-02-24T11:27:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-02-24](2027-02-24.md) |
| em-0021 | 2027-02-24T11:51:00-07:00 | email | Reminder: all-staff meeting Thursday | [2027-02-24](2027-02-24.md) |
| em-0022 | 2027-02-24T12:51:00-07:00 | email | [INC-73767] Ticket updated | [2027-02-24](2027-02-24.md) |
| nt-0003 | 2027-02-24T14:35:00-07:00 | note | Voice debrief: Fennel platform sync | [2027-02-24](2027-02-24.md) |
| em-0023 | 2027-02-24T16:32:00-07:00 | email | Re: Mistral tenant on Fennel | [2027-02-24](2027-02-24.md) |
| ch-0020 | 2027-02-24T16:41:00-07:00 | chat | #fennel-core | [2027-02-24](2027-02-24.md) |
| ch-0021 | 2027-02-24T18:14:00-07:00 | chat | DM: Dina Ricci / Yael Ellery | [2027-02-24](2027-02-24.md) |
| ch-0022 | 2027-02-24T19:02:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-02-24](2027-02-24.md) |
| em-0024 | 2027-02-25T07:07:00-07:00 | email | [INC-79161] Ticket updated | [2027-02-25](2027-02-25.md) |
| em-0025 | 2027-02-25T08:01:00-07:00 | email | Parking lot resurfacing | [2027-02-25](2027-02-25.md) |
| ch-0023 | 2027-02-25T09:25:00-07:00 | chat | #fennel-core | [2027-02-25](2027-02-25.md) |
| em-0026 | 2027-02-25T09:32:00-07:00 | email | Re: Fennel tenant onboarding guide | [2027-02-25](2027-02-25.md) |
| em-0027 | 2027-02-25T11:33:00-07:00 | email | Re: Mistral risk register | [2027-02-25](2027-02-25.md) |
| em-0028 | 2027-02-25T11:55:00-07:00 | email | [REQ-20216] Request resolved | [2027-02-25](2027-02-25.md) |
| ca-0003 | 2027-02-25T12:50:00-07:00 | calendar | Invite: Catch-up: Dina / Siti | [2027-02-25](2027-02-25.md) |
| mt-0004 | 2027-02-25T14:00:00-07:00 | transcript | Cross-department AI forum (transcript) | [2027-02-25](2027-02-25.md) |
| em-0029 | 2027-02-25T14:11:00-07:00 | email | Catering menu for next month | [2027-02-25](2027-02-25.md) |
| ch-0024 | 2027-02-25T15:31:00-07:00 | chat | #fennel-core | [2027-02-25](2027-02-25.md) |
| ch-0025 | 2027-02-25T15:45:00-07:00 | chat | DM: Dina Ricci / Bilal Kahananui | [2027-02-25](2027-02-25.md) |
| em-0030 | 2027-02-25T15:54:00-07:00 | email | Room booking confirmation | [2027-02-25](2027-02-25.md) |
| mn-0001 | 2027-02-25T17:00:00-07:00 | meeting_notes | Recap: Mistral / Fennel sync | [2027-02-25](2027-02-25.md) |
| dc-0001 | 2027-02-25T17:05:00-07:00 | document | Fennel status slide (draft) | [2027-02-25](2027-02-25.md) |
| em-0031 | 2027-02-25T17:05:00-07:00 | email | Re: Fennel status slide | [2027-02-25](2027-02-25.md) |
| ch-0026 | 2027-02-25T17:25:00-07:00 | chat | #general | [2027-02-25](2027-02-25.md) |
| ch-0027 | 2027-02-25T18:29:00-07:00 | chat | #ai-in-public-service-core | [2027-02-25](2027-02-25.md) |
| em-0032 | 2027-02-25T18:55:00-07:00 | email | Your benefits statement is ready | [2027-02-25](2027-02-25.md) |
| ch-0028 | 2027-02-26T08:40:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-02-26](2027-02-26.md) |
| em-0033 | 2027-02-26T09:17:00-07:00 | email | [REQ-10363] Request resolved | [2027-02-26](2027-02-26.md) |
| em-0034 | 2027-02-26T09:18:00-07:00 | email | Re: AI in public service workshop post-event survey | [2027-02-26](2027-02-26.md) |
| ch-0029 | 2027-02-26T09:19:00-07:00 | chat | #mistral-core | [2027-02-26](2027-02-26.md) |
| em-0035 | 2027-02-26T09:45:00-07:00 | email | Re: FYI: Fennel model allow-list | [2027-02-26](2027-02-26.md) |
| mt-0005 | 2027-02-26T09:55:00-07:00 | transcript | Mistral standup (transcript) | [2027-02-26](2027-02-26.md) |
| ca-0004 | 2027-02-26T10:05:00-07:00 | calendar | Invite: Mistral scoping call | [2027-02-26](2027-02-26.md) |
| em-0036 | 2027-02-26T10:56:00-07:00 | email | [INC-83509] Ticket updated | [2027-02-26](2027-02-26.md) |
| ch-0030 | 2027-02-26T11:02:00-07:00 | chat | #coffee | [2027-02-26](2027-02-26.md) |
| ch-0031 | 2027-02-26T14:05:00-07:00 | chat | DM: Dina Ricci / Catrin Kuznetsova | [2027-02-26](2027-02-26.md) |
| ch-0032 | 2027-02-26T15:56:00-07:00 | chat | #coffee | [2027-02-26](2027-02-26.md) |
| em-0037 | 2027-02-26T17:04:00-07:00 | email | Status note: w/e 26 February | [2027-02-26](2027-02-26.md) |
| ch-0033 | 2027-02-26T17:17:00-07:00 | chat | #fennel-core | [2027-02-26](2027-02-26.md) |
| em-0038 | 2027-02-26T17:21:00-07:00 | email | Room booking confirmation | [2027-02-26](2027-02-26.md) |
| em-0039 | 2027-02-27T08:54:00-07:00 | email | [REQ-33165] Request resolved | [2027-02-27](2027-02-27.md) |
| em-0040 | 2027-02-27T09:45:00-07:00 | email | Fwd: Mistral test plan | [2027-02-27](2027-02-27.md) |
| em-0041 | 2027-02-27T11:16:00-07:00 | email | [INC-78801] Ticket updated | [2027-02-27](2027-02-27.md) |
| em-0042 | 2027-02-27T11:48:00-07:00 | email | [INC-45145] Ticket updated | [2027-02-27](2027-02-27.md) |
| dc-0002 | 2027-02-27T11:50:00-07:00 | document | Mistral test plan v1 | [2027-02-27](2027-02-27.md) |
| em-0043 | 2027-02-27T11:50:00-07:00 | email | Re: Mistral test plan | [2027-02-27](2027-02-27.md) |
| ch-0034 | 2027-02-27T17:39:00-07:00 | chat | DM: Tendai Santos / Dina Ricci | [2027-02-27](2027-02-27.md) |
| ch-0035 | 2027-02-27T18:20:00-07:00 | chat | DM: Penelope Fuentes / Dina Ricci | [2027-02-27](2027-02-27.md) |
| em-0044 | 2027-03-01T06:58:00-07:00 | email | Reminder: Friday status note due Friday 5 March | [2027-03-01](2027-03-01.md) |
| nt-0004 | 2027-03-01T07:25:00-07:00 | note | Mon notes | [2027-03-01](2027-03-01.md) |
| ca-0005 | 2027-03-01T07:55:00-07:00 | calendar | Invite: Funding model options review | [2027-03-01](2027-03-01.md) |
| mt-0006 | 2027-03-01T08:30:00-07:00 | transcript | Catch-up: Dina / Hiba (transcript) | [2027-03-01](2027-03-01.md) |
| ch-0036 | 2027-03-01T08:58:00-07:00 | chat | DM: Yael Ellery / Dina Ricci | [2027-03-01](2027-03-01.md) |
| ca-0006 | 2027-03-01T09:07:00-07:00 | calendar | Cancelled: Mistral standup | [2027-03-01](2027-03-01.md) |
| em-0045 | 2027-03-01T09:22:00-07:00 | email | Open enrollment reminder | [2027-03-01](2027-03-01.md) |
| em-0046 | 2027-03-01T10:29:00-07:00 | email | [REQ-28214] Request resolved | [2027-03-01](2027-03-01.md) |
| mn-0002 | 2027-03-01T11:45:00-07:00 | meeting_notes | Notes: DS leads call | [2027-03-01](2027-03-01.md) |
| ch-0037 | 2027-03-01T13:25:00-07:00 | chat | #coffee | [2027-03-01](2027-03-01.md) |
| ch-0038 | 2027-03-01T13:53:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-03-01](2027-03-01.md) |
| ch-0039 | 2027-03-01T14:10:00-07:00 | chat | #mistral-core | [2027-03-01](2027-03-01.md) |
| ch-0040 | 2027-03-01T15:52:00-07:00 | chat | DM: Cassandra Yilmaz / Dina Ricci | [2027-03-01](2027-03-01.md) |
| mt-0007 | 2027-03-01T16:30:00-07:00 | transcript | Catch-up: Dina / Mei (transcript) | [2027-03-01](2027-03-01.md) |
| ch-0041 | 2027-03-01T16:36:00-07:00 | chat | #coffee | [2027-03-01](2027-03-01.md) |
| ch-0042 | 2027-03-01T16:46:00-07:00 | chat | DM: Cassandra Yilmaz / Dina Ricci | [2027-03-01](2027-03-01.md) |
| ch-0043 | 2027-03-01T17:22:00-07:00 | chat | #ai-in-public-service-core | [2027-03-01](2027-03-01.md) |
| ch-0044 | 2027-03-01T17:45:00-07:00 | chat | #general | [2027-03-01](2027-03-01.md) |
| ch-0045 | 2027-03-02T07:29:00-07:00 | chat | DM: Hiba Jaber / Dina Ricci | [2027-03-02](2027-03-02.md) |
| ca-0007 | 2027-03-02T08:26:00-07:00 | calendar | Invite: Working session: Funding model funding options memo | [2027-03-02](2027-03-02.md) |
| nt-0005 | 2027-03-02T09:00:00-07:00 | note | Tue voice memo | [2027-03-02](2027-03-02.md) |
| ch-0046 | 2027-03-02T09:09:00-07:00 | chat | DM: Dina Ricci / Xiaoling Taufa | [2027-03-02](2027-03-02.md) |
| ch-0047 | 2027-03-02T09:11:00-07:00 | chat | DM: Dina Ricci / Catrin Kuznetsova | [2027-03-02](2027-03-02.md) |
| ch-0048 | 2027-03-02T10:05:00-07:00 | chat | #general | [2027-03-02](2027-03-02.md) |
| em-0047 | 2027-03-02T10:06:00-07:00 | email | Reminder: all-staff meeting Thursday | [2027-03-02](2027-03-02.md) |
| ch-0049 | 2027-03-02T11:47:00-07:00 | chat | #fennel-core | [2027-03-02](2027-03-02.md) |
| em-0048 | 2027-03-02T12:36:00-07:00 | email | Room booking confirmation | [2027-03-02](2027-03-02.md) |
| ch-0050 | 2027-03-02T15:25:00-07:00 | chat | DM: Yael Ellery / Dina Ricci | [2027-03-02](2027-03-02.md) |
| em-0049 | 2027-03-02T15:36:00-07:00 | email | Civic Tech Bulletin: issue 9 | [2027-03-02](2027-03-02.md) |
| em-0050 | 2027-03-02T16:37:00-07:00 | email | Scheduled maintenance this weekend | [2027-03-02](2027-03-02.md) |
| mt-0008 | 2027-03-02T17:00:00-07:00 | transcript | Mistral scoping call (transcript) | [2027-03-02](2027-03-02.md) |
| em-0051 | 2027-03-02T18:06:00-07:00 | email | Fwd: Mistral service blueprint | [2027-03-02](2027-03-02.md) |
| em-0052 | 2027-03-02T18:16:00-07:00 | email | Re: Fennel test plan | [2027-03-02](2027-03-02.md) |
| em-0053 | 2027-03-02T18:51:00-07:00 | email | [REQ-11828] Request resolved | [2027-03-02](2027-03-02.md) |
| ch-0051 | 2027-03-03T07:40:00-07:00 | chat | DM: Dina Ricci / Xiaoling Taufa | [2027-03-03](2027-03-03.md) |
| em-0054 | 2027-03-03T09:23:00-07:00 | email | Speaker spotlight | [2027-03-03](2027-03-03.md) |
| mt-0009 | 2027-03-03T09:55:00-07:00 | transcript | Mistral standup (transcript) | [2027-03-03](2027-03-03.md) |
| mt-0010 | 2027-03-03T10:00:00-07:00 | transcript | Catch-up: Dina / Siti (transcript) | [2027-03-03](2027-03-03.md) |
| ch-0052 | 2027-03-03T11:30:00-07:00 | chat | DM: Yael Ellery / Dina Ricci | [2027-03-03](2027-03-03.md) |
| em-0055 | 2027-03-03T11:30:00-07:00 | email | Mistral requirements matrix | [2027-03-03](2027-03-03.md) |
| em-0056 | 2027-03-03T11:37:00-07:00 | email | Room booking confirmation | [2027-03-03](2027-03-03.md) |
| ch-0053 | 2027-03-03T12:17:00-07:00 | chat | DM: Kayode Whitfield / Dina Ricci | [2027-03-03](2027-03-03.md) |
| ch-0054 | 2027-03-03T12:54:00-07:00 | chat | #random | [2027-03-03](2027-03-03.md) |
| mt-0011 | 2027-03-03T14:30:00-07:00 | transcript | Fennel platform sync (transcript) | [2027-03-03](2027-03-03.md) |
| ch-0055 | 2027-03-03T14:39:00-07:00 | chat | #random | [2027-03-03](2027-03-03.md) |
| em-0057 | 2027-03-03T14:49:00-07:00 | email | Pothole Reporting Tool Selection: moving to questionnaires | [2027-03-03](2027-03-03.md) |
| mt-0012 | 2027-03-03T15:30:00-07:00 | transcript | Funding model options review (transcript) | [2027-03-03](2027-03-03.md) |
| em-0058 | 2027-03-03T15:55:00-07:00 | email | [Investigating] Intermittent sign-in delays | [2027-03-03](2027-03-03.md) |
| ch-0056 | 2027-03-03T16:06:00-07:00 | chat | DM: Dina Ricci / Rudo Thornbury | [2027-03-03](2027-03-03.md) |
| ch-0057 | 2027-03-03T16:27:00-07:00 | chat | DM: Nomvula Jansen / Dina Ricci | [2027-03-03](2027-03-03.md) |
| ch-0058 | 2027-03-03T16:55:00-07:00 | chat | #random | [2027-03-03](2027-03-03.md) |
| em-0059 | 2027-03-03T18:54:00-07:00 | email | Room booking confirmation | [2027-03-03](2027-03-03.md) |
| em-0060 | 2027-03-04T07:50:00-07:00 | email | Re: Marmara security questionnaire | [2027-03-04](2027-03-04.md) |
| em-0061 | 2027-03-04T08:08:00-07:00 | email | Room booking confirmation | [2027-03-04](2027-03-04.md) |
| ch-0059 | 2027-03-04T09:56:00-07:00 | chat | DM: Meera Chebet / Dina Ricci | [2027-03-04](2027-03-04.md) |
| em-0062 | 2027-03-04T10:56:00-07:00 | email | Room booking confirmation | [2027-03-04](2027-03-04.md) |
| ch-0060 | 2027-03-04T12:49:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-03-04](2027-03-04.md) |
| mt-0013 | 2027-03-04T13:15:00-07:00 | transcript | Catch-up: Dina / Imani (transcript) | [2027-03-04](2027-03-04.md) |
| ch-0061 | 2027-03-04T13:35:00-07:00 | chat | DM: Dina Ricci / Imani Navarro | [2027-03-04](2027-03-04.md) |
| em-0063 | 2027-03-04T14:07:00-07:00 | email | [Resolved] Elevated latency on file storage | [2027-03-04](2027-03-04.md) |
| em-0064 | 2027-03-04T14:08:00-07:00 | email | [INC-81255] Ticket updated | [2027-03-04](2027-03-04.md) |
| ch-0062 | 2027-03-04T15:03:00-07:00 | chat | #mistral-core | [2027-03-04](2027-03-04.md) |
| ch-0063 | 2027-03-04T15:03:00-07:00 | chat | DM: Tendai Santos / Dina Ricci | [2027-03-04](2027-03-04.md) |
| ch-0064 | 2027-03-04T15:26:00-07:00 | chat | DM: Kayode Whitfield / Dina Ricci | [2027-03-04](2027-03-04.md) |
| ch-0065 | 2027-03-04T15:45:00-07:00 | chat | #general | [2027-03-04](2027-03-04.md) |
| mt-0014 | 2027-03-04T16:30:00-07:00 | transcript | Office hours with Cassandra (transcript) | [2027-03-04](2027-03-04.md) |
| em-0065 | 2027-03-04T17:02:00-07:00 | email | Fwd: A Talton catch-up | [2027-03-04](2027-03-04.md) |
| nt-0006 | 2027-03-04T18:02:00-07:00 | note | Thu notes | [2027-03-04](2027-03-04.md) |
| ch-0066 | 2027-03-04T18:15:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-03-04](2027-03-04.md) |
| em-0066 | 2027-03-04T18:28:00-07:00 | email | Re: Mistral support model | [2027-03-04](2027-03-04.md) |
| em-0067 | 2027-03-04T18:33:00-07:00 | email | [Scheduled] Network maintenance window | [2027-03-04](2027-03-04.md) |
| em-0068 | 2027-03-05T08:46:00-07:00 | email | Re: Mistral decision memo | [2027-03-05](2027-03-05.md) |
| mt-0015 | 2027-03-05T10:00:00-07:00 | transcript | Mistral standup (transcript) | [2027-03-05](2027-03-05.md) |
| ch-0067 | 2027-03-05T12:12:00-07:00 | chat | #fennel-core | [2027-03-05](2027-03-05.md) |
| ch-0068 | 2027-03-05T12:24:00-07:00 | chat | #random | [2027-03-05](2027-03-05.md) |
| em-0069 | 2027-03-05T12:58:00-07:00 | email | Room booking confirmation | [2027-03-05](2027-03-05.md) |
| em-0070 | 2027-03-05T13:55:00-07:00 | email | Room booking confirmation | [2027-03-05](2027-03-05.md) |
| em-0071 | 2027-03-05T14:05:00-07:00 | email | Room booking confirmation | [2027-03-05](2027-03-05.md) |
| em-0072 | 2027-03-05T15:06:00-07:00 | email | [INC-41863] Ticket updated | [2027-03-05](2027-03-05.md) |
| em-0073 | 2027-03-05T15:18:00-07:00 | email | [INC-46374] Ticket updated | [2027-03-05](2027-03-05.md) |
| ch-0069 | 2027-03-05T15:57:00-07:00 | chat | #general | [2027-03-05](2027-03-05.md) |
| dc-0003 | 2027-03-05T16:21:00-07:00 | document | Mistral solution brief v2 | [2027-03-05](2027-03-05.md) |
| em-0074 | 2027-03-05T16:21:00-07:00 | email | Status note: w/e 5 March | [2027-03-05](2027-03-05.md) |
| mt-0016 | 2027-03-05T16:30:00-07:00 | transcript | Lunch and learn (transcript) | [2027-03-05](2027-03-05.md) |
| em-0075 | 2027-03-05T16:33:00-07:00 | email | [INC-86714] Ticket updated | [2027-03-05](2027-03-05.md) |
| em-0076 | 2027-03-05T17:43:00-07:00 | email | Mistral architecture diagram | [2027-03-05](2027-03-05.md) |
| ch-0070 | 2027-03-05T18:04:00-07:00 | chat | #mistral-core | [2027-03-05](2027-03-05.md) |
| nt-0007 | 2027-03-05T18:29:00-07:00 | note | Fri notes | [2027-03-05](2027-03-05.md) |
| em-0077 | 2027-03-06T07:47:00-07:00 | email | Cassandra's Fennel accessibility review | [2027-03-06](2027-03-06.md) |
| em-0078 | 2027-03-06T08:11:00-07:00 | email | [INC-55685] Ticket updated | [2027-03-06](2027-03-06.md) |
| em-0079 | 2027-03-06T09:19:00-07:00 | email | Call for proposals closes Saturday 20 March | [2027-03-06](2027-03-06.md) |
| ch-0071 | 2027-03-06T14:58:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-03-06](2027-03-06.md) |
| ch-0072 | 2027-03-06T15:24:00-07:00 | chat | #ai-in-public-service-core | [2027-03-06](2027-03-06.md) |
| em-0080 | 2027-03-06T18:19:00-07:00 | email | Records requests discovery interview guide | [2027-03-06](2027-03-06.md) |
| em-0081 | 2027-03-08T06:51:00-07:00 | email | Reminder: Friday status note due Friday 12 March | [2027-03-08](2027-03-08.md) |
| nt-0008 | 2027-03-08T07:53:00-07:00 | note | Mon notes — approach C / agreement superseded | [2027-03-08](2027-03-08.md) |
| dc-0004 | 2027-03-08T08:42:00-07:00 | document | Mistral change request v1 (parent em-0082) | [2027-03-08](2027-03-08.md) |
| em-0082 | 2027-03-08T08:42:00-07:00 | email | Re: Mistral change request | [2027-03-08](2027-03-08.md) |
| ch-0073 | 2027-03-08T09:03:00-07:00 | chat | #mistral-core | [2027-03-08](2027-03-08.md) |
| em-0083 | 2027-03-08T09:40:00-07:00 | email | Call for proposals closes Saturday 20 March (body: Friday 12 March) | [2027-03-08](2027-03-08.md) |
| em-0084 | 2027-03-08T09:43:00-07:00 | email | [Scheduled] Network maintenance window | [2027-03-08](2027-03-08.md) |
| em-0085 | 2027-03-08T09:45:00-07:00 | email | Reminder: all-staff meeting Thursday (body: car park) | [2027-03-08](2027-03-08.md) |
| em-0086 | 2027-03-08T09:58:00-07:00 | email | Re: AI in Public Service Workshop: moving to closed | [2027-03-08](2027-03-08.md) |
| mt-0017 | 2027-03-08T10:00:00-07:00 | transcript | Mistral standup (transcript) | [2027-03-08](2027-03-08.md) |
| em-0087 | 2027-03-08T10:39:00-07:00 | email | Open enrollment reminder | [2027-03-08](2027-03-08.md) |
| em-0088 | 2027-03-08T10:41:00-07:00 | email | Speaker spotlight | [2027-03-08](2027-03-08.md) |
| mn-0003 | 2027-03-08T11:00:00-07:00 | meeting_notes | Recap: Marmara intro call | [2027-03-08](2027-03-08.md) |
| em-0089 | 2027-03-08T11:14:00-07:00 | email | Ethura sandbox credentials (credentials omitted) | [2027-03-08](2027-03-08.md) |
| mt-0018 | 2027-03-08T11:45:00-07:00 | transcript | DS leads call (transcript) | [2027-03-08](2027-03-08.md) |
| dc-0005 | 2027-03-08T13:24:00-07:00 | document | Fennel evaluation rubric v2 (parent em-0090) | [2027-03-08](2027-03-08.md) |
| em-0090 | 2027-03-08T13:24:00-07:00 | email | Re: Fennel evaluation rubric | [2027-03-08](2027-03-08.md) |
| ch-0074 | 2027-03-08T13:25:00-07:00 | chat | DM: Dina Ricci / Yael Ellery | [2027-03-08](2027-03-08.md) |
| ch-0075 | 2027-03-08T13:32:00-07:00 | chat | DM: Dina Ricci / Imani Navarro | [2027-03-08](2027-03-08.md) |
| ca-0008 | 2027-03-08T14:52:00-07:00 | calendar | Invite: Mistral review | [2027-03-08](2027-03-08.md) |
| em-0091 | 2027-03-08T17:11:00-07:00 | email | Early-bird registration ends Friday | [2027-03-08](2027-03-08.md) |
| ch-0076 | 2027-03-08T17:29:00-07:00 | chat | DM: Dina Ricci / Penelope Fuentes | [2027-03-08](2027-03-08.md) |
| ch-0077 | 2027-03-08T18:52:00-07:00 | chat | DM: Naoko Sandoval / Dina Ricci | [2027-03-08](2027-03-08.md) |
| nt-0009 | 2027-03-08T20:16:00-07:00 | note | Mon notes — equity impact review walkthrough | [2027-03-08](2027-03-08.md) |
| ca-0009 | 2027-03-08T20:21:00-07:00 | calendar | Invite: Walkthrough: Mistral equity impact review | [2027-03-08](2027-03-08.md) |
| em-0092 | 2027-03-09T07:12:00-07:00 | email | Re: Gateway rate limits for Fennel tenants | [2027-03-09](2027-03-09.md) |
| ch-0078 | 2027-03-09T08:39:00-07:00 | chat | #mistral-core | [2027-03-09](2027-03-09.md) |
| em-0093 | 2027-03-09T09:06:00-07:00 | email | Civic Tech Bulletin: issue 10 | [2027-03-09](2027-03-09.md) |
| ch-0079 | 2027-03-09T09:31:00-07:00 | chat | #ai-in-public-service-core | [2027-03-09](2027-03-09.md) |
| ch-0080 | 2027-03-09T09:41:00-07:00 | chat | #mistral-core | [2027-03-09](2027-03-09.md) |
| mt-0019 | 2027-03-09T09:55:00-07:00 | transcript | Mistral standup (transcript) | [2027-03-09](2027-03-09.md) |
| em-0094 | 2027-03-09T13:56:00-07:00 | email | Re: Mistral access request after Bilal's comments | [2027-03-09](2027-03-09.md) |
| ch-0081 | 2027-03-09T14:15:00-07:00 | chat | DM: Imani Quaye / Dina Ricci | [2027-03-09](2027-03-09.md) |
| ch-0082 | 2027-03-09T14:23:00-07:00 | chat | DM: Magdalena Shapiro / Dina Ricci | [2027-03-09](2027-03-09.md) |
| em-0095 | 2027-03-09T14:41:00-07:00 | email | Records requests discovery findings summary | [2027-03-09](2027-03-09.md) |
| em-0096 | 2027-03-09T14:49:00-07:00 | email | Funding model funding options memo | [2027-03-09](2027-03-09.md) |
| mn-0004 | 2027-03-09T15:30:00-07:00 | meeting_notes | Recap: 1:1 Dina / Imani | [2027-03-09](2027-03-09.md) |
| nt-0010 | 2027-03-09T15:34:00-07:00 | note | Tue notes | [2027-03-09](2027-03-09.md) |
| mn-0005 | 2027-03-09T15:45:00-07:00 | meeting_notes | Recap: Mistral review | [2027-03-09](2027-03-09.md) |
| em-0097 | 2027-03-09T15:48:00-07:00 | email | Re: Funding model cost model | [2027-03-09](2027-03-09.md) |
| em-0098 | 2027-03-09T16:20:00-07:00 | email | Records requests discovery process map | [2027-03-09](2027-03-09.md) |
| ch-0083 | 2027-03-09T16:51:00-07:00 | chat | DM: Dina Ricci / Cassandra Yilmaz | [2027-03-09](2027-03-09.md) |
| em-0099 | 2027-03-09T17:14:00-07:00 | email | Re: Fennel timeout errors | [2027-03-09](2027-03-09.md) |
| em-0100 | 2027-03-09T17:49:00-07:00 | email | Re: Imani's Fennel metrics definition | [2027-03-09](2027-03-09.md) |
| ch-0084 | 2027-03-09T18:54:00-07:00 | chat | DM: Imani Navarro / Dina Ricci | [2027-03-09](2027-03-09.md) |
| ch-0085 | 2027-03-09T19:50:00-07:00 | chat | DM: Thibault Sahin / Dina Ricci | [2027-03-09](2027-03-09.md) |
