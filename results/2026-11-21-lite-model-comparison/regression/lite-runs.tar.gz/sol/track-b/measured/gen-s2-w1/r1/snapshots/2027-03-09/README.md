# Dina Ricci — working memory

**Current through 2027-03-09.** Worker: Dina Ricci, Vercliff Digital Service (DS), City of Vercliff. Identity supported by emails and `nt-0001`.

## Navigation
- [PROJECTS.md](PROJECTS.md): latest project state, decisions, targets, dependencies and history.
- [COMMITMENTS.md](COMMITMENTS.md): actionable ledger, including completed, transferred, reopened and tentative items. No completion is inferred merely from a recap, reaction, document draft or invitation.
- [PEOPLE.md](PEOPLE.md): roles, aliases and relationship map.
- [DATES.md](DATES.md): deadlines, calendar evidence and administrative reminders.
- [PORTFOLIO-BASELINE.md](PORTFOLIO-BASELINE.md): full 22 February portfolio map (`nt-0001`), including original project aliases, owners and sponsors. Historical, not current.
- [sources/INDEX.md](sources/INDEX.md): all **233 artifacts** across the fourteen supplied dates, linked to sanitized daily source text. Search artifact IDs or topic words there for exact supporting language.

## Latest changes (9 March)
- **Delivered/confirmed:** Mistral architecture diagram to Imani (`ch-0080`), funding options memo to Kayode (`em-0096`, before revised 16 March deadline), funding cost model from Imani (`em-0097`), records discovery process-map confirmation (`em-0098`). Contents absent; no final project/funding sign-off implied.
- **Fennel gateway rate limits still block Dina** (`em-0092`). Thibault separately reports timeout errors fixed (`ch-0085`); not evidence rate limits or SSO completed.
- Bilal requests access-request update **by 10 March** (`em-0094`); Yael needs retention schedule **by 11 March** (`ch-0078`); neither is a new firm Dina acceptance. New findings-summary/metrics-review requests and recap-only pothole decision-memo review recorded with confidence distinctions.
- Incoming: chargeback scenarios (`nt-0010`), Fennel help-desk script (`ch-0084`), session notes from **Imani Quaye @imaniq** involving Torthen Civic (`ch-0081`) and **Magdalena Shapiro / Magda** (`ch-0082`). Quaye is not Navarro.
- Workshop stays closed; Nomvula resumed its individual feedback-form task (`ch-0079`). Mistral duplicate-notifications action repeated in automatic recap only (`mn-0005`). Two 9 March meeting recaps overlap; conflict retained.
- Still current: Ivyworth agreement superseded by approach C (`nt-0008`); equity walkthrough **11 March** (`ca-0009`), status note **12 March** (`em-0081`), CFP latest body **12 March** versus subject/earlier notice 20 March (`em-0083`, `em-0079`).

## Evidence and updating rules
- Cite IDs such as `em-0052`, `ch-0064`, `mt-0008`, `nt-0005`; the source index gives received date/channel/title and the daily archive contains the text.
- Latest explicit changes supersede older states. Preserve both the old event and the reason for reopening/reassignment. Use edited message text, not its original version.
- Distinguish requests/offers, accepted commitments, ongoing work, and actual completion. Emoji reactions and vague acknowledgments alone are not proof of acceptance or delivery. An email saying it sent something supports delivery, but does not reveal an absent attachment's contents.
- Automatic transcripts can misname people; resolve aliases using handles, participants and corroborating sources. Automatic meeting summaries are lower confidence than direct messages.
- Friday status notes sometimes repeat older achievements. Do not treat repeated reporting as a new completion date.
- Targets in the baseline remain last-known targets unless superseded; they are not evidence that delivery happened. Missing deadlines/attachments/service-center names/approvals remain unknown.
- No data after 2027-03-09 is available. All supplied artifacts were incorporated, including low-signal notifications in the searchable archive. No credentials, passcodes or meeting join links are retained; archive URLs were omitted as a precaution.
