# Baseline source: nt-0001 (2027-02-22)

Historical starting point, not current status. See PROJECTS.md and COMMITMENTS.md for subsequent changes.

# Portfolio map (22 February)

Where things stand across my projects. Org: City of Vercliff; my team: Vercliff Digital Service (DS).

## Mistral
aka Project Mistral, the service request triage pilot, the Nordale pilot

Pilot of an AI service request triage tool for three service centers at Nordale, hosted on Fennel. Currently scoping; target date 19 March.

- owner: Yael Ellery; sponsor: Xiaoling Taufa; stage: currently scoping; target: 19 March
- people: Yael Ellery, Imani Navarro, Rudo Thornbury, Naoko Sandoval, Cassandra Yilmaz, Bilal Kahananui, Thibault Sahin, Mei Obi, Xiaoling Taufa
- orgs: Nordale Department of Transportation

## Fennel
aka the platform, the common platform, Fennel platform

Cassandra's team runs Fennel, the shared AI platform that department projects build on. Onboarding tenants.

- owner: Cassandra Yilmaz; sponsor: Kayode Whitfield; stage: onboarding tenants
- people: Cassandra Yilmaz, Imani Navarro, Yael Ellery, Rudo Thornbury, Naoko Sandoval, Thibault Sahin

## Pothole Reporting Tool Selection
aka the pothole reporting bake-off, the Marmara/Ethura evaluation, PRTS selection

Selecting a tool for pothole reporting at Selfell; Marmara and Ethura are in the running. Gathering requirements; target date 5 April.

- owner: me; sponsor: Alejandro Carmichael; stage: gathering requirements; target: 5 April
- people: Imani Navarro, Tendai Santos, Catrin Kuznetsova, Nomvula Jansen
- orgs: Selfell Public Works, Marmara Labs, Ethura Systems

## Ivyworth Records Requests Discovery
aka the Ivyworth discovery, the records requests work, IRRD discovery

Discovery with Ivyworth on records requests; the problem framing is still moving. Planning; target date 14 April.

- owner: Hiba Jaber; sponsor: Kayode Whitfield; stage: planning; target: 14 April
- people: Hiba Jaber, Imani Navarro, Niamh Kovalenko
- orgs: Ivyworth Housing Services

## Fennel Funding Model
aka the recharge model, the funding options, Fennel recharge

Funding options for Fennel across departments, ahead of the Digital Steering Committee. Collecting inputs; target date 12 April.

- owner: me; sponsor: Kayode Whitfield; stage: collecting inputs; target: 12 April
- people: Imani Navarro, Yael Ellery, Rudo Thornbury, Naoko Sandoval
- orgs: Nordale Department of Transportation

## AI in Public Service Workshop
aka the workshop, the Selfell workshop, the AI in public service session

Imani is organizing the AI in public service workshop for caseworkers at Selfell; I own the slides. Sorting out logistics; target date 19 March.

- owner: Imani Navarro; sponsor: Kayode Whitfield; stage: sorting out logistics; target: 19 March
- people: Imani Navarro, Tendai Santos, Catrin Kuznetsova, Nomvula Jansen
- orgs: Selfell Public Works

## Inspection Scheduling Advisory
aka the inspection scheduling advice, Selfell inspection scheduling advisory

Light-touch advice to Selfell on inspection scheduling; no deliverables of our own. Advising as needed.

- owner: Tendai Santos; sponsor: Kayode Whitfield; stage: advising as needed
- people: Tendai Santos, Imani Navarro, Catrin Kuznetsova
- orgs: Selfell Public Works

## Talton Partnership
aka the Talton relationship, Talton

Keeping the relationship with Talton warm: introductions, catch-ups and favours. Ongoing.

- owner: me; sponsor: Kayode Whitfield; stage: ongoing
- people: Imani Navarro, Yael Ellery
- orgs: Nordale Department of Transportation, Talton Institute for Public Service Design

## Selfell Parking Analytics Idea
aka Tendai's parking analytics idea, the parking analytics placeholder

Placeholder for Tendai's parking analytics idea at Selfell; waiting on a problem statement. Waiting on a problem statement.

- owner: Tendai Santos; sponsor: Kayode Whitfield; stage: waiting on a problem statement
- people: Tendai Santos, Imani Navarro
- orgs: Selfell Public Works

## Marmara Code Enforcement Diligence
aka the Marmara deep dive, the code enforcement diligence

Diligence on Marmara's code enforcement offering; enthusiasm early, nothing dated since. In diligence.

- owner: me; sponsor: Kayode Whitfield; stage: in diligence
- people: Imani Navarro
- orgs: Ormmarsh Parks and Recreation, Marmara Labs, Ethura Systems

## Library Help Learning Series
aka the learning series, the library help talks

A library help learning series for caseworkers, run with Talton. Quiet; no sessions booked.

- owner: Imani Navarro; sponsor: Kayode Whitfield; stage: quiet; no sessions booked
- people: Imani Navarro, Meera Chebet
- orgs: Ormmarsh Parks and Recreation, Talton Institute for Public Service Design

## Long-running items

- asked Tendai to send me the parking analytics problem statement
- asked Anh to send me the Ethura deep-dive materials

## Who's who

- Yael Ellery: Program Manager, Nordale Department of Transportation
- Xiaoling Taufa (goes by Ling): Department Director, Nordale Department of Transportation
- Imani Navarro: Director of Delivery, Vercliff Digital Service
- Rudo Thornbury: Records Manager, Nordale Department of Transportation
- Naoko Sandoval: Web Coordinator, Nordale Department of Transportation
- Cassandra Yilmaz: Principal, Platform Engineering, Vercliff Digital Service
- Bilal Kahananui: Chief Information Security Officer, Vercliff Digital Service
- Thibault Sahin: Platform Engineer, Vercliff Digital Service
- Mei Obi: Product Lead, Resident Services, Vercliff Digital Service
- Kayode Whitfield: Chief Digital Officer, Vercliff Digital Service
- Alejandro Carmichael: Department Director, Selfell Public Works
- Tendai Santos: Customer Service Manager, Selfell Public Works
- Catrin Kuznetsova: Records Manager, Selfell Public Works
- Nomvula Jansen: Web Coordinator, Selfell Public Works
- Hiba Jaber: Operations Manager, Ivyworth Housing Services
- Niamh Kovalenko: Business Analyst, Ivyworth Housing Services
- Meera Chebet: Chief of Staff, Ormmarsh Parks and Recreation
- Anh Novotny: Account Executive, Ethura Systems
