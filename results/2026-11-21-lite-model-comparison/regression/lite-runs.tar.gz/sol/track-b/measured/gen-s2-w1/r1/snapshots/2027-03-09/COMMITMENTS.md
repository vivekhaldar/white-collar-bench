# Commitment ledger — current through 2027-03-09

Dates below are first evidenced commitment/request dates unless stated otherwise. **Open** means no completion evidence in supplied inputs, not necessarily overdue. No deadline is known except where stated. Project context and change history: PROJECTS.md.

## Dina's accepted tasks, self-assigned work and reopened items

| Item | Counterparty | State / date | Evidence |
|---|---|---|---|
| Write Mistral API contract v1 | Yael | Open request, 22 Feb; no explicit acceptance in inputs | em-0010 |
| Review Fennel model allow-list | Cassandra | Open, accepted 23 Feb | ch-0010, ch-0012, em-0035 |
| Update Mistral pilot charter after Bilal's comments | Mistral team / Bilal dependency | Open conditional commitment, 24 Feb; comments receipt unknown | mt-0003 |
| Convert workshop questions into FAQ | Workshop team | Individual task unresolved, 25 Feb; project closed 8 Mar, not proof FAQ done/cancelled | mt-0004, em-0086 |
| Introduce Imani to Tendai for permit intake | Imani / Tendai | Open, accepted 1 Mar | ch-0038, mt-0012 |
| Send Mistral dependency list | Cassandra | Open, promised 1 Mar | ch-0039 |
| Send Mistral one-page summary | Imani | Open, promised 2 Mar | mt-0008 |
| Send Mistral stakeholder map | Cassandra | Open, self-assigned 5 Mar | nt-0007 |
| Send Mistral vendor comparison | Thibault, expectation relayed by Naoko | Open, **accepted 8 Mar**; morning Cassandra offer is separate | ch-0077, ch-0073 |
| Walk Cassandra through Mistral equity impact review | Cassandra | Open, self-assigned 8 Mar; scheduled 11 Mar 14:00–14:30 (-07:00), invite acceptance unknown | nt-0009, ca-0009 |
| Friday status note for w/e 12 March | Kayode | Due end of Friday **12 Mar**; half-page moved/slipped/leadership needs | em-0081 |

The API-contract request is included for visibility, but has less acceptance evidence than Dina's explicit promises. The architecture-diagram offer was completed 9 March (`ch-0080`). Slides were Dina's responsibility from baseline (`nt-0001`); workshop explicitly closed 8 March (`em-0086`), but individual slide delivery is not confirmed. Remaining workshop deliverables below have no individual closure evidence; do not automatically chase them as live event logistics or mark them delivered.

## Waiting on others / delegated responsibilities

| Item | Responsible → recipient | Latest state | Evidence |
|---|---|---|---|
| Parking analytics problem statement | Tendai → Dina | Waiting; promise dated 22 Feb, forwarded 24 Feb | nt-0001, em-0017 |
| Ethura deep-dive materials | Anh → Dina | Long-running request; no new response | nt-0001 |
| Publish Fennel tenant onboarding guide | **Imani** | Open, **transferred from Cassandra 25 Feb**; earlier Cassandra promise 22 Feb | ca-0001, ch-0015, em-0026, ch-0024 |
| Configure Nordale Fennel SSO broker | Thibault | In progress/resumed 24 Feb; not complete | em-0016, em-0020 |
| List of pilot service centers for Mistral | Yael → Dina | Accepted 24 Feb, not received; names unknown | ch-0021 |
| Inspection scheduling advisory options note | Catrin → Dina | **Confirmed 26 Feb**, still waiting; previously possible | nt-0002, ch-0031 |
| Selfell use-case list | Tendai → Dina | Offered/accepted 27 Feb; not received; precise project unspecified | ch-0034 |
| Talton working paper | Penelope → Dina | Promised 27 Feb; not received | ch-0035 |
| Workshop run sheet | Catrin → Dina | Accepted 2 Mar; not received | ch-0047 |
| Fennel data dictionary | Imani → Dina | Promised 2 Mar; not received | ch-0049 |
| Fennel tenant gateway rate limits | Thibault | Assigned/reported 2 Mar; **Dina blocked until delivery, chased 9 Mar**; still no completion | ch-0050, em-0092 |
| Mistral service blueprint | Naoko → Dina | Promised 2 Mar; on track/waiting on others 4 Mar, no delivery | em-0051, mt-0014 |
| Mistral action log | Yael → Rudo | Promised, Dina reporting 3 Mar; not Dina's deliverable | ch-0056 |
| Workshop feedback form | Nomvula → Dina | Offered/accepted 3 Mar, recapped 4 Mar; **resumed 9 Mar**, not received; project stays closed | ch-0057, ch-0066, ch-0079, em-0086 |
| Marmara security questionnaire (pothole selection) | Siti → Dina | Promised return 4 Mar; not returned | em-0060, mt-0016 |
| Rebase funding-model usage forecast | Freja Mutasa (Budget Director) | Imani reports assignment 4 Mar; not complete | ch-0060 |
| Mistral decision memo, intended for Yael | **Thibault**, transferred from Dina | **Handed off 5 Mar**; no final delivery to Yael confirmed | mt-0009, em-0068 |
| Workshop session outline | Imani → Dina | Nomvula reports 6 Mar that Imani will share; not received; project closed 8 Mar | ch-0072, em-0086 |
| Funding-model status slide | Imani → Dina | Promised 8 Mar; not received | mt-0018 |
| Fennel architecture diagram | Cassandra → Dina | Accepted Dina's request 8 Mar; not received | mt-0018 |
| Talton catch-up response | Penelope → Dina | Catch-up **on hold** 8 Mar until Dina hears back; no date/details | em-0065, ch-0076 |
| Funding model chargeback scenarios | Imani Navarro → Dina | Incoming, Dina's note 9 Mar; not received | nt-0010 |
| Fennel help-desk script | Imani Navarro → Dina | Promised/accepted 9 Mar; not received | ch-0084 |
| Inspection-scheduling session notes, involving Torthen Civic | **Imani Quaye (@imaniq)** → Dina | Promised/accepted 9 Mar; not received; not Navarro, Selfell linkage unknown | ch-0081, 9 Mar manifest |
| Pothole reporting session notes | **Magdalena Shapiro (Magda)** → Dina | Offered/accepted 9 Mar; not received; exact organization/project linkage unknown | ch-0082, 9 Mar manifest |

## Tentative / requested but not agreed

Do not promote these to firm commitments based on reactions, 'got it', or a recap.

| Item | Who / context | Evidence |
|---|---|---|
| Review Yael's Fennel RACI chart | Dina; request via Imani 23 Feb; Dina asked to come back; Yael clarified nothing agreed 24 Feb | ch-0007, ch-0020 |
| Review Bilal's Mistral training outline | Dina; 24 Feb: check workload and come back | mt-0003 |
| Send parking-analytics reading list to Waian Nakamura | Dina; 24 Feb conditional 'could ... if useful' | mt-0002 |
| Send Tendai workshop room plan | Dina; 26 Feb 'check and get back'; 1 Mar recap explicitly nothing agreed | ch-0028, mt-0007 |
| Workshop speaker brief | Catrin → Dina; request not agreed 1 Mar | ch-0043 |
| Workshop registration list | Catrin → Dina; might send, nothing confirmed 4 Mar | ch-0063 |
| Review Imani's records discovery observation notes | Dina; 5 Mar 'maybe', see how week goes | mt-0015 |
| Pull records requests baseline data from Ivyworth | Niamh; possible 5 Mar, not confirmed | nt-0007 |
| Review Cassandra's Fennel accessibility review | Dina; new request relayed by Yael 6 Mar, no answer | em-0077 |
| Send Mistral vendor comparison to Cassandra | Dina offered 8 Mar; Bilal said 'good to know', no Cassandra acceptance. Later firm promise is to Thibault, not explicit transfer | ch-0073, ch-0077 |
| Send Mistral retention schedule to Yael | Dina 8 Mar: 'try ... no promises'; **Imani relays need by 11 Mar** on 9 Mar, no firm acceptance | mt-0017, ch-0078 |
| Look into Mistral duplicate notifications | Automatic recaps assign Dina 8/9 Mar; still lower confidence, no direct acceptance/completion | mn-0003, mn-0005 |
| Update Mistral access request after Bilal's comments | Bilal requests Dina 9 Mar, **wanted by 10 Mar**; no acceptance, comments absent; distinct from charter | em-0094 |
| Send records discovery findings summary to Imani | Direct request 9 Mar; automatic recap says Dina picking it up; no direct acceptance/delivery | em-0095, mn-0004 |
| Review Imani's pothole reporting selection decision memo | Dina, assigned only by automatic 9 Mar 1:1 recap; no direct acceptance/completion | mn-0004 |
| Review Imani's Fennel metrics definition | Dina; requested 9 Mar, no answer or completion | em-0100 |
| Set up Mistral dashboard access | Cassandra → Dina; requested 9 Mar, Cassandra replies to small talk only; no acceptance/setup | ch-0083 |
| Share Mistral accessibility review | Rudo → Dina; 'maybe I should' 9 Mar, tentative, not received; not Fennel review | mt-0019 |

## Completed and historical events (not open tasks)

| Completed date | Item / parties | Evidence |
|---|---|---|
| 22 Feb | Dina sent Mistral solution brief to Bilal | em-0004, em-0005; recaps ch-0016, ch-0036, mt-0006, em-0074 |
| 22 Feb | Dina sent pothole selection requirements to Nomvula; received | ch-0001, ch-0002; recaps ch-0008, ch-0009, ch-0014, em-0037 |
| 23 Feb | Dina reviewed Nathaniel's Marmara diligence notes | ch-0005, ch-0006 |
| 23 Feb | Dina wrote Imani's inspection-scheduling fellowship reference; received | ch-0004, ch-0013, ch-0018; recap mt-0005 |
| 24 Feb | Cassandra's Mistral tenant provisioning looked fine from Dina's side | ch-0017, em-0023; not a general platform sign-off |
| 25 Feb | Dina confirmed Mistral risk register with Imani | ch-0019, em-0027; recaps ch-0029, em-0037, mt-0006, ch-0040, ch-0042, em-0074 |
| 25 Feb | Dina confirmed Fennel test plan with Imani — **historical only; reopened 2 Mar** | nt-0003, ch-0023, ch-0033, em-0037; superseded by em-0052 |
| 25 Feb | Dina joined Bilal's benefits-screening panel | ch-0011, ch-0025 |
| 25 Feb | Dina sent Fennel status slide draft to Rudo | mn-0001, em-0031, dc-0001 |
| 26 Feb | Imani sent workshop post-event survey | ch-0027, em-0034; event itself not confirmed occurred |
| 26 Feb | Dina sent weekly status note to Kayode, 17:04 -07:00 | em-0001, em-0037 |
| 27 Feb | Imani sent Mistral test plan v1 to Naoko | em-0040, em-0043, dc-0002 |
| 2 Mar | Dina sent records discovery site visit agenda to Imani | mn-0002, mt-0008 |
| 3 Mar | Dina sent Mistral RACI chart to Ling; received | ch-0046, ch-0051 |
| 4 Mar | Dina sent Mistral requirements matrix to Imani; received | em-0055, ch-0061 |
| 4 Mar | Dina sent Mistral support model to Imani | nt-0006, em-0066 |
| 5 Mar | Dina sent weekly status note to Kayode, 16:21 -07:00 | em-0044, ch-0053, em-0074 |
| 6 Mar | Dina confirmed records discovery interview guide with Imani | ch-0071, em-0080 |
| 8 Mar | Dina sent Mistral change request v1 to Imani (promised 2 Mar) | mt-0008, em-0082, dc-0004 |
| 8 Mar | Mistral rollout checklist available/in use; Dina says it covers her needs; actual send time unknown | ch-0074; earlier nt-0004, ch-0052, ch-0070 |
| 8 Mar | Dina re-confirmed Fennel test plan with Imani, closing 2 Mar reopening | ch-0075; history nt-0003, ch-0023, em-0052 |
| 8 Mar | Yael sent Fennel evaluation rubric v2 to Dina | em-0090, dc-0005; promise ch-0067 |
| 8 Mar | Imani explicitly reported AI in Public Service Workshop complete; individual residual task delivery unknown | em-0086 |
| 8 Mar | Esi set up Ethura sandbox access; not evidence Dina logged in/tested | em-0089 |
| 9 Mar | Dina sent Mistral architecture diagram to Imani; explicit send statement, Imani +1; contents absent | ch-0080; earlier offer em-0076 |
| 9 Mar | Dina sent funding options memo to Kayode, 14:49 -07:00; closes task ahead of revised 16 Mar deadline | em-0096; deadline ch-0064, agenda ca-0007 |
| 9 Mar | Imani sent funding model cost model to Dina; contents absent | em-0097; automatic action mn-0004 |
| 9 Mar | Dina confirmed records discovery process map with Imani, 16:20 -07:00 | em-0098; history mt-0011, mt-0013, nt-0008 |
| 9 Mar | Thibault reports Fennel timeout errors fixed earlier today; Dina thanks him and confirms a link works; no gateway/SSO completion implied | ch-0085; earlier offer em-0099 |

## Superseded / stopped (not completed)

- **Ivyworth data-sharing agreement:** requested Hiba countersign 2 March (`nt-0005`); unsigned and blocking through 5 March (`ch-0045`, `mt-0013`, `em-0074`). **Dina stopped pursuing it 8 March, explicitly superseded by approach C for the records discovery opportunity list** (`nt-0008`). No signature; no longer an open countersign/chase loop. Process-map confirmation subsequently completed 9 March (`em-0098`), without evidence of a signed agreement.

### Known unknowns
No confirmed individual delivery for items remaining in the open/waiting/tentative tables. Most tasks have no exact deadline; 10 Mar access-request update and 11 Mar retention schedule are requested dates, not Dina's accepted deadlines. Service-center names, signed agreement, approach C details, final procurement/funding decisions, and final workshop logistics/deliverable contents remain unknown. New delivered diagram, memo and cost model contents are absent. Workshop project completion is explicitly reported (`em-0086`), not inferred from survey title. Supplied attachment contents are `dc-0001`–`dc-0005`: Fennel slide draft, Mistral test plan v1, Mistral solution brief v2, Mistral change request v1, Fennel evaluation rubric v2. Dates of recaps are not dates of fresh deliveries.
