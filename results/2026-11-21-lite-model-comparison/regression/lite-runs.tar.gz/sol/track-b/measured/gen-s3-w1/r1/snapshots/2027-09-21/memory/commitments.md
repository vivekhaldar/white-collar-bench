# Action ledger — through 21 September 2027

No due date is supplied for open individual actions below unless explicitly noted. Portfolio targets are not automatically action deadlines. "Pending" means no completion in the available evidence, not proof nothing happened. Repeated messages about the same action are deduplicated.

## Alasdair's accepted/offered work still open

| Project / recipient | Action | Evidence / qualification |
|---|---|---|
| Okapi | Write API contract v1 | Offered in standup 7 Sep; no delivery. [mt-0004] |
| Okapi / Bisi Chatterjee | Update retention schedule after Bisi's comments | Explicit "I'll" 8 Sep; reaffirmed 9 Sep. [ch-0013, ch-0026] |
| Okapi / Bisi Chatterjee | Send order set review | Explicit "I'll" 13 Sep. [em-0038] |
| Okapi / Bisi Chatterjee | Send accessibility review | 17 Sep generated recap assigns action; 20 Sep leads-call note says **blocked, waiting on a vendor fix**. Vendor/fix/ETA unknown, not completed or cancelled. [mn-0007, mn-0008] |
| Okapi / Bisi Chatterjee | Send action log | Direct accepted commitment 20 Sep 14:25; 21 Sep 22:25 artifact is **X-Draft: true**, attachment not yet added. Still pending, not sent; actual log content unavailable. [ch-0086, em-0089] |
| Okapi | Look into slow page loads | 21 Sep generated standup assigns Alasdair; no investigation completion. Distinct from Dina's completed timeout fix and accessibility vendor fix. [mn-0009, ch-0096] |
| Okapi / Penelope Romano | Walk through downtime procedure | Direct commitment 20 Sep 18:25, Penny accepts. Worker-organized invite **Thu 23 Sep 14:00–14:30 UTC−05:00**; attendee NEEDS-ACTION despite chat acceptance. No walkthrough completion/procedure text. [ch-0087, ca-0009] |
| Bed management / Friederike Haidari | Set up coffee about bed management | Direct "will do" 21 Sep 10:46; no scheduled time, venue or completion. [ch-0090] |
| Referral triage / Bisi Chatterjee | Send discovery site-visit agenda | 8 Sep generated recap; 9 Sep Eleni reminder corroborates offer. [mn-0002, ch-0025] |
| Rosix Enterprise / Eun-ji Chen | Draft counter-proposal to Rosix | Offered 7 Sep; no task completion evidenced, but agreement now signed/complete. May no longer be required; do not assert cancellation. [ch-0006, ch-0064] |
| Rosix Enterprise / Bisi Chatterjee | Confirm enterprise-agreement dependency list with Bisi | Tentative "I could ... if useful" 7 Sep; Bisi only "Right". Treat as offer, not firm acceptance; no completion, project complete. [mt-0006, ch-0064] |

## Waiting on other people: accepted or relayed promised actions

| Person | Project / awaited item | Evidence / latest state |
|---|---|---|
| Nurlan Jansen | Provision Okapi tenant on Sirocco | Dina accepted request 9 Sep; **handoff to Nurlan** 10 Sep. Chase Nurlan, not Dina. No completion. [mt-0008, em-0028] |
| Dina Laurent | Publish Sirocco tenant onboarding guide | Penelope relayed promise 8 Sep; no delivery. [ch-0016] |
| Nurlan Jansen | Set gateway rate limits for Sirocco tenants | Offered/assigned in 21 Sep generated Okapi standup; no completion. Separate from SSO and tenant provisioning. [mn-0009] |
| Nurlan Jansen | Configure Ketford Sirocco SSO broker | Bisi relayed 13 Sep, recap 14 Sep; worker directly chased 20 Sep, Nurlan acknowledged, not delivered. Separate from tenant provisioning. [ch-0041, ch-0048, ch-0083] |
| Dina Laurent → Eleni Fontaine | Okapi comms plan | Dina directly accepted Eleni's request 13 Sep. Not an Alasdair action. [mt-0011] |
| Katarzyna Dang | Line up referral-triage nurse interviews | Direct commitment 6 Sep; no interview scheduling details/completion. [mt-0001] |
| Bisi Chatterjee | Referral-triage discovery observation notes | Direct "I'll send Alasdair" in 20 Sep transcript; no delivery. Distinct from unagreed findings summary and superseded current process map. [mt-0013, ch-0042, nt-0006] |
| Guadalupe Moreau | Lanmoor bed-management baseline data | Lupe promised 10 Sep; no delivery; relevance after pivot unknown. [em-0030, ch-0046] |
| Vitoria Oduro | Share bed-management discovery change request | Bisi relayed promise 13 Sep. Vitoria reports unblocked/moving 14 Sep, **not** that she sent it. [ch-0041, ch-0045] |
| Guadalupe Moreau | Outpatient no-shows wait-time export | Direct "yep, on it" 17 Sep. No delivery. [ch-0076] |
| Guadalupe Moreau | Discharge-summary problem statement | Longstanding wait, 6 Sep "on it". [nt-0001, ch-0002] |
| Sneha Thornbury | Kasis deep-dive materials | Longstanding wait; no later delivery. [nt-0001] |
| Sneha Thornbury | Two Kasis customer references | Relayed promise 15 Sep; direct 21 Sep "picking ... back up now" confirms work resumed, not delivered. Not completed Rosix references; no earlier Kasis completion evidenced. [ch-0053, em-0087] |
| Adebayo Kalua | Notes from intake forms session | Two chats same 14 Sep promise, one action. Invite 17 Sep not a delivered document. [ch-0049, ch-0050, ca-0007] |
| Platform lead (unnamed in action note) | Set up intake-forms selection dashboard access for Alasdair | Worker records dependency 20 Sep; no independent assignee acceptance/delivery. Dina is mapped platform owner, but **specific assignee not confirmed**. [nt-0007, nt-0001] |
| Bisi Njoroge | Rosix volume tiers | Same 7 Sep promise repeated twice. No delivery; enterprise agreement now complete, task necessity unknown. [ch-0009, ch-0010, ch-0064] |
| Bisi Chatterjee | Rosix enterprise-agreement term sheet | Direct acceptance in 8 Sep funding-options meeting (not Bisi Njoroge). No delivery; agreement complete. [mt-0007, ch-0064] |

## Requested, tentative, or unaccepted — not firm commitments

| Action | State / evidence |
|---|---|
| Answer Bisi Chatterjee's after-hours support question on intake forms selection | Raised 10 Sep, Alasdair only said check workload/come back. Explicit **not agreed** recaps 14, 15 and 17 Sep. Still unresolved request, not an overdue accepted answer. [mt-0010, ch-0044, ch-0051, ch-0052, em-0060] |
| Review Sirocco model allow-list for Dina | Penelope relayed expectation 16 Sep; Alasdair "let me check and get back to you". Not accepted review. [ch-0071] |
| Review Bisi Chatterjee's Sirocco bed census extract | Email request 20 Sep; no acceptance, attachment/content, due date or delivery. Not Lupe's baseline data or no-shows export. [em-0071] |
| Send Katarzyna Okapi evaluation rubric | 20 Sep "I'll try ... no promises" remains tentative. 21 Sep Bisi relays **Thu 23 Sep** need-by, edited from Fri 24 Sep; worker "good to know" is not firm acceptance. Unspecified link-working exchange is not delivery evidence. [mt-0014, ch-0092] |
| Send Eleni referral-triage discovery interview guide | Requested **by Wed 22 Sep**, no acceptance or delivery. Not site-visit agenda or superseded map. [em-0085] |
| Review Somchai's funding-model pricing options table | Request 21 Sep; no acceptance, table content/attachment, deadline or delivery. [em-0081] |
| Review Nurlan's Okapi stakeholder map | "Maybe I should" 13 Sep; no firm agreement. Transcript "Nurlanne" likely Nurlan. [mt-0012, nt-0001] |
| Bisi to send referral-triage findings summary | Eleni says "could probably", explicitly not agreed 14 Sep. [ch-0042] |
| Send Bisi Chatterjee denials-analytics reading list | Alasdair "I could ... if useful" 9 Sep; audio interruption, no clear acceptance or delivery. [mt-0008] |

## Completed / delivered — do not continue chasing

| Action | Completion / chronology |
|---|---|
| Update funding-model assumptions log after Deniz's comments | Done 6 Sep by Alasdair email. [ch-0001, em-0002] |
| Pilot wards list from Katarzyna | Requested in 6 Sep standup, sent same day. Actual ward names unavailable. [mn-0001, mt-0002, ch-0004] |
| Lupe countersign Lanmoor data-use agreement | Promised by Thu 16 Sep; **done Mon 6 Sep**. [ch-0003, ch-0005] |
| Confirm Okapi pilot charter with Dina | Committed 7 Sep 18:15, confirmed 20:34. [ch-0011, ch-0012] |
| Send Katarzyna Okapi solution brief (Alasdair + Bisi offer) | Sent v3 8 Sep; Bisi and later recap confirm. One action, not still owed by Bisi separately. [mt-0005, em-0017, em-0018, mn-0004] |
| Review Dina's Okapi risk register | Accepted 10 Sep; reviewed 13 Sep. [ch-0031, em-0037] |
| Circulate intake-forms selection scorecard | Accepted request via Bisi 13 Sep; sent Somchai v3 same day. [ch-0041, em-0040, dc-0003] |
| Two Rosix customer references | Collected 7 Sep [em-0012], **reopened** 9 Sep wrong group [ch-0022], promised again/recollected 14 Sep [em-0044, em-0045], reaffirmed 15 Sep [ch-0057]. Current completed, no reference contents/names supplied. |
| Okapi requirements matrix from Bisi | Delivered v2 15 Sep [em-0053, dc-0004], supersedes same-day waiting note [nt-0005]. |
| Pull together Okapi vendor comparison with Penelope | Offered 13 Sep, completed 15 Sep. [mt-0012, ch-0058] |
| Kwame return Rosix master-agreement redlines | Promised and completed 15 Sep, corroborated by Eun-ji; status note repeats 17 Sep. [ch-0053, ch-0059, ch-0060, em-0066] |
| Scope two-week outpatient no-shows sprint | Relayed commitment, scoped 16 Sep and acknowledged by Lupe. Scoping done, not implementation. [ch-0065, ch-0068] |
| Funding-model usage forecast from Bisi | Promised and sent 16 Sep. Do not confuse with cancelled Deniz rebase. [ch-0070, ch-0072] |
| Okapi budget justification from Bisi | Promised 16 Sep; incorporated into deck 17 Sep, evidence received. [ch-0063, ch-0079] |
| Friday status note to Tunde, w/e 10 Sep | Due EOD 10 Sep [em-0001], sent 16:53 that day [em-0031]. |
| Friday status note to Tunde, w/e 17 Sep | Due EOD 17 Sep [em-0033], sent 17:19 that day [em-0066]. |
| Confirm bed-management discovery process map with Oluwaseun | Lupe relayed expectation, accepted 20 Sep 08:15; worker reports **done 09:22**, Lupe/Vitoria acknowledge. Not referral-triage map. [ch-0081, ch-0082] |
| Confirm Sirocco vendor comparison with Bisi | Accepted 17 Sep; worker reports confirmed earlier **20 Sep**, at 12:13. Distinct from Okapi comparison. [em-0062, ch-0077, ch-0078, ch-0084] |
| Send Sirocco operating-model review comments to Bisi | Requested 14 Sep; worker says sent **20 Sep 13:04**, Bisi acknowledges. Same-day worker note says "I'll" but no writing time; direct delivery outranks stale todo. Content unavailable. [ch-0047, nt-0007, ch-0085] |

### Additional completions on 21 September

| Action | Completion / chronology |
|---|---|
| Send funding-model budget justification to Bisi | Accepted 20 Sep; worker says sent 21 Sep **07:31**, Bisi acknowledges receipt 07:32. Content unavailable; not Okapi justification. [em-0075, ch-0088, ch-0089] |
| Run funding-model sensitivity analysis for Deniz | Accepted 20 Sep after previously unagreed request; worker email **21 Sep 09:23** says ran it. Results unavailable. Not cancelled forecast rebase. [ch-0073, nt-0007, em-0080, ch-0061] |
| Write Dina prior-authorization fellowship reference | Worker reports wrote it earlier that day in 21 Sep 15:00–15:30 transcript. Writing done, no evidence sent/submitted; content unavailable. [em-0021, ch-0024, mn-0006, mt-0015] |
| Send Bisi Sirocco acceptance criteria, with Dina | Direct commitment 21 Sep 14:32; worker reports sent earlier at **17:57**. No contents or Bisi receipt acknowledgement. [em-0084, ch-0095] |
| Intake-forms selection demo script | Bisi relays "Emberbury lead" will send 21 Sep; **18:30** worker email says pulled into deck, thanks Somchai. Delivery/incorporation complete; earlier unnamed assignee resolved contextually by later email, not role guess. Script content unavailable. [ch-0093, em-0088] |
| Dina fix Okapi timeout errors | Promised 21 Sep 17:35; reports fixed earlier that day at **21:08**, worker check-mark reaction. Reported completion, not independent verification; does not close slow page-load investigation/accessibility fix. [ch-0094, ch-0096] |

## Dropped / withdrawn

- **Bisi's Okapi clinical safety case:** 10 Sep generated recap suggested Alasdair, explicitly no owner agreed [mn-0003]. Worker dropped as no longer needed 15 Sep [nt-0005]; reaffirmed in status 17 Sep [em-0066]. Not an active review or completed safety case; does not prove security review closure.
- **Funding-options memo to Tunde:** 9 Sep worker "maybe ... not committed" [nt-0003]; 13 Sep no longer needed [nt-0004]. Cancelled proposal, not delivered memo.
- **Deniz rebase funding-model usage forecast:** 13 Sep desired but not agreed [ch-0039]; 16 Sep withdrawn as duplicate [ch-0061]. Do not retain as Deniz's outstanding action. Later accepted sensitivity analysis is distinct [nt-0007].
- **Current referral-triage process map from Eleni:** requested 7 Sep, blocked worker 8 Sep, not delivered in evidence [em-0011, ch-0014, ch-0015, em-0023]. **Superseded/cancelled 20 Sep** by worker's **approach B** decision; no longer an active wait. Replacement map details/owner/due date unknown. Do not cancel other referral-triage actions or claim map delivery. [nt-0006]

## Dated administrative action

- **Friday status note w/e 24 Sep:** weekly reminder asks Alasdair to send Tunde half a page (what moved/slipped/leadership needs) by **EOD Fri 24 Sep**; no completion/extension supplied. [em-0068]
- IT ticket **REQ-15950** (VPN drops hourly) marked resolved 20 Sep but asks worker to confirm issue fixed; confirmation not evidenced. Distinct ticket ID from INC-70165; no automatic closure of older IT tasks. [em-0073, em-0051]

## Project-level closures (not proof all actions were done)

- Sirocco Operating Model Review complete 15 Sep. [ch-0056]
- Rosix Enterprise Agreement signed and complete 16 Sep. [ch-0064]
