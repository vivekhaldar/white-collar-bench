# People and aliases

Roles and affiliations are from the 6 September portfolio map unless another source is cited. [nt-0001]

| Person | Role / affiliation | Context |
|---|---|---|
| Alasdair Kaya | Worker, Clinical Digital Services (CDS), Birchmere Health Partners; precise job title not supplied | Owns intake forms selection, Sirocco Funding Model, Talwick relationship, Dalett diligence. Transcript “Alasdair's iPhone” / “Alasdair Kaya (Guest)” refer to worker speaker devices. [nt-0001, mt-0005, mt-0010, mt-0011] |
| Tunde Andersen | Chief Digital Officer, CDS | Sponsor of all mapped projects except Okapi; receives Friday status notes, next due EOD 24 Sep. [em-0001, em-0031, em-0033, em-0066, em-0068] |
| Bisi Chatterjee | Director of Digital Programs, CDS | Usually “Bisi” in core project channels; frequent relayed requests, partnership with worker. **Not Rosix AE Bisi Njoroge**. |
| Katarzyna Dang | Director of Pharmacy, Ketford General Hospital | **Kasia**; owns Okapi and Ketford Referral Triage Discovery. [nt-0001, ch-0063] |
| Victoria Hoffmann | Chief Medical Information Officer, Ketford General Hospital | Okapi sponsor; confirms four-ward decision. [em-0065] |
| Eleni Fontaine | Revenue Cycle Analyst, Ketford General Hospital | **Lena** in her DMs, Bisi uses Lena in process-map reminder. Prior current referral-triage map wait **superseded by approach B** 20 Sep, not delivered; recipient of Dina comms plan. [ch-0015, ch-0025, ch-0042, mt-0011, nt-0006] |
| Dina Laurent | Principal, Integration Platform, CDS | Sirocco platform and operating-model owner. Transcript “Dinah” refers to Dina. Tenant provisioning handed to Nurlan. Fellowship reference written by worker 21 Sep (sending unknown); reports Okapi timeout errors fixed that day. [mt-0008, em-0028, em-0021, mt-0015, ch-0096] |
| Penelope Romano | Principal, Information Security, CDS | **Penny** in her DM. Joint Okapi vendor comparison; relays Sirocco requests. Accepted worker's Okapi downtime walkthrough; invite Thu 23 Sep 14:00–14:30 UTC−05:00. [ch-0077, ch-0078, mt-0012, ch-0087, ca-0009] |
| Nurlan Jansen | Integration Engineer, CDS | Took over Okapi tenant provisioning; Ketford SSO broker still awaited in 20 Sep direct chase [ch-0083]. Transcript “Nurlanne” probably Nurlan, not independently identified new person. [em-0028, ch-0041, mt-0012] |
| Giorgi Villanueva | Product Lead, Clinical Apps, CDS | Okapi team. |
| Somchai Thapa | Director of Patient Access, Emberbury Rehabilitation Center | Intake-forms and funding-model stakeholder. Reports stage changes, receives scorecard; requested pricing-options table review (unaccepted) and thanked for demo script incorporated in deck 21 Sep. Earlier "Emberbury lead" relayed script promise does not itself identify a unique person. [em-0006, em-0040, em-0055, em-0081, ch-0093, em-0088] |
| Catrin Kiprono | Nurse Informaticist, Emberbury Rehabilitation Center | Intake-forms, funding, Rosix stakeholder. |
| Sneha Thornbury | Account Executive, Kasis Health | Kasis materials/references; forwards Rosix reference messages but does not become owner of Rosix references. [nt-0001, em-0044, ch-0053] |
| Guadalupe Moreau | Chief Nursing Officer, Lanmoor Medical Center | **Lupe**; owns bed-management discovery and discharge-summary idea. [nt-0001, ch-0046, ch-0076] |
| Vitoria Oduro | Revenue Cycle Analyst, Lanmoor Medical Center | Bed-management change request. **Not Victoria Hoffmann**. [ch-0041, ch-0045] |
| Oluwaseun Hakobyan | Application Analyst, Lanmoor Medical Center | **Seun** likely short name in bed-management channel (contextual inference); relays data-use signature deadline. Worker confirmed bed-management discovery process map with Oluwaseun 20 Sep. [ch-0003, ch-0065, ch-0081, ch-0082] |
| Deniz Feng | Director, Finance Shared Services, Birchmere Health Partners | Finance director commenting on funding assumptions; sensitivity-analysis request. [ch-0001, em-0002, ch-0073] |
| Eun-ji Chen | Supply Chain Contracts Manager, Birchmere Health Partners | Rosix Enterprise Agreement owner; reports contract-review and signed/complete stages. [ch-0035, ch-0064] |
| Bisi Njoroge | Account Executive, Rosix Labs | “Bisi” in her DM ch-0022; Rosix tiers and customer references. **Do not conflate with Bisi Chatterjee.** [ch-0009, ch-0010, em-0012, ch-0022, em-0045] |
| Kwame Brandt | Associate General Counsel | Returns Rosix master-agreement redlines. Precise organizational unit not supplied. [ch-0053, ch-0059, ch-0060] |
| Stanley Luo | Clinical Informatics Lead, Ostport Children's Hospital | Talwick partnership contact. No new dated interaction supplied. |
| Adebayo Kalua | Role not supplied | Promised intake-forms session notes; organized related calendar invite. [ch-0049, ch-0050, ca-0007] |
| Friederike Haidari | Role / affiliation not supplied | Asked worker to set up coffee about bed management 21 Sep; he accepted, no date/venue yet. [ch-0090] |
| Lindiwe Ahmadi | Role not supplied | Relayed Dina fellowship-reference expectation. [ch-0024] |
| Femke Afolabi | Events Coordinator | Room bookings, survey and catering notices. [em-0003, em-0032, em-0048] |
| Leonard Chukwu | Conference Organizer | Regional Digital Services Summit notices. [em-0004, em-0056] |
| Goran Rattanakorn | Newsletter sender; role not supplied | Ward Round Digest. [em-0016, em-0043] |

**Unnamed action assignee:** worker's 20 Sep note says "the platform lead" will set up intake-forms selection dashboard access. Dina is mapped platform owner, so a possible referent, but the specific assignee is not confirmed. [nt-0007, nt-0001]

**Uncertain alias:** “Tori” acknowledges Okapi comparison in ch-0058. Could be a shortened name, but no explicit identity mapping supplied. Do not silently equate it with either Victoria Hoffmann or Vitoria Oduro. [ch-0058]

## Organizations

Birchmere Health Partners is parent organization; Clinical Digital Services (CDS) is worker's team. Ketford General Hospital hosts Okapi/referral-triage discovery; Emberbury Rehabilitation Center hosts intake-forms selection and participates in funding/operating-model/Rosix work; Lanmoor Medical Center hosts bed-management/discharge-summary work. Rosix Labs and Kasis Health are vendors; Dalett Clinical is interpreter-booking diligence vendor. Talwick Nursing Research Collaborative is relationship organization alongside Stanley at Ostport Children's Hospital. [nt-0001]
