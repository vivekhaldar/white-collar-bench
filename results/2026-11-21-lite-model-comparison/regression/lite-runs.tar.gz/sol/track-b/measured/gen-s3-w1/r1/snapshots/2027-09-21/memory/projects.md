# Portfolio — current through 21 September 2027

Baseline identities, owners, sponsors, aliases and target dates come from the worker's portfolio map [nt-0001]. Targets below are baseline targets unless explicitly updated; Okapi's target moved on 21 September. [ch-0091]

## Okapi

**Aliases:** Project Okapi; portal message routing pilot; Ketford pilot. AI patient-portal message routing pilot at Ketford General Hospital, hosted on Sirocco. Owner Katarzyna Dang (Kasia); sponsor Victoria Hoffmann; baseline stage scoping, target now **1 November**, moved from **18 October** by Katarzyna on 21 September; Victoria acknowledges. No explicit later stage change is supplied. [nt-0001, ch-0091]

**Decisions:** Use synthetic patient data until the security review closes (15 September generated standup recap; closure not evidenced). Limit pilot to **four wards** (17 September agreement with Katarzyna and sponsor confirmation). Four wards also appeared in baseline scope; the later messages explicitly confirm the limit. Ward names are not supplied. [mn-0005, ch-0075, em-0065, nt-0001]

**Delivered/completed:**
- Katarzyna sent pilot ward list 6 September; closes the standup request. [mn-0001, mt-0002, ch-0004]
- Alasdair confirmed pilot charter with Dina 7 September. [ch-0011, ch-0012]
- Solution brief v3 sent to Katarzyna 8 September; Bisi and 14 September recap confirm done. [mt-0005, em-0017, em-0018, mn-0004]
- Dina's risk register reviewed 13 September. [ch-0031, em-0037]
- Alasdair and Penelope pulled together **Okapi vendor comparison** 15 September. Distinct from the **Sirocco vendor comparison**, confirmed separately 20 September. [mt-0012, ch-0058, ch-0084]
- Bisi delivered requirements matrix v2 15 September, despite worker's undated-time note that day still saying waiting. [em-0053, dc-0004, nt-0005]
- Budget justification incorporated in deck by Alasdair 17 September; Bisi's delivery is thereby acknowledged. This **Okapi** justification is distinct from the **funding-model** justification delivered to Bisi 21 September. [ch-0063, ch-0079, em-0075, ch-0088, ch-0089]
- Dina promised to fix **Okapi timeout errors** 21 September 17:35; reported fixed earlier that day at 21:08. Worker check-mark reaction acknowledges, not independent technical verification. Distinct from slow page loads and the accessibility vendor fix. [ch-0094, ch-0096]

**Open work/dependencies:** Alasdair: API contract v1, retention schedule changes after Bisi's comments, order set review to Bisi, accessibility review to Bisi (**blocked waiting on a vendor fix**, 20 September leads-call note; vendor/fix details and ETA unknown), action log to Bisi (accepted 20 September; 21 September email is explicitly **X-Draft: true**, says attachment not yet added, so not delivered), investigation of slow page loads (21 September generated standup assignment), and downtime-procedure walkthrough to Penelope (accepted; invite 23 September 14:00–14:30 UTC−05:00). Tenant provisioning passed from Dina to Nurlan; not yet completed in evidence. Dina owes Eleni comms plan. See commitments for precise sources and uncertainty. [mt-0004, ch-0013, ch-0026, em-0038, mn-0007, mn-0008, ch-0086, em-0089, mn-0009, ch-0087, ca-0009, mt-0008, em-0028, mt-0011]

**Not active commitments:** Clinical safety case review was only suggested with no owner agreed; dropped as no longer needed by 15 September and reiterated in 17 September status. Nurlan's stakeholder map review was only a "maybe". Alasdair's 20 September offer to send Katarzyna the **evaluation rubric** is explicitly "I'll try ... no promises", not a firm commitment. Bisi's 21 September DM gives need-by **Thu 23 September**, edited from Fri 24 September; worker only says "good to know", not firm acceptance or delivery. "Link worked" refers to an unspecified link, not proof of rubric completion or dashboard access. [mn-0003, nt-0005, em-0066, mt-0012, mt-0014, ch-0092]

**Risks:** Weekly status notes say flagship timelines tight, without identifying a specific slipped milestone. Standups also raised overcommitment, scope creep, thin documentation and lack of end-user participation; these are concerns, not agreed scope changes or proven blockers. Katarzyna again worried about overcommitting in the 20 September scoping call. [em-0031, em-0066, mt-0002, mt-0004, mt-0008, mt-0003, mt-0014]

### Preserved Okapi documents

- **dc-0001**, 8 September, solution brief v3, project Okapi, prepared Alasdair: scope aligned with glossary; support needs unit input; integration to be confirmed; communications pilot group only. Open questions: usage assumptions realism and final sign-off owner. Feedback incorporated where possible; appendix assumptions need checking before sign-off. [dc-0001]
- **dc-0002**, 10 September, also called solution brief v3 but project field says **Clinical Digital Services**, not Okapi. Training agreed at last review; scope draft/comments welcome; timeline out of scope; support see appendix. Open questions: post-project maintainer and whether council review needed. Do not silently merge these two same-version documents or infer sign-off. Extracted text does not supply appendix contents. [dc-0002]
- **dc-0004**, requirements matrix v2, Bisi: options are only named A/B, not mapped to vendors. Weights/scores: usability 25 (3/2), integration 20 (2/4), security 20 (2/4), accessibility 10 (3/3), requirements fit 20 (5/4). Formula totals calculate to **285 / 320** with weights summing **95**; these are derived, not cached workbook values or an approved option choice. [dc-0004]

## Sirocco platform

Shared AI platform used by hospital projects; Dina Laurent owns, Tunde Andersen sponsors. Stage onboarding tenants; no dated target. [nt-0001]
- Dina to publish tenant onboarding guide; no delivery evidenced. [ch-0016]
- Nurlan to configure Ketford SSO broker; worker explicitly chased 20 September and Nurlan acknowledged, **not completion**. Separate from Okapi tenant provisioning. [ch-0041, ch-0048, ch-0083]
- Alasdair committed 17 September to confirm Sirocco vendor comparison with Bisi; **confirmed earlier on 20 September**, reported at 12:13. Distinct from completed Okapi comparison. No comparison contents/choice supplied. [em-0062, ch-0077, ch-0078, ch-0084]
- Dina's model allow-list review request was relayed by Penelope; Alasdair said he would check and get back, not acceptance of review. [ch-0071]
- Alasdair committed to send Bisi **Sirocco acceptance criteria, with Dina**, 21 September 14:32; reported sent earlier that day at 17:57. Criteria content and Bisi receipt acknowledgement unavailable. [em-0084, ch-0095]
- Nurlan offered to set **gateway rate limits for Sirocco tenants** in 21 September generated Okapi standup recap; no completion evidenced. Distinct from SSO broker and tenant provisioning. [mn-0009]
- Bisi requested Alasdair review her **Sirocco bed census extract** 20 September. No acceptance, extract attachment/content, due date or completion supplied. Do not conflate with Lupe's baseline data or no-shows export. [em-0071]

## Intake Forms Tool Selection (IFTS)

Intake forms bake-off / Kasis-Rosix evaluation for Emberbury Rehabilitation Center. Owner Alasdair, sponsor Tunde, target **6 October**. Moved from demos to **scoring** 6 September; no selection or later stage evidenced. [nt-0001, em-0006]
- Scorecard v3 circulated to Somchai 13 September. [ch-0041, em-0040, dc-0003]
- Rosix two customer references: collected 7 September, **reopened 9 September because sent to wrong group**, offered again 14 September, recollected 14 September and confirmed again 15 September. Current state collected, not still open; customer identities/reference contents not supplied. [nt-0002, em-0012, ch-0022, em-0044, em-0045, ch-0057]
- Sneha to collect two **Kasis** references (different action, still pending); 21 September "picking ... back up now" reaffirms resumed work, not delivery or reopening of a previously completed Kasis action. Longstanding Kasis deep-dive materials also pending. [ch-0053, nt-0001, em-0087]
- Bisi relayed that "the Emberbury lead" would send the **demo script** 21 September. Later worker says pulled it into the deck, thanking Somchai: receipt/incorporation complete, with Somchai linked to delivery. Earlier unnamed role alone did not uniquely identify assignee. Script content unavailable; no new project-stage change. [ch-0093, em-0088]
- Adebayo to send session notes; no delivery evidenced. Calendar invite titled "Notes from the intake forms session" is not delivered notes. [ch-0049, ch-0050, ca-0007]
- Worker records **the platform lead** to set up intake-forms selection dashboard access for him, 20 September. Dina is the mapped platform owner, but the note does not name this action's assignee; attribution to Dina is only an inference, not confirmed. No access completion supplied. [nt-0007, nt-0001]
- Bisi's after-hours support question is still **not agreed**, repeatedly clarified through 17 September. No support policy/answer supplied. [mt-0010, ch-0044, ch-0051, ch-0052, em-0060]

**Scorecard data:** Costs weight 25 Kasis 2 / Rosix 3; integration 10 4/4; accessibility 20 3/2; security 10 2/4; fit 20 4/5. Scores 1 poor–5 strong. Weights sum **85**, not 100; SUMPRODUCT formulas calculate **250 Kasis / 295 Rosix**. Weighted averages if normalized: about 2.94 / 3.47. All totals are calculations from supplied cells, not a documented final recommendation; Rosix scores higher overall but Kasis higher accessibility. [dc-0003]

## Lanmoor Bed Management Discovery (LBMD)

Bed management work / Lanmoor discovery; owner Guadalupe Moreau (Lupe), sponsor Tunde, baseline target **1 October**. Moved from site visits to **pivot** 14 September. [nt-0001, ch-0046]
- Lupe countersigned data-use agreement **6 September**, well before relayed 16 September due date; no longer waiting for signature. [ch-0003, ch-0005]
- Lupe promised bed-management baseline data 10 September; not delivered in evidence. [em-0030]
- Vitoria to share discovery change request. On 14 September says got what she needed and it is moving again: dependency unblocked, **not proof of delivery to Alasdair**. [ch-0041, ch-0045]
- Alasdair accepted Lupe's relayed request to confirm the **bed-management discovery process map with Oluwaseun** at 08:15 on 20 September; reported done at 09:22, acknowledged by Lupe and Vitoria. Actual map content unavailable. This is distinct from the referral-triage map/approach B decision. [ch-0081, ch-0082]
- Alasdair accepted Friederike Haidari's request to **set up a coffee about bed management** 21 September ("will do"). No booking, date, venue or meeting completion supplied; Friederike's role/affiliation unknown. [ch-0090]
- Alasdair scoped a **two-week outpatient no-shows sprint** 16 September, acknowledged by Lupe. This arose in bed-management channel and reflects pivot context; no start/end dates, implementation completion or new formal project owner supplied. Requested Lupe's no-shows wait-time export 17 September; she accepted, not delivered yet. [ch-0065, ch-0068, ch-0076]

## Sirocco Funding Model

Recharge model / funding options / Sirocco recharge. Alasdair owner, Tunde sponsor; funding across hospitals ahead of Clinical Operations Council; target **25 October**. Collecting inputs at baseline → **options** 7 September → **review** 16 September, repeated in 17 September status. No funding option approval evidenced. [nt-0001, ch-0008, em-0031, em-0055, em-0066]
- Assumptions log updated after finance director Deniz's comments 6 September. [ch-0001, em-0002]
- Bisi delivered usage forecast 16 September. Underlying forecast numbers not supplied. [ch-0070, ch-0072]
- Funding-options memo to Tunde was tentative 9 September, dropped 13 September as no longer needed. [nt-0003, nt-0004]
- Deniz forecast rebase never agreed; withdrawn 16 September as duplicate of another ask. This does not cancel the distinct delivered forecast or sensitivity analysis (accepted later, 20 September). [ch-0039, ch-0061, nt-0007]
- Deniz's sensitivity-analysis request was explicitly not agreed 16 September; worker **accepted in his 20 September note** ("I'll run a sensitivity analysis on the funding model"). Worker reported **ran the analysis** by email to Deniz 21 September 09:23; completed, results/content not supplied. The forecast rebase remains withdrawn. [ch-0073, nt-0007, ch-0061, em-0080]
- Alasdair accepted Bisi's request to send the **funding-model budget justification** 20 September. Email plus DM describe one action; **sent 21 September 07:31**, Bisi says "got it, thanks" at 07:32. Justification content unavailable. Different from Bisi's Okapi justification already incorporated in deck. [em-0075, ch-0088, ch-0089, ch-0079]
- Somchai requested review of his **funding-model pricing options table** 21 September; no acceptance, table content/attachment, due date or completion supplied. [em-0081]

## Rosix Enterprise Agreement

Rosix deal / renewal; single agreement intended to cover all hospitals rather than separate deals. Owner Eun-ji Chen, sponsor Tunde; baseline target **25 October**, completed ahead of it. Negotiating terms → **contract review** 10 September → **signed and complete** 16 September. No actual signed contract text or commercial terms supplied. [nt-0001, ch-0035, ch-0064]
- Kwame Brandt returned master-agreement redlines 15 September; both his direct message and Eun-ji corroborate, and status note repeats. [ch-0053, ch-0059, ch-0060, em-0066]
- Individual completion not evidenced: Alasdair counter-proposal draft, Alasdair dependency list confirmation with Bisi, Bisi Njoroge's volume tiers, Bisi Chatterjee's term sheet. Retain as unresolved task evidence despite overall project complete; do not claim they were done or still required without clarification. [ch-0006, mt-0006, ch-0009, ch-0010, mt-0007]

## Ketford Referral Triage Discovery (KRTD)

Referral triage work / Ketford discovery; AI opportunity discovery before building. Katarzyna owner, Tunde sponsor; baseline **planning**, target **22 October**; no explicit stage update. [nt-0001]
- Katarzyna to line up nurse interviews. [mt-0001]
- **20 September decision:** use **approach B** for the referral-triage discovery process map. Worker explicitly says no longer doing the **current referral-triage process map**, superseded by approach B. Eleni's prior map dependency is therefore no longer active, **not delivered**; earlier 8 September block was real historically. Approach B's content, replacement owner/delivery/date and effect on overall discovery readiness are unknown. Do not equate this map with the bed-management map confirmed the same day. [nt-0006, em-0011, ch-0014, ch-0015, em-0023, ch-0082]
- Alasdair owes Bisi site-visit agenda. [mn-0002, ch-0025]
- Eleni requested the **referral-triage discovery interview guide by Wed 22 September**; no acceptance/delivery. Distinct from agenda, observation notes and superseded process map. [em-0085]
- Bisi findings-summary possibility **not agreed**, not an accepted dependency. Separately, Bisi **committed 20 September** to send Alasdair referral-triage discovery **observation notes**; no delivery. Bisi said no blockers for that item, which does not establish all project dependencies resolved. [ch-0042, mt-0013]

## Sirocco Operating Model Review

Ops model draft / operating-model review; Dina owner, Tunde sponsor; no target supplied. Out for peer review at baseline → **revision** 14 September → **complete** 15 September. No approved final text supplied. [nt-0001, em-0046, ch-0056]
Somchai relayed Bisi expectation for Alasdair's review comments 14 September. **Direct delivery evidenced 20 September**: Alasdair says sent, Bisi acknowledges with thanks/thumbs-up. Worker note also accepts the action but is not grounds to reopen it; its writing time is unspecified. Project completed 15 September, comments sent later; comments content unavailable. [ch-0047, nt-0007, ch-0085, ch-0056]

## Other portfolio / relationship work

- **Talwick Partnership** (Talwick relationship): Alasdair owner, Tunde sponsor; ongoing introductions/catch-ups/favours, involving Stanley Luo at Ostport Children's Hospital and Talwick Nursing Research Collaborative. No new activity supplied beyond map. [nt-0001]
- **Lanmoor Discharge Summary Idea**: Lupe owner, Tunde sponsor; placeholder **waiting on problem statement**, reaffirmed Lupe would send on 6 September. No delivery or dated target. [nt-0001, ch-0002]
- **Dalett Interpreter Booking Diligence** (Dalett deep dive): Alasdair owner, Tunde sponsor; **stalled**, enthusiasm early but no recent dated activity; involves Ketford, Dalett Clinical, Kasis. No restart/decision supplied. [nt-0001]
- **Dina prior-authorization fellowship reference**: accepted personal/professional favour; Alasdair reported **wrote the reference earlier 21 September** in 1:1 transcript. Writing completed; sending/submission not evidenced, text unavailable. Not platform operating-model work. [em-0021, ch-0024, mn-0006, mt-0015]
- **Bisi denials-analytics reading list**: Alasdair offered to send, no explicit acceptance/delivery recorded. [mt-0008]
