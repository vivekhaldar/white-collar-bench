# Alasdair Kaya — working memory

Updated through **2027-09-21**. Worker: Alasdair Kaya, Clinical Digital Services (CDS), Birchmere Health Partners. [nt-0001]

## Start here

- [Current portfolio and decisions](memory/projects.md)
- [Commitments, waiting-on items, and closed/cancelled work](memory/commitments.md)
- [People and aliases](memory/people.md)
- [Calendar and administrative reminders](memory/calendar.md)
- [Artifact index](memory/artifact-index.json): all 229 inputs from the twelve supplied dates, with titles, dates, receipt times, channels, and archive locations.
- `memory/sources/YYYY-MM-DD.md`: searchable sanitized text for every artifact, including PDF text and spreadsheet cells/formulas. These files survive removal of `inbox/`.

## How to answer later

Cite input IDs (e.g. `[em-0066, ch-0064]`), not just this summary. Look up exact evidence in the source archive, especially for historical questions. Current summaries reflect only evidence through 21 September; no later completion is assumed. Dates without years here mean 2027. Distinguish project status from individual tasks: a completed project does not automatically prove each outstanding task was performed.

Requests, suggestions, tentative offers, and reminders are not interchangeable with accepted commitments. Direct delivery/completion evidence outranks stale waiting lists; explicit reopenings and cancellations supersede earlier completion/proposal claims. Repeated paraphrases of one action are not new actions. Receipt time can differ from message/event time. Generated meeting summaries/transcripts may contain errors; preserve their uncertainty and prefer direct corroboration. Draft emails (including X-Draft flags) are not sent deliveries; edited message text supersedes its original. Unknown due dates, sign-offs, content of unavailable attachments, and post-cutoff outcomes should be stated as unknown.

Credentials, passcodes, and meeting join links are excluded. Binary document text/cells are preserved, not original layout. No external linked material was fetched.
