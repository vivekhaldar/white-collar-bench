# People and organizations

## Worker and naming rules

**Worker: Hiba Jimenez**, Systemwide Learning Innovation Office (SLIO), Corrstead University System. The portfolio's "me" means Hiba (`nt-0001`, identity corroborated by sent `em-0027`, `em-0065`). Exact Hiba job title is not supplied. Hiba owns admissions selection, Corrie, Holmarsh partnership and Merol captioning diligence; workshop slides are Hiba's responsibility (`nt-0001`).

**Do not merge the two Zawadis:** Zawadi Grigoryan is the Iselbury Corrie/thesis collaborator (`nt-0001`); Zawadi Quinlan is Torane's solutions engineer and sandbox sender (`em-0078`).

**Do not merge the two Bolats:**
- **Bolat Oyelami**: SLIO Head of Learning Services, colleague; chat `@bolat`, sometimes just "Bolat" or "Bolat's iPhone." Portfolio role (`nt-0001`), full email signature (`em-0044`), transcript alias (`mt-0010`).
- **Bolat Farah**: Merol Labs Account Executive; vendor sender `bolat.farah@merol.example`, signs "Bolat" (`em-0025`, `em-0037`, `em-0039`, `em-0043`). Questionnaire ownership explicitly transferred from Farah to Oyelami (`em-0043`), and Oyelami returned it (`ch-0050`, `em-0065`).

## Directory

Roles and organizational affiliations in this table are from Hiba's portfolio map (`nt-0001`) unless a separate source is shown. Project responsibilities are baseline, not proof every listed person has a current task.

| Person | Role / affiliation | Links / aliases |
|---|---|---|
| Anastasia Mizrahi | Associate Provost for Academic Technology, SLIO | Sponsor of most portfolio work except Elmwick; receives Friday status. Hiba addresses her as **Nastya** in `em-0065`; transcript "Anas tasia" `mt-0009` |
| Bolat Oyelami | Head of Learning Services, SLIO | Assessment workshop and syllabus learning series owner; broad collaborator across portfolio; see distinction above |
| Ewan Laine | Registrar, Crandale University | Garnet owner; Crandale lead. Transcript **Ewan L.**, **Ewan Laine (Guest)** (`mt-0003`, `mt-0008`), note "the Crandale lead" (`mn-0010`) |
| Madeline Chikwanha | Site Reliability Engineer, Crandale University | **Maddie**, `@madeline`; Garnet integration, load tests/playbook; Siskin ops comparison table |
| Desmond Visser | Lead, Cloud Platforms, SLIO | **Dez**, `@desmond`; Siskin and operating model review owner |
| Andrei Laurent | Information Security Manager, SLIO | Security manager associated with Garnet access request (`nt-0004`, `mt-0007`); service blueprint recipient |
| Emre Khumalo | Platform Engineer, SLIO | Siskin gateway rate limits, Crandale SSO broker; support model recipient |
| Adaeze Fifita | Product Owner, Student Systems, SLIO | Garnet collaborator; relays Bolat accessibility-audit expectation (`ch-0058`) |
| Eun-ji Valdez | Chief Information Officer, Crandale University | Garnet collaborator; email identifier "eunji" in calendar (`ca-0009`) |
| Catalina Achterhof | Account Executive, Torane Software | Admissions materials contact; reading-list recipient |
| Mere Hidayat | Director, Teaching & Learning Technology, University of Elmwick | Alumni discovery owner, DSA countersign/baseline data/pain-point list; learning series collaborator |
| Nurlan Kavanagh | Chief Information Officer, University of Elmwick | Alumni discovery sponsor |
| Deborah Nurlanov | Instructional Designer, University of Elmwick | Alumni discovery collaborator; not Nurlan Kavanagh |
| Tane Wisniewska | Dean of Libraries, Aldervale University | Assessment workshop collaborator |
| Funmilayo Ogunleye | Service Desk Lead, Aldervale University | **Funmi**, transcript **Funmilayo Ogunleye (Guest)** (`mt-0005`); workshop collaborator |
| Zawadi Grigoryan | Director of Institutional Research, Iselbury State College | Thesis idea owner; Corrie collaborator. Transcript **Zawady** (`mt-0003`); **not Zawadi Quinlan** |
| Zawadi Quinlan | Solutions Engineer, Torane Software (`em-0078`) | Reports Torane sandbox access set up July 5; **not Zawadi Grigoryan** |
| Kristen Ochieng | Software Engineer, Iselbury State College | Corrie collaborator; July 6 sync invite (`ca-0014`) |
| Bolat Farah | Account Executive, Merol Labs (`em-0025`) | Merol admissions questionnaire vendor contact; distinct from Oyelami |
| Rania Dlamini | Holmarsh contact; email domain holmarsh-research.example (`em-0020`) | Introduced to Oyelami for Holmarsh working group (`ch-0031`); exact job title unknown |
| Tyrone Duarte | Corrstead sender; exact role unknown (`em-0087`) | Requests Garnet privacy impact assessment by July 7; not evidence Hiba accepted |
| Rahul Sargsyan | Director, System Budget Office, Corrstead University System (`em-0088`) | Garnet budget agreed pending formal sign-off/figure; lessons-learned recipient `em-0091` |
| Rodrigo Gurung | Role/organization not specified | Hiba catch-up attendee (`mt-0009`), Corrstead chat participant (`ch-0048`, `ch-0060`); do not invent role |
| Thao Mendoza | Events Coordinator (`em-0017`, `em-0047`) | Room bookings, event survey/catering; Corrstead sender |
| Elif Salazar | Conference Organizer (`em-0026`) | Regional Digital Services Summit CFP/newsletter; no Hiba submission commitment |
| Stanley Agyeman | Quad Ledger newsletter sender (`em-0009`, `em-0050`) | No project role provided |

## Organizations

- **Corrstead University System**: worker's umbrella organization; **SLIO** is Systemwide Learning Innovation Office (`nt-0001`).
- **Crandale University**: Garnet pilot and admissions triage selection (`nt-0001`).
- **University of Elmwick**: alumni outreach discovery, learning series link (`nt-0001`).
- **Aldervale University**: assessment design workshop (`nt-0001`).
- **Iselbury State College**: Corrie collaborators, thesis formatting idea (`nt-0001`).
- **Holmarsh Institute for Learning Research**: partnership and syllabus review series (`nt-0001`).
- **Torane Software / Merol Labs**: admissions candidate vendors; also baseline links to captioning diligence, which remains a separate quiet project (`nt-0001`).
