# Commitment ledger — 2027-07-06

No deadlines are known unless explicitly listed. Open means no later completion/drop evidence in the supplied inputs, not necessarily unfinished in reality. Requests, accepted work and suggestions are deliberately separate. See [projects](projects.md) for history and context.

## Hiba's accepted outstanding work

| Project | Action / recipient | Evidence and qualification |
|---|---|---|
| Siskin | Review model allow-list | Accepted June 24 `ch-0027`; reaffirmed June 29 `mt-0009`; initial unagreed suggestion `ch-0009` superseded |
| Corrie | Confirm usability test script with Zawadi Grigoryan | Direct commitment June 24 `mt-0003` (transcript spells Zawadi "Zawady") |
| Garnet | Confirm support model with Bolat Oyelami | June 28 `ch-0037`; **not** Siskin support model sent to Emre |
| Elmwick discovery | Send Bolat Oyelami problem framing note | June 29 `ch-0041` |
| Garnet | Send Andrei Laurent service blueprint | June 30 request accepted `ch-0047`; July 1 reaffirmed `ch-0053` |
| Garnet | Review Bolat Oyelami's accessibility audit | July 1 secondhand expectation plus Hiba "on it" `ch-0058` |
| Siskin operating model review | Confirm summary of changes with Ewan Laine | July 2 `mn-0011`, **automated recap only**, reports Hiba offered; no completion |
| Assessment workshop | Own slides | Baseline responsibility `nt-0001`; specific slides-v2 send below remains unagreed |
| Siskin | Walk Bolat Oyelami through metrics definition | Direct July 5 commitment `ch-0065`; scheduled July 8 14:00–14:30 UTC−08 `ca-0015`; not completed |
| Garnet | Send Bolat Oyelami LMS integration notes | Direct acceptance July 5 `ch-0066`, email request `em-0081`; no delivery |
| Garnet | Look into login loop | July 5 automated recap reports Hiba offered `mn-0012`; source-quality caveat, no completion |
| Siskin | Send Andrei one-page summary; recipient needs **July 8** | July 5 automated recap action `mn-0013`; Bolat edited due/need date to Thursday July 8 from Wednesday July 7 `ch-0068`; Hiba acknowledgement only, no direct acceptance/delivery |
| Assessment workshop | Send Funmilayo action log | Direct promise July 5 `em-0085`; July 6 **unsent draft, attachment not yet added** `em-0095`; no delivery/deadline; **not slides v2** |

## Waiting on others — accepted/reported responsibility

| Owner | Project / action for Hiba | Evidence and status |
|---|---|---|
| Catalina Achterhof | Admissions: Torane deep-dive materials | Long-running waiting-on `nt-0001`; no later delivery |
| Zawadi Grigoryan | Thesis idea: problem statement | Long-running waiting-on `nt-0001`; no later delivery |
| Madeline Chikwanha | Garnet integration endpoint | Responsible `ch-0021`; July 1 **resumed** `em-0060`, not evidenced delivered |
| Ewan Laine | Book Garnet faculty onboarding sessions | Direct June 25 commitment `ch-0029`; no booked-session evidence |
| Desmond Visser | Publish Siskin tenant onboarding guide | Direct June 28 commitment `mt-0008`; June 30 recap `mt-0010`; no publication evidence |
| Bolat Oyelami | Send Garnet evaluation rubric | Direct June 29 commitment `ch-0040`; July 6 **resumed**, not delivered `ch-0071` |
| Mere Hidayat | Pull Elmwick alumni outreach baseline data | Reported by Bolat June 29 `em-0044`; no direct Mere acceptance/completion captured |
| Ewan Laine | Share Garnet rollout checklist | Offer accepted/acknowledged by Hiba June 30 `em-0049`; no delivery |
| Rania Dlamini | Send Hiba Holmarsh working paper | Confirmed by worker July 5 `nt-0007`, superseding earlier unagreed state; no delivery/deadline |
| Bolat Oyelami | Send Hiba Garnet data dictionary | July 5 automated recap assigns task, says Bolat has it `mn-0012`; no direct acceptance/delivery |
| Desmond Visser | Send Hiba Garnet test plan | Hiba **makes official** July 6 `ch-0067`, superseding tentative `mn-0010`; worker-confirmed assignment, no Dez reply/delivery/deadline; not Maddie's load test plan |
| Emre Khumalo | Share Garnet requirements matrix with Hiba | July 6 automated recap says offered/action `mn-0014`; source-quality caveat, no delivery |
| Rahul Sargsyan | Share Garnet budget figure after formal sign-off | July 6 direct promise `em-0088`; budget agreed but sign-off/amount not supplied |

## Requests pending / explicitly not agreed — not firm commitments

| Potential owner | Item | Evidence |
|---|---|---|
| Hiba | Complete Garnet privacy impact assessment **requested by July 7** | Tyrone request July 6 `em-0087`; no acceptance/completion; not completed security review package |
| Hiba | Write Corrie usability findings | Anastasia's request forwarded by Bolat June 23 `em-0015`; no direct acceptance captured |
| Hiba | Review Desmond's Siskin operating model draft v2 | June 29 `ch-0039`; **explicitly still not agreed July 2** `em-0062` |
| Hiba | Review Bolat's admissions triage selection demo script | Request July 2 `em-0063`; no reply supplied |
| Hiba | Set up coffee with Bolat Oyelami about alumni outreach | Suggested June 21 `mn-0001`; unagreed June 23 `mt-0001`, June 25 `ch-0034`, June 30 `mn-0009` |
| Hiba | Send Bolat workshop attendee list | Suggested/unagreed June 28 automated recap `mn-0007` |
| Hiba | Review Bolat's Siskin evaluation rubric | Explicitly not agreed July 1 `ch-0057`, still not committed July 6 worker notes `mn-0016` |
| Hiba | Review Bolat's Garnet budget justification | Suggested/unagreed July 2 automated recap `mn-0011` |
| Bolat Oyelami | Confirm spring syllabus review series dates | Suggested/unagreed June 29 automated recap `mn-0008` |
| Desmond Visser | Send Hiba Siskin capacity plan | Hiba request July 1 `ch-0051`; Dez did not accept in supplied chat |
| Desmond Visser | Set up alumni outreach discovery sandbox access for Hiba | Direct request July 5 `em-0076`; no acceptance/setup evidence; not Torane sandbox |
| Hiba | Send Funmilayo assessment workshop slides v2 | Suggested only, **no owner agreed**, July 5 automated recap `mn-0013`; proposed due **Mon July 12**, not accepted deadline |

## Completed — do not reopen from older recaps

| Completion date | Owner / item | Completion evidence (earlier context) |
|---|---|---|
| June 21 | Emre: gateway rate limits for Siskin tenants | `ch-0007`, `em-0006`; direct Emre retrospective `em-0010`, `em-0013`; Hiba status `em-0027` (future-tense `ch-0002` superseded) |
| June 21 | Hiba: interview guide to Bolat, Elmwick discovery | Worker report/recipient acknowledgement `ch-0006` (stale automated checkbox `mn-0001`) |
| June 22 | Hiba: admissions reading list to Catalina | Worker report/recipient receipt + working link `ch-0016` (automated checkbox `mn-0002`) |
| June 23 | Hiba: turn around Garnet API contract v2 | Worker report/Dez acknowledgement `ch-0018` (request `em-0019`) |
| June 24 | Hiba: Garnet solution brief to Bolat Oyelami | `ch-0026`; status `em-0027`; retrospective `em-0036` (old task `mn-0002`, `mt-0001`, `em-0016`, `ch-0017`) |
| June 25 | Hiba: introduce Rania to Bolat Oyelami, Holmarsh working group | Worker report/Rania acknowledgement `ch-0031` (request/accepted `em-0020`, `ch-0024`) |
| June 25 | Hiba: Friday status w/e June 25 to Anastasia, due EOD June 25 | Sent `em-0027` (reminder `em-0001`, multiple acceptance recaps `ch-0008`, `ch-0010`, `ch-0013`) |
| June 25 (reported) | Emre: Siskin SSO broker for Crandale | Ewan report `ch-0033` (direct Emre commitment `ch-0022`) |
| June 28 | Maddie: Garnet load test plan drafted | Direct `ch-0036` (accepted offer `ch-0028`) |
| June 29 | Maddie: Garnet support playbook written | Direct `ch-0043`; status `em-0065` (tentative `mt-0004`, made official `em-0046`) |
| June 30 | Maddie: Siskin operating model comparison table to Hiba | Direct `ch-0044` (promise reported `ch-0023`) |
| June 30 | Bolat Oyelami: returned Merol security questionnaire "again" | Direct `ch-0050`; status `em-0065`; responsibility transfer `em-0043` (Farah's July 2/5 promises `em-0025`, `em-0037`, pickup `em-0039` superseded) |
| July 1 | Mere: alumni outreach discovery pain-point list to Hiba | Direct sent report `ch-0055` (offer `ch-0054`) |
| By July 2 | Hiba: update alumni discovery stakeholder map after Bolat comments | **Automated recap reports Hiba confirmed done** `mn-0011` (todo `mn-0010`, request `em-0053`); source-quality caveat |
| July 2 | Hiba: Friday status w/e July 2 to Anastasia, due EOD July 2 | Sent 16:53 UTC−08 `em-0065` (reminder `em-0033`, recap `mt-0009`, worker-owned task `mn-0009`) |
| July 2 | Hiba: Siskin support model to Emre | Sent 17:23 UTC−08 `em-0067`, attachment text `dc-0001` (request/reported commitment `ch-0012`, `ch-0011`; formerly vendor-fix blocked `mn-0005`). Draft v2 still has open questions |
| July 6 | Hiba: assemble Garnet security review package | Direct done report/Andrei acknowledgement `ch-0070` (request `ch-0069`); review approval/data-pause clearance not established |
| July 6 | Hiba: send Rahul Garnet lessons-learned note | Sent `em-0091` (request `em-0088`); actual note contents not supplied |
| July 6 | Hiba: hand Corrie over to Iselbury | Direct promise then completed report/Zawadi acknowledgement `ch-0072`; separate from usability tasks |
| July 6 | Hiba: send Bolat Oyelami admissions triage selection evaluation rubric | Direct retrospective sent report/recipient acknowledgement `ch-0073`, supersedes voice memo `nt-0008`; not Garnet/Siskin rubrics |
| July 6 | Desmond: fix admissions triage selection stale cache | Direct completion report `ch-0074` (promise `em-0092`) |

## Dropped, not completed

- **Siskin decision memo to Bolat:** only suggested/unagreed June 23 (`mn-0004`); explicitly no longer needed, overtaken by events June 25 (`mt-0005`).
- **Andrei's Garnet access request review:** tentative June 28 (`mt-0007`); worker dropped June 29, overtaken by events (`nt-0004`); confirmed in sent July 2 status (`em-0065`).
- **Elmwick data-sharing agreement work / countersign:** worker stopped July 5, superseded by approach A process-map decision (`nt-0006`). Earlier Mere commitment and unsigned blocker (`ch-0025`, `em-0058`) are historical, not open. No evidence agreement signed.

## Recurring status reporting

Weekly reminder asks for half a page to Anastasia: what moved, slipped, leadership needs; extension can be requested by replying (`em-0001`, `em-0033`, `em-0074`). June 25 and July 2 notes were sent. **W/e July 9 status note is due EOD Friday July 9** per July 5 reminder (`em-0074`); required recurring task, July 6 Corrie transcript recaps Hiba's July 5 promise to send (`mt-0011`, secondhand/automatic); no delivery supplied.
