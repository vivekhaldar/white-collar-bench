# Evidence index

Processed through 2027-07-06 (221 artifacts). Each file retains the artifact ID, received date, title, and sanitized source text. Calendar access details are omitted. DOCX is extracted as text; original layout and margin comments are not preserved.

## 2027-06-21

- [em-0001](2027-06-21/em-0001.md) — Reminder: Friday status note due Friday 25 June
- [nt-0001](2027-06-21/nt-0001.md) — Portfolio map
- [em-0002](2027-06-21/em-0002.md) — Open enrollment reminder
- [em-0003](2027-06-21/em-0003.md) — Wellness credit deadline
- [ca-0001](2027-06-21/ca-0001.md) — Invite: Catch-up: Hiba / Catalina
- [em-0004](2027-06-21/em-0004.md) — Parking lot resurfacing
- [ch-0001](2027-06-21/ch-0001.md) — #general
- [ca-0002](2027-06-21/ca-0002.md) — Invite: Garnet scoping call
- [ch-0002](2027-06-21/ch-0002.md) — DM: Bolat Oyelami / Hiba Jimenez
- [ch-0003](2027-06-21/ch-0003.md) — #general
- [ch-0004](2027-06-21/ch-0004.md) — #coffee
- [ch-0005](2027-06-21/ch-0005.md) — #general
- [em-0005](2027-06-21/em-0005.md) — Speaker spotlight
- [em-0006](2027-06-21/em-0006.md) — Re: FYI: Gateway rate limits for Siskin tenants
- [mn-0001](2027-06-21/mn-0001.md) — Recap: Garnet / Siskin sync
- [ch-0006](2027-06-21/ch-0006.md) — DM: Hiba Jimenez / Bolat Oyelami
- [ch-0007](2027-06-21/ch-0007.md) — DM: Andrei Laurent / Hiba Jimenez

## 2027-06-22

- [ch-0008](2027-06-22/ch-0008.md) — DM: Anastasia Mizrahi / Hiba Jimenez
- [ch-0009](2027-06-22/ch-0009.md) — #siskin-core
- [em-0007](2027-06-22/em-0007.md) — [REQ-31749] Request resolved
- [ch-0010](2027-06-22/ch-0010.md) — DM: Anastasia Mizrahi / Hiba Jimenez
- [ch-0011](2027-06-22/ch-0011.md) — #siskin-core
- [em-0008](2027-06-22/em-0008.md) — Re: Assessment Design Workshop: moving to logistics
- [em-0009](2027-06-22/em-0009.md) — The Quad Ledger: issue 25
- [em-0010](2027-06-22/em-0010.md) — FYI: Gateway rate limits for Siskin tenants
- [mn-0002](2027-06-22/mn-0002.md) — Recap: 1:1 Hiba / Bolat
- [ch-0012](2027-06-22/ch-0012.md) — #siskin-core
- [em-0011](2027-06-22/em-0011.md) — Re: Corrie: moving to user testing
- [ch-0013](2027-06-22/ch-0013.md) — DM: Anastasia Mizrahi / Hiba Jimenez
- [ch-0014](2027-06-22/ch-0014.md) — #random
- [ca-0003](2027-06-22/ca-0003.md) — Invite: Elmwick site visit
- [ch-0015](2027-06-22/ch-0015.md) — #coffee
- [ch-0016](2027-06-22/ch-0016.md) — DM: Hiba Jimenez / Catalina Achterhof
- [em-0012](2027-06-22/em-0012.md) — [Investigating] Intermittent sign-in delays
- [em-0013](2027-06-22/em-0013.md) — FYI: Gateway rate limits for Siskin tenants

## 2027-06-23

- [em-0014](2027-06-23/em-0014.md) — Wellbeing week activities
- [em-0015](2027-06-23/em-0015.md) — Fwd: Corrie usability findings
- [nt-0002](2027-06-23/nt-0002.md) — Voice debrief: Garnet standup
- [nt-0003](2027-06-23/nt-0003.md) — Wed notes
- [mt-0001](2027-06-23/mt-0001.md) — Garnet scoping call (transcript)
- [mn-0003](2027-06-23/mn-0003.md) — Recap: Catch-up: Hiba / Catalina
- [mt-0002](2027-06-23/mt-0002.md) — Catch-up: Hiba / Catalina (transcript)
- [em-0016](2027-06-23/em-0016.md) — Fwd: Garnet solution brief
- [em-0017](2027-06-23/em-0017.md) — Room booking confirmation
- [ch-0017](2027-06-23/ch-0017.md) — DM: Andrei Laurent / Hiba Jimenez
- [em-0018](2027-06-23/em-0018.md) — [Resolved] Elevated latency on file storage
- [ca-0004](2027-06-23/ca-0004.md) — Invite: Catch-up: Hiba / Catalina
- [em-0019](2027-06-23/em-0019.md) — Garnet API contract v2
- [ca-0005](2027-06-23/ca-0005.md) — Updated: Elmwick site visit
- [ch-0018](2027-06-23/ch-0018.md) — DM: Hiba Jimenez / Desmond Visser
- [em-0020](2027-06-23/em-0020.md) — Fwd: Introduce Rania to Bolat for the Holmarsh working group
- [mn-0004](2027-06-23/mn-0004.md) — Recap: Siskin platform sync
- [ch-0019](2027-06-23/ch-0019.md) — #random
- [em-0021](2027-06-23/em-0021.md) — [INC-66093] Ticket updated

## 2027-06-24

- [ca-0006](2027-06-24/ca-0006.md) — Cancelled: Garnet standup
- [mn-0005](2027-06-24/mn-0005.md) — Notes: Catch-up: Hiba / Desmond
- [ch-0020](2027-06-24/ch-0020.md) — DM: Bolat Oyelami / Hiba Jimenez
- [em-0022](2027-06-24/em-0022.md) — [INC-40555] Ticket updated
- [ch-0021](2027-06-24/ch-0021.md) — DM: Andrei Laurent / Hiba Jimenez
- [ch-0022](2027-06-24/ch-0022.md) — DM: Emre Khumalo / Hiba Jimenez
- [ca-0007](2027-06-24/ca-0007.md) — Invite: Assessment design workshop run-through
- [ch-0023](2027-06-24/ch-0023.md) — DM: Bolat Oyelami / Hiba Jimenez
- [em-0023](2027-06-24/em-0023.md) — All-staff: building access changes
- [mt-0003](2027-06-24/mt-0003.md) — Cross-campus AI forum (transcript)
- [ch-0024](2027-06-24/ch-0024.md) — DM: Rania Dlamini / Hiba Jimenez
- [ch-0025](2027-06-24/ch-0025.md) — #alumni-outreach-discovery-core
- [ch-0026](2027-06-24/ch-0026.md) — DM: Hiba Jimenez / Bolat Oyelami
- [ch-0027](2027-06-24/ch-0027.md) — DM: Hiba Jimenez / Desmond Visser
- [ca-0008](2027-06-24/ca-0008.md) — Updated: Catch-up: Hiba / Catalina
- [ch-0028](2027-06-24/ch-0028.md) — DM: Hiba Jimenez / Madeline Chikwanha
- [em-0024](2027-06-24/em-0024.md) — [REQ-24644] Request resolved

## 2027-06-25

- [ch-0029](2027-06-25/ch-0029.md) — DM: Ewan Laine / Hiba Jimenez
- [em-0025](2027-06-25/em-0025.md) — Re: Merol security questionnaire
- [em-0026](2027-06-25/em-0026.md) — Call for proposals closes Wednesday 7 July
- [ch-0030](2027-06-25/ch-0030.md) — #random
- [mt-0004](2027-06-25/mt-0004.md) — Garnet standup (transcript)
- [ca-0009](2027-06-25/ca-0009.md) — Invite: Catch-up: Hiba / Eun-ji
- [mt-0005](2027-06-25/mt-0005.md) — Assessment design workshop / admissions triage selection sync (transcript)
- [ch-0031](2027-06-25/ch-0031.md) — DM: Hiba Jimenez / Rania Dlamini
- [em-0027](2027-06-25/em-0027.md) — Status note: w/e 25 June
- [ch-0032](2027-06-25/ch-0032.md) — #corrie-core
- [em-0028](2027-06-25/em-0028.md) — Your benefits statement is ready
- [ch-0033](2027-06-25/ch-0033.md) — DM: Ewan Laine / Hiba Jimenez
- [ch-0034](2027-06-25/ch-0034.md) — DM: Bolat Oyelami / Hiba Jimenez

## 2027-06-26

- [ch-0035](2027-06-26/ch-0035.md) — #general
- [em-0029](2027-06-26/em-0029.md) — [INC-47040] Ticket updated
- [em-0030](2027-06-26/em-0030.md) — [Scheduled] Network maintenance window
- [em-0031](2027-06-26/em-0031.md) — [INC-63921] Ticket updated
- [em-0032](2027-06-26/em-0032.md) — [INC-87759] Ticket updated
- [ca-0010](2027-06-26/ca-0010.md) — Invite: Working session: Garnet single sign-on role mapping

## 2027-06-28

- [em-0033](2027-06-28/em-0033.md) — Reminder: Friday status note due Friday 2 July
- [em-0034](2027-06-28/em-0034.md) — [Resolved] Elevated latency on file storage
- [em-0035](2027-06-28/em-0035.md) — [Scheduled] Network maintenance window
- [ca-0011](2027-06-28/ca-0011.md) — Cancelled: Garnet standup
- [ch-0036](2027-06-28/ch-0036.md) — DM: Madeline Chikwanha / Hiba Jimenez
- [em-0036](2027-06-28/em-0036.md) — Re: FYI: Garnet solution brief
- [em-0037](2027-06-28/em-0037.md) — Merol security questionnaire
- [em-0038](2027-06-28/em-0038.md) — [Investigating] Intermittent sign-in delays
- [mn-0006](2027-06-28/mn-0006.md) — Recap: Catch-up: Hiba / Catalina
- [mt-0006](2027-06-28/mt-0006.md) — Catch-up: Hiba / Catalina (transcript)
- [ch-0037](2027-06-28/ch-0037.md) — DM: Hiba Jimenez / Bolat Oyelami
- [ch-0038](2027-06-28/ch-0038.md) — #coffee
- [mt-0007](2027-06-28/mt-0007.md) — Garnet build sync (transcript)
- [mn-0007](2027-06-28/mn-0007.md) — Recap: Assessment design workshop run-through
- [mt-0008](2027-06-28/mt-0008.md) — Holmarsh partnership / Siskin sync (transcript)
- [ca-0012](2027-06-28/ca-0012.md) — Invite: Corrie sync

## 2027-06-29

- [em-0039](2027-06-29/em-0039.md) — Re: Merol security questionnaire again
- [em-0040](2027-06-29/em-0040.md) — Reminder: all-staff meeting Thursday
- [ch-0039](2027-06-29/ch-0039.md) — DM: Desmond Visser / Hiba Jimenez
- [em-0041](2027-06-29/em-0041.md) — Call for proposals closes Wednesday 7 July
- [mn-0008](2027-06-29/mn-0008.md) — Recap: Garnet standup
- [ch-0040](2027-06-29/ch-0040.md) — DM: Bolat Oyelami / Hiba Jimenez
- [em-0042](2027-06-29/em-0042.md) — Open enrollment reminder
- [ch-0041](2027-06-29/ch-0041.md) — DM: Hiba Jimenez / Bolat Oyelami
- [ch-0042](2027-06-29/ch-0042.md) — #siskin-core
- [em-0043](2027-06-29/em-0043.md) — Re: Merol security questionnaire again
- [em-0044](2027-06-29/em-0044.md) — Alumni outreach baseline data from Elmwick
- [mt-0009](2027-06-29/mt-0009.md) — Catch-up: Hiba / Rodrigo (transcript)
- [em-0045](2027-06-29/em-0045.md) — [REQ-34453] Request resolved
- [em-0046](2027-06-29/em-0046.md) — Re: Garnet support playbook
- [ch-0043](2027-06-29/ch-0043.md) — #garnet-core
- [nt-0004](2027-06-29/nt-0004.md) — Tue notes

## 2027-06-30

- [ca-0013](2027-06-30/ca-0013.md) — Cancelled: Corrie sync
- [ch-0044](2027-06-30/ch-0044.md) — DM: Madeline Chikwanha / Hiba Jimenez
- [em-0047](2027-06-30/em-0047.md) — Room booking confirmation
- [mn-0009](2027-06-30/mn-0009.md) — Notes: Assessment design workshop run-through
- [em-0048](2027-06-30/em-0048.md) — Speaker spotlight
- [mn-0010](2027-06-30/mn-0010.md) — Notes: Garnet standup
- [ch-0045](2027-06-30/ch-0045.md) — #coffee
- [ch-0046](2027-06-30/ch-0046.md) — #coffee
- [ch-0047](2027-06-30/ch-0047.md) — DM: Andrei Laurent / Hiba Jimenez
- [ch-0048](2027-06-30/ch-0048.md) — #coffee
- [mt-0010](2027-06-30/mt-0010.md) — Siskin platform sync (transcript)
- [em-0049](2027-06-30/em-0049.md) — Re: Garnet rollout checklist
- [em-0050](2027-06-30/em-0050.md) — The Quad Ledger: issue 26
- [ch-0049](2027-06-30/ch-0049.md) — #coffee
- [em-0051](2027-06-30/em-0051.md) — [REQ-21294] Request resolved
- [em-0052](2027-06-30/em-0052.md) — Event space survey
- [em-0053](2027-06-30/em-0053.md) — Re: FYI: Alumni outreach discovery stakeholder map after Bolat's comments
- [ch-0050](2027-06-30/ch-0050.md) — DM: Bolat Oyelami / Hiba Jimenez
- [em-0054](2027-06-30/em-0054.md) — Catering menu for next month
- [nt-0005](2027-06-30/nt-0005.md) — Wed notes

## 2027-07-01

- [em-0055](2027-07-01/em-0055.md) — Room booking confirmation
- [ch-0051](2027-07-01/ch-0051.md) — #siskin-core
- [em-0056](2027-07-01/em-0056.md) — Room booking confirmation
- [ch-0052](2027-07-01/ch-0052.md) — #coffee
- [em-0057](2027-07-01/em-0057.md) — [INC-56825] Ticket updated
- [em-0058](2027-07-01/em-0058.md) — Elmwick Alumni Outreach Discovery update
- [ch-0053](2027-07-01/ch-0053.md) — DM: Andrei Laurent / Hiba Jimenez
- [ch-0054](2027-07-01/ch-0054.md) — DM: Mere Hidayat / Hiba Jimenez
- [em-0059](2027-07-01/em-0059.md) — Room booking confirmation
- [ch-0055](2027-07-01/ch-0055.md) — #alumni-outreach-discovery-core
- [ch-0056](2027-07-01/ch-0056.md) — DM: Hiba Jimenez / Ewan Laine
- [ch-0057](2027-07-01/ch-0057.md) — #siskin-core
- [ch-0058](2027-07-01/ch-0058.md) — DM: Adaeze Fifita / Hiba Jimenez
- [em-0060](2027-07-01/em-0060.md) — Re: Garnet integration endpoint

## 2027-07-02

- [ch-0059](2027-07-02/ch-0059.md) — DM: Rania Dlamini / Hiba Jimenez
- [ch-0060](2027-07-02/ch-0060.md) — #coffee
- [ch-0061](2027-07-02/ch-0061.md) — #random
- [em-0061](2027-07-02/em-0061.md) — [INC-58409] Ticket updated
- [mn-0011](2027-07-02/mn-0011.md) — Recap: Garnet standup
- [ch-0062](2027-07-02/ch-0062.md) — #random
- [em-0062](2027-07-02/em-0062.md) — Re: FYI: Desmond's Siskin operating model draft v2
- [ch-0063](2027-07-02/ch-0063.md) — #general
- [ca-0014](2027-07-02/ca-0014.md) — Invite: Corrie sync
- [em-0063](2027-07-02/em-0063.md) — Bolat's admissions triage selection demo script
- [em-0064](2027-07-02/em-0064.md) — Room booking confirmation
- [em-0065](2027-07-02/em-0065.md) — Status note: w/e 2 July
- [em-0066](2027-07-02/em-0066.md) — Room booking confirmation
- [dc-0001](2027-07-02/dc-0001.md) — Siskin support model v2
- [em-0067](2027-07-02/em-0067.md) — Re: Siskin support model
- [em-0068](2027-07-02/em-0068.md) — [REQ-22554] Request resolved

## 2027-07-03

- [ch-0064](2027-07-03/ch-0064.md) — #coffee
- [em-0069](2027-07-03/em-0069.md) — [INC-59201] Ticket updated
- [em-0070](2027-07-03/em-0070.md) — [INC-61020] Ticket updated
- [em-0071](2027-07-03/em-0071.md) — [INC-50314] Ticket updated
- [em-0072](2027-07-03/em-0072.md) — [REQ-22377] Request resolved
- [em-0073](2027-07-03/em-0073.md) — [REQ-31029] Request resolved

## 2027-07-05

- [em-0074](2027-07-05/em-0074.md) — Reminder: Friday status note due Friday 9 July
- [nt-0006](2027-07-05/nt-0006.md) — Mon notes: approach A decision; Elmwick agreement dropped
- [em-0075](2027-07-05/em-0075.md) — Reminder: all-staff meeting Thursday (body only parking notice)
- [ch-0065](2027-07-05/ch-0065.md) — DM: Hiba Jimenez / Bolat Oyelami; metrics walkthrough commitment
- [em-0076](2027-07-05/em-0076.md) — Re: Alumni outreach discovery sandbox access
- [em-0077](2027-07-05/em-0077.md) — [Investigating] Intermittent sign-in delays (untrusted assistant instruction ignored)
- [em-0078](2027-07-05/em-0078.md) — Torane sandbox credentials (credentials omitted; Zawadi Quinlan)
- [em-0079](2027-07-05/em-0079.md) — Scheduled maintenance this weekend
- [em-0080](2027-07-05/em-0080.md) — Re: Corrie in-house rather than buy
- [mn-0012](2027-07-05/mn-0012.md) — Recap: Corrie / Garnet sync; security review/data pause, dictionary, login loop
- [mn-0013](2027-07-05/mn-0013.md) — Recap: SLIO leads call; unagreed slides v2, one-page summary
- [em-0081](2027-07-05/em-0081.md) — Re: Garnet LMS integration notes
- [ca-0015](2027-07-05/ca-0015.md) — Invite: Walkthrough: Siskin metrics definition
- [em-0082](2027-07-05/em-0082.md) — [INC-79170] Ticket updated
- [ca-0016](2027-07-05/ca-0016.md) — Invite: Garnet review
- [em-0083](2027-07-05/em-0083.md) — Room booking confirmation
- [em-0084](2027-07-05/em-0084.md) — Open enrollment reminder
- [em-0085](2027-07-05/em-0085.md) — Assessment design workshop action log (send promise)
- [ch-0066](2027-07-05/ch-0066.md) — DM: Bolat Oyelami / Hiba Jimenez; LMS notes send accepted
- [em-0086](2027-07-05/em-0086.md) — [Resolved] Elevated latency on file storage
- [nt-0007](2027-07-05/nt-0007.md) — Mon notes: Rania working-paper send confirmed

## 2027-07-06

- [em-0087](2027-07-06/em-0087.md) — Garnet privacy impact assessment request by July 7; not accepted
- [ch-0067](2027-07-06/ch-0067.md) — Hiba makes Dez's Garnet test-plan send official; no Dez reply
- [mt-0011](2027-07-06/mt-0011.md) — Corrie sync transcript; status-note promise recap, thin documentation
- [mn-0014](2027-07-06/mn-0014.md) — Automated Garnet standup: target August 3, Emre requirements matrix
- [ch-0068](2027-07-06/ch-0068.md) — Siskin one-page summary need edited to July 8 from July 7
- [ch-0069](2027-07-06/ch-0069.md) — Request Hiba assemble Garnet security review package
- [em-0088](2027-07-06/em-0088.md) — Rahul: Garnet lessons-learned request, budget agreed pending sign-off/figure
- [em-0089](2027-07-06/em-0089.md) — Room 4.02 confirmed July 15
- [em-0090](2027-07-06/em-0090.md) — INC-73804 shared drive permissions: In progress / no further action needed
- [ch-0070](2027-07-06/ch-0070.md) — Garnet security review package assembled; Hiba remote July 7
- [mn-0015](2027-07-06/mn-0015.md) — Automated workshop run-through: Torane sandbox already done
- [em-0091](2027-07-06/em-0091.md) — Sent Garnet lessons-learned note to Rahul
- [mn-0016](2027-07-06/mn-0016.md) — Worker workshop/Siskin notes: rubric review unagreed, metrics walkthrough reaffirmed
- [ch-0071](2027-07-06/ch-0071.md) — Bolat resumes Garnet evaluation rubric, not delivered
- [em-0092](2027-07-06/em-0092.md) — Desmond promises admissions stale-cache fix
- [em-0093](2027-07-06/em-0093.md) — Quad Ledger issue 27: meeting overload, vendor demos, records retention
- [em-0094](2027-07-06/em-0094.md) — Room 4.02 confirmed July 9
- [ch-0072](2027-07-06/ch-0072.md) — Corrie handover to Iselbury promised then completed
- [nt-0008](2027-07-06/nt-0008.md) — Voice-memo admissions rubric send promise, superseded by sent report
- [ch-0073](2027-07-06/ch-0073.md) — Admissions evaluation rubric sent to Bolat Oyelami
- [ch-0074](2027-07-06/ch-0074.md) — Desmond fixed admissions stale cache
- [em-0095](2027-07-06/em-0095.md) — Unsent workshop action-log draft; attachment not yet added

