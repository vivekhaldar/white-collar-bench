# Hiba Jimenez — durable work memory

**Current as of 2027-07-06.** Incorporated all 221 artifacts in the fourteen supplied inboxes, 2027-06-21 through 2027-07-06 (no June 27 or July 4 inputs supplied).

## Start here

- [Projects](memory/projects.md): current state, ownership, targets, decisions and meaningful history.
- [Commitments](memory/commitments.md): accepted work, waiting-on items, proposals, completed and dropped tasks.
- [People](memory/people.md): identities, roles and aliases, especially the two different Bolats and two different Zawadis.
- [Calendar and administration](memory/calendar-admin.md): upcoming bookings, cancellations and non-project notices.
- [Evidence index](evidence/INDEX.md): every artifact, including low-priority notices and social chat. Individual `evidence/<date>/<artifact-id>.md` files preserve sanitized source text, email quoted history, transcript speaker labels, and extracted document text.

## How to answer later

Use the curated memory for current state, then inspect the cited evidence for exact wording or details. Cite the **input artifact IDs** (e.g. `ch-0050`, `em-0065`), not just this summary. Evidence is retained outside the disposable inbox. Claims here are observations from inputs, not actions performed by this assistant.

Distinguish a request or suggestion from an accepted commitment; acknowledgements and emoji alone do not establish acceptance or completion. Repeated recaps are not new tasks. Completion evidence supersedes old checkboxes; dropped tasks are not outstanding. An unsent draft is not delivery, even when its body says "attached"; inspect draft metadata and attachment placeholders. A delivered draft does not imply final approval or all questions resolved. Project stage and outstanding tasks can differ.

Meeting-assistant notes/transcripts explicitly warn of errors. Prefer direct worker/owner messages, sent deliverables and worker notes when resolving conflicts; retain uncertainty when only automated notes support a claim. Calendar invitations do not prove attendance or that their agenda was completed. Artifact received dates may differ from message/event dates. Calendar UTC times are preserved; where local times are listed below they use the inputs' fixed **UTC−08:00**, not an inferred daylight-saving zone.

No supplied evidence means **unknown**, not completed, abandoned, or unchanged in reality. The baseline portfolio targets remain baseline targets unless explicitly updated. Do not infer the flagship's identity from a vague status-note risk. Never retain credentials, passcodes or meeting join links; these have been omitted from the evidence archive. DOCX text extraction does not preserve layout or unseen margin comments.
