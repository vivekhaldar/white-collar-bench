# Project portfolio

As of **2027-07-06**. Baseline ownership, sponsors, aliases and target dates below come from Hiba's June 21 portfolio map (`nt-0001`). All targets are 2027; Garnet's later reported target change is noted below. Hiba works in the Systemwide Learning Innovation Office (SLIO), Corrstead University System (`nt-0001`; email identity in `em-0001`).

## Garnet

**Aliases:** Project Garnet, early alert pilot, Crandale pilot. AI early-alert assistant at Crandale University hosted on Siskin. **Owner:** Ewan Laine. **Sponsor:** Anastasia Mizrahi. **Latest reported target: August 3**, moved from July 26 in July 6 automated standup recap (`mn-0014`, may contain errors; baseline `nt-0001`). No direct owner confirmation supplied.

- **Latest reported stage: security review; blocked, real student data paused pending that review**, July 5 automated recap (`mn-0012`, may contain errors). Supersedes build, reached June 23 (`nt-0002`). Hiba explicitly confirmed on July 1 that the pilot is limited to **three courses** (`ch-0056`; also baseline `nt-0001`).
- Hiba **assembled Garnet security review package July 6**, direct done report and Andrei acknowledgement (`ch-0070`, request `ch-0069`). This does **not** establish security review approval or lift the real-student-data pause.
- Tyrone Duarte requested Hiba **complete privacy impact assessment by July 7** (`em-0087`); no acceptance/completion supplied. Separate from the completed security review package.
- Rahul Sargsyan says **Garnet budget agreed**, but formal sign-off and figure still pending; he will share figure after sign-off (`em-0088`). No amount known; does not close the unagreed budget-justification review.
- Hiba **sent Garnet lessons-learned note to Rahul July 6**, sent email (`em-0091`, request `em-0088`). Note contents/attachment not supplied.
- Emre offered to handle and share **Garnet requirements matrix with Hiba**, July 6 automated recap only (`mn-0014`); no delivery.
- Hiba accepted **send Garnet LMS integration notes to Bolat Oyelami** July 5 (`ch-0066`, request `em-0081`); no delivery. Automated July 5 recap reports Hiba offered to **look into Garnet login loop**, and assigns Bolat **send Hiba Garnet data dictionary** (`mn-0012`); no completion and no direct corroboration. Do not equate the login loop with generic platform-status incidents.
- Hiba sent Bolat Oyelami the solution brief June 24: worker report and recipient acknowledgement (`ch-0026`), confirmed in sent June 25 status note (`em-0027`) and Dez's retrospective June 28 email (`em-0036`). Earlier June 22 action checkbox and June 23 recaps are superseded (`mn-0002`, `mt-0001`, `em-0016`, `ch-0017`).
- Hiba turned around API contract v2 June 23, acknowledged by Dez (`em-0019`, `ch-0018`).
- Maddie drafted load test plan June 28 after Hiba accepted her offer June 24 (`ch-0028`, `ch-0036`). **Do not conflate this with the unconfirmed Garnet test plan from Dez** (`mn-0010`).
- Maddie wrote support playbook June 29 (`ch-0043`), after tentative suggestion June 25 (`mt-0004`) and Hiba making it official June 29 (`em-0046`); completion also in July 2 status (`em-0065`).
- **Integration endpoint:** Maddie is responsible (`ch-0021`). July 1 says it is "back on, sorry for the delay" (`em-0060`): resumed, not delivered.
- Ewan committed to book faculty onboarding sessions (`ch-0029`); Bolat Oyelami committed to send Hiba evaluation rubric (`ch-0040`), and July 6 says **picking it back up**, not delivered (`ch-0071`); Hiba accepted Ewan's offer to share rollout checklist (`em-0049`). No completion evidence for these.
- Hiba committed to confirm Garnet support model with Bolat (`ch-0037`), send Andrei service blueprint (`ch-0047`, reaffirmed `ch-0053`), and review Bolat's accessibility audit (`ch-0058`). No completion evidence.
- **Dropped:** reviewing Andrei/the security manager's Garnet access request. Tentative in June 28 transcript (`mt-0007`), explicitly dropped June 29 as overtaken by events (`nt-0004`), confirmed July 2 sent status (`em-0065`).
- **Garnet test plan from Dez now made official by Hiba July 6**: "you'll send me" (`ch-0067`), superseding June 30 unconfirmed idea (`mn-0010`). Track as worker-confirmed assignment; Dez himself does not reply (Maddie's acknowledgement is not his acceptance), no delivery/deadline. Distinct from Maddie's drafted load test plan.
- **Not agreed:** Hiba reviewing Bolat's Garnet budget justification (`mn-0011`, automated July 2 recap).
- July 2 status warns "timelines on the flagship are tight" without naming which project; not enough evidence to assert Garnet specifically (`em-0065`).

## Siskin

**Aliases:** platform, common platform, Siskin platform. Shared AI platform supporting campus projects. **Owner:** Desmond Visser. **Sponsor:** Anastasia Mizrahi (`nt-0001`).

- **Latest stage: hardening**, June 29 (`ch-0042`), superseding baseline tenant onboarding (`nt-0001`).
- Emre **set gateway rate limits for tenants June 21**. Direct recap from Emre June 22 (`em-0010`, `em-0013`); owner completion supported by Andrei and Bolat (`ch-0007`, `em-0006`) and Hiba's June 25 status (`em-0027`). Earlier future-tense chat (`ch-0002`) is superseded.
- Emre **configured the SSO broker for Crandale**, reported June 25 by Ewan (`ch-0033`), after direct June 24 commitment (`ch-0022`).
- Hiba's **send support model to Emre** task is **done July 2**, sent email with attached **Siskin support model v2** (`em-0067`, `dc-0001`). June 22 request / secondhand future commitment (`ch-0012`, `ch-0011`) and June 24 blocked note "waiting on a vendor fix" (`mn-0005`) do not leave the send task outstanding. No explicit evidence the vendor fix itself was completed.
- **Support model v2 content:** prepared by Hiba, dated July 2. Two sections still being drafted; margin comments tracked and resolved comments removed; figures indicative/rounded. Costs need unit input; users show two options with no preference; governance reworded after feedback; scope only pilot group. Open questions: council submission needed? Who maintains it after project end? Delivery is not finalization (`dc-0001`).
- Hiba **accepted review of model allow-list** June 24 (`ch-0027`), reaffirmed June 29 (`mt-0009`). Initial June 22 proposal was explicitly not agreed (`ch-0009`). No completion evidence.
- Dez committed June 28 to **publish tenant onboarding guide** (`mt-0008`), reiterated June 30 (`mt-0010`); not evidenced published.
- Hiba requested **capacity plan from Dez** July 1; no acceptance by Dez (`ch-0051`). Emre's "ok" is not Dez's commitment.
- Hiba directly committed July 5 to **walk Bolat Oyelami through Siskin metrics definition** (`ch-0065`); July 8 walkthrough invite sent (`ca-0015`), not completed.
- July 5 automated leads-call recap assigns Hiba **send Andrei Siskin one-page summary** (`mn-0013`); tracked with source-quality caveat, no direct acceptance/delivery. **Recipient need is Thursday July 8**, Bolat's edited July 6 message; original Wednesday July 7 superseded. Hiba's "thanks for the heads up" acknowledges, not a fresh acceptance (`ch-0068`). Distinct from Garnet service blueprint and Siskin support model.
- **Not agreed:** Hiba reviewing Bolat Oyelami's Siskin evaluation rubric (`ch-0057`), still "not committed yet" in July 6 worker notes (`mn-0016`). Same notes reaffirm metrics walkthrough, not completion. This is distinct from Bolat sending the Garnet evaluation rubric.
- **Dropped:** send Siskin decision memo to Bolat. Suggested/not agreed June 23 (`mn-0004`); Bolat says no longer needed/overtaken by events June 25 (`mt-0005`).

## Admissions Triage Tool Selection

**Aliases:** admissions triage bake-off, Torane/Merol evaluation, ATTS selection. Tool selection at Crandale between Torane Software and Merol Labs. **Owner:** Hiba. **Sponsor:** Anastasia. **Baseline stage:** waiting on vendor questionnaires. **Target:** August 2 (`nt-0001`). No selection decision or later explicit project stage provided.

- Reading list sent to Catalina June 22, acknowledged and link confirmed working (`ch-0016`), superseding automated action item (`mn-0002`).
- **Merol security questionnaire sequence:** vendor account executive **Bolat Farah** promised July 2 (`em-0025`), then June 28 promised return "again" by July 5 (`em-0037`); June 29 said picking it back up (`em-0039`). Same day explicitly transferred to **Bolat Oyelami** (`em-0043`). Bolat Oyelami returned it June 30 (`ch-0050`), confirmed in Hiba's July 2 status (`em-0065`). **Closed**, not still due July 5. "Again" is retained source wording; earlier delivery before this sequence is not established.
- Still waiting on **Catalina's Torane deep-dive materials**, baseline item with no supplied completion (`nt-0001`). June 23 and June 28 catch-ups captured no new specific items (`mn-0003`, `mt-0002`, `mn-0006`, `mt-0006`); do not infer materials were delivered during them.
- Bolat Oyelami requested Hiba review his **admissions triage selection demo script July 2** (`em-0063`); Hiba acceptance not evidenced. Questionnaire completion alone does not establish selection completion or all vendor answers received.
- Hiba **sent admissions triage selection evaluation rubric to Bolat Oyelami July 6**, direct retrospective sent report and recipient acknowledgement (`ch-0073`), superseding same-evening voice-memo promise (`nt-0008`). Distinct from Garnet rubric Bolat owes Hiba and unagreed Siskin rubric review.
- Desmond **fixed admissions triage selection stale cache July 6**, direct done report (`ch-0074`) after promise (`em-0092`); not evidence of a selection decision.
- **Torane sandbox access set up**, vendor solutions engineer Zawadi Quinlan reports July 5 (`em-0078`), reiterated in July 6 automated workshop recap (`mn-0015`, source-quality caveat). Reset every Sunday night; first-login change requested. Credentials omitted. No evidence Hiba logged in, evaluated the sandbox, or received Catalina's deep-dive materials. This Torane sandbox is distinct from the requested alumni discovery sandbox.

## Elmwick Alumni Outreach Discovery

**Aliases:** Elmwick discovery, alumni outreach work, EAOD discovery. **Owner:** Mere Hidayat. **Sponsor:** Nurlan Kavanagh. **Baseline stage:** site visits / evolving problem framing. **Target:** August 3 (`nt-0001`).

- **July 5 decision: use approach A for alumni outreach discovery process map; stop doing the Elmwick data-sharing agreement, superseded by that decision** (`nt-0006`, direct worker note). Replaces July 1 unsigned-agreement blocker (`em-0058`) and closes the agreement work as **dropped, not signed/completed** (earlier Mere commitment `ch-0025`). Approach A details and any formal overall stage change are unknown; do not infer baseline data arrived or all access issues cleared.
- Hiba requested **alumni outreach discovery sandbox access from Desmond** July 5 (`em-0076`); no acceptance or setup evidence. Distinct from Torane sandbox access.
- Interview guide sent by Hiba to Bolat June 21 with recipient acknowledgement (`ch-0006`); automated same-day action checkbox is stale (`mn-0001`).
- Hiba committed June 29 to send Bolat **problem framing note** (`ch-0041`); no completion evidence.
- **Stakeholder map after Bolat's comments**: worker todo June 30 (`mn-0010`), Bolat's request (`em-0053`); July 2 automated recap reports Hiba confirmed done (`mn-0011`). Best available completion evidence, but recap warns of possible errors.
- Mere to pull baseline data from Elmwick, per Bolat June 29 (`em-0044`); no completion/direct Mere acceptance captured.
- Mere offered pain-point list July 1 (`ch-0054`), then reported it sent same day (`ch-0055`). Done.
- Coffee with Bolat about alumni outreach remains **unagreed**, suggested June 21 (`mn-0001`), explicitly not agreed June 23/25 (`mt-0001`, `ch-0034`), and still "not committed yet" June 30 (`mn-0009`).

## Assessment Design Workshop

**Aliases:** workshop, Aldervale workshop, assessment design session. Faculty workshop at Aldervale University. **Owner:** Bolat Oyelami. **Sponsor:** Anastasia. **Hiba owns slides. Target:** August 16 (`nt-0001`).

- **Latest stage: logistics**, June 22 (`em-0008`), superseding baseline planning.
- Send attendee list to Bolat is only **suggested/not agreed** in June 28 automated recap (`mn-0007`).
- **Send Funmilayo slides v2, due July 12**, is only suggested; **no owner agreed** in July 5 automated leads-call recap (`mn-0013`). Hiba's baseline slide ownership does not mean this specific send task is accepted.
- Hiba directly committed July 5 to **send Funmilayo assessment design workshop action log** (`em-0085`). July 6 `em-0095` is **unsent draft** (`X-Draft: true`), despite "please find ... attached" wording; it explicitly says **attachment not yet added**. Send remains outstanding, no deadline. Draft invites comments before wider circulation; neither delivery nor wider circulation is evidenced. Distinct from slides v2.
- June 30 run-through notes confirm Hiba's July 2 status-note task and unagreed alumni coffee, not new workshop deliverables (`mn-0009`). No evidence of slides completion or workshop occurrence.

## Corrie

**Aliases:** Project Corrie, course assistant prototype. In-house central-team prototype before campus adoption; Iselbury State College collaborators. **Owner:** Hiba. **Sponsor:** Anastasia. **Target:** August 2 (`nt-0001`).

- **Latest stage: handover**, June 25 (`ch-0032`), after prototype building baseline (`nt-0001`) and June 22 move to user testing (`em-0011`).
- **Build rather than buy confirmed July 5 by sponsor Anastasia**: Corrie will be built in-house (`em-0080`).
- **Hiba handed Corrie over to Iselbury July 6**, direct same-day promise then completed report and Zawadi acknowledgement (`ch-0072`). This completes the handover action, but does not establish usability findings/script completion, a changed target, or a new ongoing owner/stage.
- July 6 Corrie sync transcript supplied (`mt-0011`): recap of Hiba's w/e July 9 status-note promise, not delivery; Bolat says documentation still thin without a specific new task. Auto-transcript spellings may be inaccurate.
- Write up usability findings: request by Anastasia forwarded June 23 via Bolat Oyelami (`em-0015`); no direct acceptance or completion captured.
- Hiba directly committed to **confirm usability test script with Zawadi** June 24 (`mt-0003`); no completion captured. The later handover stage does not automatically close these tasks.
- July 1 sync cancelled June 30 "nothing to discuss this week" (`ca-0013`, supersedes `ca-0012`). New sync invited for July 6 (`ca-0014`), not cancellation of the project.

## Holmarsh Partnership

**Aliases:** Holmarsh relationship, Holmarsh. Relationship maintenance / introductions with Holmarsh Institute for Learning Research. **Owner:** Hiba. **Sponsor:** Anastasia. **Stage:** ongoing (`nt-0001`); no later explicit stage change.

- Hiba introduced **Rania Dlamini to Bolat Oyelami for Holmarsh working group June 25**, acknowledged by Rania (`ch-0031`), after request/acceptance (`em-0020`, `ch-0024`). Done.
- Rania sending Hiba **Holmarsh working paper is now confirmed**, direct worker July 5 note (`nt-0007`); no delivery/deadline supplied. Supersedes unagreed June 30 / July 2 state (`nt-0005`, `ch-0059`); Hiba's earlier "perfect, thanks" alone was not acceptance.

## Siskin Operating Model Review

**Aliases:** operating model review, ops model draft, Siskin operating model. **Owner:** Desmond. **Sponsor:** Anastasia. **Baseline stage:** out for peer review before leadership (`nt-0001`); no evidenced final approval or later stage.

- Maddie **sent comparison table June 30** (`ch-0044`), after promised send reported June 24 (`ch-0023`). Closed waiting-on item.
- Hiba reviewing **Dez's draft v2** still **not agreed**. June 29 request followed by Hiba "let me check and get back to you" (`ch-0039`); July 2 Desmond explicitly reiterates not agreed (`em-0062`). Emoji is not completion.
- Hiba offered to **confirm summary of changes with Ewan**, per July 2 automated recap (`mn-0011`); tracked as commitment with source-quality caveat, not completed. Distinct from draft-v2 review and Siskin support model.

## Iselbury Thesis Formatting Idea

**Aliases:** Zawadi's thesis formatting idea, thesis formatting placeholder. **Owner:** Zawadi. **Sponsor:** Anastasia. **Stage:** waiting on problem statement from Zawadi to Hiba (`nt-0001`). No dated update or completion in supplied inputs. Keep separate from Corrie.

## Merol Captioning Diligence

**Aliases:** Merol deep dive, captioning diligence. **Owner:** Hiba. **Sponsor:** Anastasia. **Stage:** stalled/gone quiet, early enthusiasm but no recent activity (`nt-0001`). No subsequent update. Do not use admissions questionnaire activity as evidence this captioning work revived.

## Syllabus Review Learning Series

**Aliases:** learning series, syllabus review talks. Faculty learning series with Holmarsh; Elmwick links. **Owner:** Bolat Oyelami. **Sponsor:** Anastasia (`nt-0001`).

- Quiet/no sessions booked at baseline (`nt-0001`), **revived June 23** (`nt-0003`), **scheduling June 24** (`ch-0020`), confirmed June 25 status (`em-0027`). Latest evidenced stage: scheduling; no booked session dates supplied.
- Bolat **confirming spring series dates** is only suggested/not agreed in June 29 automated Garnet recap (`mn-0008`); meeting title does not make this a Garnet action.
