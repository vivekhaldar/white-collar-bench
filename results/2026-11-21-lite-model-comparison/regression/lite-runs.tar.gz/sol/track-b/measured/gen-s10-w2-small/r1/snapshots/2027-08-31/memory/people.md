# People and organizations

Worker **Aoife Everett**, Federation Data Office (FDO), Reddale Community Federation. Aoife owns Translation Help Tool Selection, Morgate Partnership, Noris Event Signups Diligence; not overall owner of Nettle/Pipit/HPID/Kelholm referral idea. [nt-0001]

## Directory
Roles below are explicit baseline roles unless otherwise noted. [nt-0001]

| Person | Role / organization | Relevant connections |
|---|---|---|
| Gaurav Laine | Development Director, Ormton Housing Trust | Nettle owner; training outline sender; comments dependency for board paper; recipient Pipit rollout checklist |
| Bruna Thapa | Executive Director, Ormton Housing Trust | Nettle sponsor |
| Douglas Grigoryan | Program Coordinator, Ormton Housing Trust | Nettle member-survey sender to Aoife [mt-0010]; Pipit summary walkthrough recipient [em-0057; ca-0002]; `Doug`, `Dooglas` in inputs |
| Akosua Bergstrom | Programs Manager, FDO | Cross-portfolio colleague, sender/forwarder; pantry findings/opportunity work; recipient requirements, safeguarding checklist, stakeholder map, pain-point list [em-0056; mn-0015]; comments for Nettle RACI |
| Bisi Volkov | Platform Lead, FDO | Nettle architecture-diagram confirmation counterpart/test-login setup [ch-0037; ch-0039]; on-call rota draft with Bergstrom [em-0062; dc-0002]; Pipit owner; Nettle API ask, synthetic data generation and vendor comparison; member-survey recipient [ch-0035]; tentative dependency-list recipient, rendered `Bisy` in transcript [mt-0011] |
| Sigrid Asante | Security & Privacy Lead, FDO | Nettle data-flow recipient, security package requester, one-page summary and integration spec requests |
| Sipho Papadopoulos | Data Engineer, FDO | Nettle metrics definition sender; Pipit SSO configuration; `Sipho P.` |
| Adaeze Morimoto | Product Manager, FDO | Nettle budget justification comments dependency |
| Paula Dubois | Director of Shared Technology, FDO | Friday status recipient; sponsor Pipit, Morgate, Kelholm referral, Noris diligence |
| Lilit Yilmaz | Executive Director, Holworth Family Services | Sponsor THTS and HPID |
| Amani Xu | Programs Director, Holworth Family Services | HPID owner; countersigned data-sharing agreement; `Amani`, `@amani`; promises Noris accessibility conformance report [ch-0041; manifest title] |
| Amani Katz | Role/organization unknown | Distinct `Amani`, `@amanik`; promises grant reporting session notes [ch-0044; manifest title] |
| Catrin Dang | Program Coordinator, Holworth Family Services | Pantry baseline data commitment; requirements-delivery recap; translation-selection vendor comparison proposed for review [mn-0015] |
| Akosua Carmichael | Account Executive, Noris Cloud | Noris deep-dive materials promise; joint offer on translation requirements |
| Nare Dempsey | Operations Lead, Kelholm Literacy Council | Referral matching idea owner, problem statement outstanding; Morgate connection |
| Tahmina Ozturk | Morgate affiliation evidenced by `morgate-research.example` address; job title unknown | Introduction to Bergstrom completed; working paper received and used in deck by Aoife 31 Aug [em-0044; em-0047; nt-0005; ch-0038] |
| Solene Zimmermann | Role/organization not specified in supplied inputs | Asked Aoife for Nettle privacy impact assessment [ch-0016]; participates in internal chats [ch-0025; ch-0031] |
| Rafael Esposito | Events Coordinator; exact organization not separately stated, Reddale address | Room confirmations, catering, event survey [em-0008; em-0022; em-0023] |
| Nurlan Banda | Newsletter sender; job title unknown | Community Digital Notes issue 33 [em-0011] |

Task connections are substantiated by the commitments ledger's artifact citations, not by role alone.

## Akosua disambiguation
- `@akosua`, `Akosua`, `Akosua B.` in Reddale core channels and DMs resolve to **Bergstrom** where manifest title/full participants/context establish it. Avoid using bare first name in answers when ambiguous. [ch-0008; ch-0019; mt-0007; nt-0001]
- Noris materials are expected from **Carmichael**, not Bergstrom. Bergstrom forwards original promise by Carmichael and repeats it; no materials delivered. Baseline bare `Akosua` should not prevail over explicit sender. [em-0006; ch-0008]
- Translation requirements went to **Bergstrom**, not Carmichael. Carmichael joined the offer to prepare/send, while explicit Catrin recap and Aoife status establish recipient. [mt-0001; mt-0002; em-0026; em-0029]
- `our programs manager` for safeguarding checklist maps to Bergstrom, confirmed explicitly in status. [nt-0001; mt-0005; em-0052]
- Morgate introduction `Akosua` maps to Bergstrom from forwarded addressing/context. [em-0044; em-0047]

## Amani disambiguation
Both 31 Aug DMs display only `Amani`, but original manifest titles identify **Xu** for `ch-0041` (`@amani`, Noris accessibility report) and **Katz** for `ch-0044` (`@amanik`, grant reporting notes). Do not merge them or infer Katz's role/organization from Xu. Full titles are preserved in `sources/index.json`.

## Organizations
- Reddale Community Federation: worker's organization; FDO is team. Shared platform Pipit operated by Bisi's team. [nt-0001]
- Ormton Housing Trust: Nettle pilot, Gaurav/Douglas/Bruna. [nt-0001]
- Holworth Family Services: translation selection and pantry discovery, Lilit/Amani/Catrin. [nt-0001]
- Kelholm Literacy Council: Nare, referral idea; also listed under Morgate and Noris event diligence. [nt-0001]
- Morgate Social Research Institute: partnership; Tahmina's Morgate correspondence. [nt-0001; em-0044]
- Noris Cloud and Ithtec Analytics: translation-selection candidates; also organizations listed for event-signups diligence. Noris account executive Carmichael. No winner known. [nt-0001]
