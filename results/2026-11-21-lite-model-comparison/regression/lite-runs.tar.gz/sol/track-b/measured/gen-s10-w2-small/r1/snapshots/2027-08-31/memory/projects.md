# Current portfolio — as of 2027-08-31

Baseline portfolio, owners, sponsors, people, aliases and original targets: [nt-0001]. Subsequent updates below supersede baseline stages where stated. See [commitments](commitments.md) for all individual actions.

## Nettle
**Aliases:** Project Nettle; outcomes dashboard pilot; Ormton pilot. AI outcomes dashboard pilot at Ormton Housing Trust, hosted on Pipit. **Owner:** Gaurav Laine. **Sponsor:** Bruna Thapa. **Target:** 11 October 2027; no later target change known. [nt-0001]

**Latest stage: security review; blocked for real client data.** Baseline was in build on 16 Aug; on 17 Aug Aoife recorded that it had moved into security review, with real client data paused pending that review. No clearance/resumption is evidenced through 31 Aug. The 30 Aug security-review transcript does not record clearance; Aoife says documentation is still thin. [mt-0011] [nt-0001; nt-0002] Bisi promised and then reported generating synthetic client data on 18 Aug; this does not establish security clearance or unblock real data. [ch-0010; em-0015]

**Scope decision:** limit pilot to four branches, stated by Aoife 25 Aug and accepted by Akosua in thread; baseline already described four branches. No branch names or expansion approval known. [ch-0024; nt-0001]

**Test-plan decision:** use **approach A**, recorded in Aoife's 30 Aug morning note. Approach A's contents, alternatives and rationale are not supplied. [nt-0006]

**Open accepted work for Aoife:** send Sigrid data-flow diagram; assemble security review package; complete privacy impact assessment (Solene's ask accepted later); update budget justification after Adaeze's comments; update board paper after Gaurav's comments (acceptance evidenced by generated recap); send Bisi the member survey (30 Aug direct promise). Douglas separately promised to send Aoife the same named survey at standup; neither delivery is evidenced, and a dependency is plausible but not explicitly stated. Dates, dependencies and evidence in ledger. [em-0007; ch-0015; nt-0003; mn-0008; mt-0006; mn-0010; ch-0035; mt-0010]

**31 Aug new accepted work:** confirm architecture diagram with Bisi **by Wed 1 Sep**, directly accepted `yep, on it` [ch-0037]; look into duplicate notifications, accepted according to generated standup recap only [mn-0016]. Architecture diagram is not presumed to be the data-flow diagram to Sigrid. Bisi agreed to set up Aoife's Nettle test tenant login; no completion known [ch-0039]. Safeguarding checklist is again recapped as done [mn-0017], not a new action.

**Not accepted / proposed:** API contract v2 from Bisi (repeatedly not agreed); data dictionary confirmation with Akosua; Sigrid's one-page summary; RACI chart update after Akosua's comments. Aoife's 30 Aug offer to send Bisi the dependency list was explicitly tentative: `I'll try ... no promises`. Do not convert these to promises. [mn-0003; mt-0007; mn-0011; em-0038; mn-0010; mn-0012; mt-0011] On 31 Aug Bergstrom's edited message says Bisi needs the dependency list **Thu 2 Sep**, correcting the original **Sat 4 Sep**; Aoife's eyes reaction does not make the tentative offer firm. [ch-0043]

**Delivered:** Sipho sent metrics definition on 18 Aug, confirmed by Aoife and later recap; Gaurav sent training outline 26 Aug after formalizing the ask; Aoife sent safeguarding checklist to Akosua Bergstrom, reported 25 Aug and confirmed in 27 Aug status note. None of these deliverable contents are supplied. [ch-0011; em-0017; ch-0027; ch-0028; mt-0008; em-0052]

**Retired:** action log parked 24 Aug (folded into a broader ask); Bisi vendor comparison dropped 26 Aug (no longer needed). Broader ask not identified. Neither is an outstanding review obligation. Sigrid's integration-spec request was dropped 30 Aug as a duplicate of another ask; the other ask is unidentified, not inferred to be the security package or data-flow diagram. [em-0034; ch-0029; ch-0033; em-0052; em-0048; nt-0007]

Core people: Gaurav, Bruna, Douglas Grigoryan, Akosua Bergstrom, Bisi Volkov, Sigrid Asante, Sipho Papadopoulos, Adaeze Morimoto. [nt-0001]

## Pipit
**Aliases:** the platform; common platform; Pipit platform. Shared data platform on which member-organization projects build. **Owner:** Bisi Volkov. **Sponsor:** Paula Dubois. Baseline onboarding tenants; **latest stage hardening** on 27 Aug. No target date supplied. [nt-0001; mn-0013]

- Sipho agreed to configure the SSO broker for Ormton, 24 Aug; no completion yet. In that discussion Gaurav said he would rather not escalate yet; no broader escalation policy inferred. [mt-0006]
- Bisi reported Aoife would send Gaurav rollout checklist from 26 Aug sync; no delivery known. [ch-0030]
- Sipho promised to fix the stale cache 31 Aug and reported it fixed at 16:40; Aoife acknowledged. Completed as reported, distinct from the still-open SSO broker work and not proof of general platform incident resolution. [ch-0040; ch-0042]
- Bisi's 31 Aug email offers drafting the on-call rota with Akosua Bergstrom, then reports it done and attaches **v3**. The document is a working draft prepared by Bisi; governance aligned with shared glossary, users have two options/no preference, Security says agreed at last review, Data unchanged. It says two sections are still being drafted, and final sign-off and hosting unit remain open questions. No actual on-call shifts/cover schedule are supplied. Reported draft delivery is done; final approval is unknown. Full body: `sources/2027-08-31/dc-0002.md`. Its Security row does not clear Nettle real client data. [em-0062; dc-0002]
- Model allow-list review raised for Aoife 17 Aug but no owner agreed; 18 Aug recap says not agreed. Still proposed, not accepted. [mn-0002; em-0012]
- Aoife promised to walk Douglas through the Pipit one-page summary 30 Aug. Invitation schedules **Thu 2 Sep, 14:00–14:30 local (+01:00)**; Douglas RSVP still NEEDS-ACTION. No completion or summary contents supplied. This is distinct from Sigrid's proposed Nettle one-page-summary review. [em-0057; ca-0002]

Core people: Bisi, Akosua Bergstrom, Gaurav, Douglas, Sipho, Sigrid. [nt-0001]

## Translation Help Tool Selection (THTS)
**Aliases:** translation help bake-off; Noris/Ithtec evaluation; THTS selection. Tool selection for Holworth Family Services; Noris Cloud and Ithtec Analytics in running. **Owner:** Aoife. **Sponsor:** Lilit Yilmaz. **Target:** 20 September 2027, unchanged in known inputs. [nt-0001]

Baseline gathering requirements; **moved into questionnaires** 20 Aug. No selection result or later stage known. [nt-0001; mt-0004]

Aoife and Akosua Carmichael offered to send requirements list to Akosua Bergstrom in 17 Aug 1:1. Aoife reported sending it 18 Aug; Catrin clarified recipient as Bergstrom on 20 Aug; Aoife's 20 Aug status note confirms. This action is complete. Transcript spelling `Akosuah` is resolved by explicit later email, not a distinct person. [mt-0001; mt-0002; em-0026; em-0029]

Draft requirements workbook, prepared by Aoife, FDO, attached to 20 Aug status note; sheet `Tracker`: [dc-0001, parent em-0029]

| ID | Item | Status | Notes |
|---|---|---|---|
| 01 | Accessibility review | open | new this version |
| 02 | Sign-off | done | carried over |
| 03 | Data feed | open | carried over |
| 04 | Documentation | in review | carried over |
| 05 | Access | done | — |
| 06 | Comms | in review | waiting on another team |

These are **draft workbook row states**, not evidence that a vendor has been selected or all procurement signed off. No more detailed requirements supplied. Full transcription: `sources/2027-08-20/dc-0001.md`.

30 Aug Holworth generated recap suggests Aoife review **Catrin's translation help selection vendor comparison**, explicitly with no owner agreed. Not accepted and distinct from Bisi's dropped Nettle vendor comparison. Comparison contents absent. [mn-0015]

People: Akosua Bergstrom, Amani Xu, Catrin Dang, Akosua Carmichael. Do not confuse this selection with Noris event-signups diligence. [nt-0001]

## Holworth Pantry Inventory Discovery (HPID)
**Aliases:** Holworth discovery; pantry inventory work; HPID discovery. **Owner:** Amani Xu. **Sponsor:** Lilit Yilmaz. Discovery on pantry inventory, problem framing still moving. **Latest known stage:** doing site visits (baseline, no explicit replacement). **Target:** 20 September 2027, unchanged. People Amani, Akosua Bergstrom, Catrin. [nt-0001]

- Findings summary review: Aoife accepted 17 Aug, reported reviewed 19 Aug, confirmed in 20 Aug status note. Done. [ch-0006; ch-0014; em-0029]
- Observation notes confirmation with Akosua: offered 18 Aug, put on hold 20 Aug awaiting Akosua, still waiting 23 Aug; **parked 24 Aug, superseded by a decision**. No details of replacing decision known. Do not keep it as a live blocked task. [ch-0013; em-0025; mn-0007; ch-0023]
- Akosua's opportunity-list review: suggested at 19 Aug forum, not accepted. Distinct from findings summary review. [mn-0004]
- Catrin agreed to pull Holworth baseline data 23 Aug, reiterated 24 Aug, still picking it up 27 Aug. No delivery known. [em-0032; ch-0022; mn-0014]
- Amani offered to countersign data-sharing agreement 24 Aug and reported countersigning 25 Aug. Completed; agreement text absent. [em-0036; em-0041]
- Stakeholder map: Aoife promised to send Akosua 27 Aug and sent same day 17:08. Completed; map contents absent. [ch-0034; em-0053]
- Pain-point list: Bergstrom requested it 30 Aug; same-day generated site-visit recap says Aoife is picking it up and assigns sending to Akosua. Accepted according to recap only, no direct worker acceptance/delivery or deadline. List contents absent. Repeated in 31 Aug 1:1 generated recap; still no direct worker promise or delivery. [em-0056; mn-0015; mn-0017]

26 Aug Lilit catch-up: Aoife noted intended users were not in the room; Lilit recalled previous work taking longer than expected. The transcript does not explicitly identify the project or record a new decision/action. [mt-0009]

## Morgate Partnership
**Aliases:** Morgate relationship; Morgate. **Owner:** Aoife. **Sponsor:** Paula Dubois. Ongoing relationship work: introductions, catch-ups, favors. Organizations listed in baseline: Morgate Social Research Institute and Kelholm Literacy Council; people Akosua Bergstrom and Nare Dempsey. [nt-0001]

Tahmina Ozturk (Morgate) asked for introduction to Akosua for working group; forwarded by Bergstrom 26 Aug. Aoife confirmed introduction completed same day. Recipient resolved to Bergstrom from forwarding context, not Carmichael. [em-0044; em-0047]

**Working paper received/used:** expected from Tahmina in Aoife's 27 Aug evening note [nt-0005]; 31 Aug Aoife says she pulled the Morgate working paper into the deck and thanks Tahmina. This establishes receipt/use, retiring the wait; paper and deck contents remain unknown. [ch-0038]

## Kelholm Referral Matching Idea
**Aliases:** Nare's referral matching idea; referral matching placeholder. **Owner:** Nare Dempsey. **Sponsor:** Paula Dubois. Kelholm Literacy Council placeholder **waiting on a problem statement**. Aoife had asked Nare to send it; Akosua's 23 Aug recap says Nare agreed 16 Aug; Aoife still waiting 23 Aug. No receipt evidenced through 31 Aug. Target unknown. [nt-0001; ch-0019; mn-0008]

## Noris Event Signups Diligence
**Aliases:** Noris deep dive; event signups diligence. **Owner:** Aoife. **Sponsor:** Paula Dubois. **Stage:** in diligence (baseline); early enthusiasm, nothing dated since in baseline. Organizations: Kelholm Literacy Council, Noris Cloud, Ithtec Analytics. [nt-0001]

Baseline says waiting on `Akosua` for materials. Forwarded original email specifies **Akosua Carmichael**, Noris account executive, offering to send Aoife Noris deep-dive materials 16 Aug; Bergstrom forwarded promise 17 Aug and recapped it in DM. These are not delivery of the materials. Waiting remains open; deadline unknown. [nt-0001; em-0006; ch-0008]

## New incoming work with unspecified project
- **Amani Xu** (`@amani`) promises to send Aoife the **Noris accessibility conformance report** 31 Aug; no receipt or deadline. Explicit project association is absent: do not assume translation selection or event-signups diligence. Identity comes from manifest title. [ch-0041]
- **Amani Katz** (`@amanik`) promises Aoife **notes from the grant reporting session** 31 Aug; no receipt/deadline or project association. Manifest distinguishes Katz from Xu. [ch-0044]
