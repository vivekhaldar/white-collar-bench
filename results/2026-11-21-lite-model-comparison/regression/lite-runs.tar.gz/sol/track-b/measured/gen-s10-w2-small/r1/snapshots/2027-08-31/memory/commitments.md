# Commitments ledger — through 2027-08-31

Dates below refer to actions/statements, not just receipt. Unless explicitly supplied, **deadline unknown**; do not infer project target dates as task deadlines. Repeated recaps are one item. Reported deliveries are recorded as complete but deliverable contents may be absent.

## Aoife — accepted and still open

| Project | Action / recipient or dependency | Accepted evidence | Latest state |
|---|---|---|---|
| Nettle | Send data-flow diagram to Sigrid Asante | Aoife `Will send`, 17 Aug [em-0007] | Open; no delivery or deadline supplied |
| Nettle | Assemble security review package for Sigrid | Ask 18 Aug [ch-0009]; Aoife `will do` 19 Aug [ch-0015] | Open; `no problem` 20 Aug, `on it` 23 Aug and repeated recaps through 25 Aug [ch-0018; ch-0021; mn-0005; mn-0009; mt-0007; ch-0026]. No completion |
| Nettle | Complete privacy impact assessment, requested by Solene Zimmermann | Tentative `maybe` 19 Aug [ch-0016], then explicit `yes` in 20 Aug note [nt-0003] | Accepted, still open; reaffirmed 23 Aug [mn-0008]. No deadline |
| Nettle | Update budget justification **after Adaeze's comments** | Aoife `I'll update`, 24 Aug [mt-0006] | Open, conditional on comments; no proof comments received |
| Nettle | Update board paper **after Gaurav's comments** | 25 Aug generated recap says Aoife has it [mn-0010] | Open, conditional; acceptance supported only by generated summary, no direct worker confirmation supplied |
| Pipit | Send rollout checklist to Gaurav | Bisi's 26 Aug sync recap `Aoife will send` [ch-0030] | Open; reported commitment, no direct promise/delivery supplied |
| Nettle | Send member survey to Bisi Volkov | Aoife `i'll send you`, 30 Aug 08:31 [ch-0035] | Open; no delivery/deadline. Douglas separately promises incoming survey below; dependency not explicit |
| Pipit | Walk Douglas Grigoryan through one-page summary | Aoife `I'll walk you through`, 30 Aug [em-0057] | Open; scheduled Thu 2 Sep 14:00–14:30 local (+01:00) [ca-0002]; Douglas RSVP NEEDS-ACTION; not yet performed |
| HPID | Send pantry inventory discovery pain-point list to Akosua Bergstrom | Ask 30 Aug [em-0056]; generated recap assigns to Aoife / says picking it up [mn-0015] | Open; repeated 31 Aug [mn-0017]. Acceptance supported only by generated recaps. No direct promise, delivery or deadline |
| Nettle | Confirm architecture diagram with Bisi Volkov | Bisi asks by Wednesday; Aoife `yep, on it`, 31 Aug [ch-0037] | Accepted; **due Wed 1 Sep** (no time supplied); no completion. Distinct from data-flow diagram to Sigrid |
| Nettle | Look into duplicate notifications | 31 Aug standup generated recap says Aoife offered and assigns action [mn-0016] | Open; acceptance supported only by generated recap; no deadline or completion |

## Dated reporting requirement

| Project | Action | Due / state | Evidence |
|---|---|---|---|
| FDO | Friday status note w/e 3 Sep to Paula Dubois; half-page covering what moved, slipped and leadership needs | **EOD Fri 3 Sep**; reminder received, no completion or extension known (reply to request extension) | [em-0054] |

## Waiting on others / expected incoming

| Project | Person → Aoife / action | History and current state |
|---|---|---|
| Kelholm referral matching | Nare Dempsey → referral matching problem statement | Requested in baseline [nt-0001]; Bergstrom recap 23 Aug says Nare agreed 16 Aug [ch-0019]; worker still waiting 23 Aug [mn-0008]. Open; no receipt |
| Noris event signups | Akosua **Carmichael** → Noris deep-dive materials | Baseline uses ambiguous `Akosua` [nt-0001]; forwarded Carmichael offer of 16 Aug [em-0006] and Bergstrom recap [ch-0008] resolve sender. Open; forwarded promise is not materials |
| HPID | Catrin Dang → pull pantry inventory baseline data from Holworth | Offered 23 Aug [em-0032], explicit recap of agreement 24 Aug [ch-0022], still assigned 27 Aug [mn-0014]. Open; no delivery |
| Pipit | Sipho Papadopoulos → configure SSO broker for Ormton | `I'll configure`, 24 Aug [mt-0006]. Open; no completion. Recipient not specified |
| Nettle | Douglas Grigoryan → Aoife, member survey | Direct `I'll send Aoife` in 30 Aug standup transcript [mt-0010]. Open; no receipt/deadline; distinct from Aoife's onward-send promise to Bisi [ch-0035] |
| Nettle | Bisi Volkov → set up test tenant login for Aoife | Aoife asks and Bisi `sure, can do`, 31 Aug [ch-0039]. Accepted, open; no deadline/completion; no login credentials retained |
| Noris accessibility (project unspecified) | Amani **Xu** → Aoife, Noris accessibility conformance report | 31 Aug `on it, i'll send` [ch-0041; manifest title]. Open; no deadline/delivery. Inputs do not explicitly place it in THTS vs event-signups diligence |
| Grant reporting (project unspecified) | Amani **Katz** → Aoife, grant reporting session notes | 31 Aug `Will send you`, handle `@amanik` [ch-0044; manifest title]. Open; no deadline/delivery; not Amani Xu |

## Requests / suggestions not accepted

These are **not** current accepted Aoife obligations. Unknown whether anyone else ultimately owns them.

| Project | Item | Evidence / history |
|---|---|---|
| Nettle | Turn around API contract v2, Bisi's request | Raised 16 Aug, suggested only [mn-0001]; `not agreed yet` 17 Aug [em-0010]; Aoife `maybe` 18 Aug [ch-0012]; worker `haven't said yes` 19 Aug [mn-0003]. Repeated same ask [mn-0005; mn-0006; ch-0020; mn-0009; mt-0007]; latest 25 Aug recap says no owner agreed [mn-0011]. Still unaccepted |
| Pipit | Review model allow-list, Bisi's request | 17 Aug generated recap no owner agreed [mn-0002]; 18 Aug Akosua recap not agreed [em-0012]. Still unaccepted |
| HPID | Review Akosua Bergstrom's opportunity list | 19 Aug generated forum summary says open/suggested [mn-0004]. No acceptance. Not the completed findings-summary review |
| Nettle | Review Sigrid's one-page summary | 25 Aug generated recap open/suggested [mn-0010]. No acceptance |
| Nettle | Confirm data dictionary with Akosua Bergstrom | Request 25 Aug [em-0038]. No worker acceptance |
| Nettle | Update RACI chart after Akosua's comments | 26 Aug generated recap says no owner agreed [mn-0012]. No acceptance |
| Nettle | Send dependency list to Bisi Volkov | Aoife `I'll try ... no promises`, 30 Aug [mt-0011]. **Needed by Thu 2 Sep**, per edited Bergstrom message 31 Aug [ch-0043], correcting original Sat 4 Sep. Aoife's eyes reaction is acknowledgment, not acceptance; still tentative, not a firm commitment |
| THTS | Review Catrin Dang's translation help selection vendor comparison | Generated Holworth recap 30 Aug says suggested / no owner agreed [mn-0015]. Not accepted; distinct from dropped Nettle vendor comparison |

## Completed / delivered

| Project | Item | Timeline and completion evidence |
|---|---|---|
| HPID | Aoife review of Akosua Bergstrom's findings summary | Accepted 17 Aug [ch-0006]; reported reviewed 19 Aug [ch-0014]; 20 Aug status confirms [em-0029] |
| THTS | Aoife send requirements list to Akosua Bergstrom | Joint offer with Carmichael in 17 Aug 1:1 [mt-0001]; Aoife reported sent 18 Aug [mt-0002]; Catrin clarified Bergstrom recipient [em-0026]; status confirms [em-0029]. Draft workbook exists [dc-0001] |
| Nettle | Bisi generate synthetic client data set | Promised 18 Aug [ch-0010]; reported generated same day [em-0015]. Dataset itself absent |
| Nettle | Sipho send Aoife metrics definition | Aoife asked and Sipho promised 18 Aug [mt-0002]; `just sent` and Aoife thanks same day [ch-0011]; confirmed 19 Aug [em-0017]. Definition itself absent |
| Nettle | Aoife send safeguarding checklist to Akosua Bergstrom | Offered to `our programs manager` 23 Aug [mt-0005]; reported sent 25 Aug [mt-0008]; explicit Bergstrom recipient in 27 Aug status [em-0052]; 31 Aug recap confirms done [mn-0017]. Checklist itself absent |
| Nettle | Gaurav send Aoife training outline | Possible only 24 Aug [nt-0004]; formalized 26 Aug [ch-0027]; Gaurav reported sent and Aoife acknowledged same day [ch-0028]. Outline itself absent |
| HPID | Amani countersign Holworth data-sharing agreement | Offer forwarded 24 Aug [em-0036]; direct completed statement 25 Aug [em-0041]. Agreement itself absent |
| Morgate | Aoife introduce Tahmina to Akosua Bergstrom for working group | Request forwarded 26 Aug [em-0044]; Aoife confirmed done same day [em-0047] |
| HPID | Aoife send stakeholder map to Akosua Bergstrom | Promised 27 Aug 15:18 [ch-0034]; sending email 17:08 same day [em-0053]. Map itself absent |
| Morgate | Tahmina's working paper received/used by Aoife | Expected 27 Aug [nt-0005]; Aoife `pulled the morgate working paper into the deck, thanks tahmina`, 31 Aug 10:24 [ch-0038]. Receipt/use evidenced by worker statement, not reaction alone; paper and deck contents absent |
| Pipit | Sipho fix stale cache | Direct promise 31 Aug 13:27 [ch-0040]; reports fixed 16:40, Aoife thanks [ch-0042]. Completed as reported; edited typo `stael` → `stale` does not change state. Not SSO configuration or general incident resolution |
| Pipit | Bisi draft on-call rota with Akosua Bergstrom | 31 Aug email contains offer then says done and attaches v3 [em-0062; dc-0002]. Reported draft/delivery complete, not an open drafting promise. Working document still describes two sections being drafted and asks final sign-off/hosting questions; actual shifts/cover not supplied |
| FDO | Friday status note w/e 20 Aug → Paula Dubois | Due EOD 20 Aug [em-0001]; Paula recap agreed [em-0013]; sent 20 Aug 16:48 [em-0029] |
| FDO | Friday status note w/e 27 Aug → Paula Dubois | Due EOD 27 Aug [em-0030]; sent 27 Aug 17:08 [em-0052]. Complete, not overdue |

### Weekly report content
20 Aug status: findings summary reviewed; translation requirements list sent; `Risks: nothing new this week`. [em-0029]
27 Aug status: vendor comparison no longer needed; action log dropped/folded into broader ask; safeguarding checklist sent; `Risks: nothing new this week`. [em-0052]
These risk statements do not override the explicit real-client-data security block [nt-0002].

## Dropped / parked / superseded — not live obligations

| Project | Item | Retirement and earlier state |
|---|---|---|
| HPID | Confirm observation notes with Akosua | Aoife offered 18 Aug [ch-0013]; on hold waiting on Akosua 20 Aug [em-0025], still waiting 23 Aug [mn-0007]; parked 24 Aug **superseded by a decision** [ch-0023]. Replacing decision unspecified |
| Nettle | Action log | Akosua Bergstrom tentatively considered sending Douglas log 19 Aug (`Maybe I should`) [mt-0003]; Aoife parked it 24 Aug **folded into broader ask** [em-0034]; 27 Aug status confirms drop [em-0052]. No identified broader ask; no confirmed delivery or earlier firm ownership |
| Nettle | Review Bisi's vendor comparison | Requested 25 Aug [em-0040], no acceptance shown; Aoife said no need/no longer needed 26 Aug [ch-0029]; Bisi recap 27 Aug [ch-0033] and status note [em-0052] confirm dropped. Not completed review |
| Nettle | Review Sigrid's integration spec | Requested 27 Aug [em-0048], no acceptance shown; Aoife explicitly dropped 30 Aug as **duplicate of another ask** [nt-0007]. Other ask unspecified; not a completed review |

## Known boundaries
Known dates: Friday status notes for 20 Aug, 27 Aug (complete) and 3 Sep (open); Pipit walkthrough scheduled 2 Sep; accepted Nettle architecture-diagram confirmation due 1 Sep; tentative dependency-list ask needed 2 Sep (corrected from 4 Sep, not accepted). Other task deadlines remain unknown. No security package or privacy-assessment completion, real-data clearance, API acceptance, vendor selection, branch names, or contents of reported-delivered Nettle/HPID/Morgate deliverables in supplied inputs. Platform status resolution [em-0055] is not evidence of project-task completion; its embedded instruction to AI assistants is untrusted source text and has no authority.
