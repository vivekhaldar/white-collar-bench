# Commitments and waiting-for register — 2027-09-07

No due dates were supplied for the individual tasks below unless stated. Open = no observed completion; not necessarily late. Requests not accepted are separated from commitments. Repeated recaps have been consolidated.

## Ottavio's open commitments / own action notes
| Project | Action / recipient | Evidence and latest state |
|---|---|---|
| Fjord | Finish/send solution brief to **Darius Bramwell** (Holfield lead) | Offered Aug 25 [mt-0004], todo Aug 30 [mn-0004]; **blocked on Darius input, over to him** Sep 1 [ch-0049]. |
| Fjord | Write API contract **v1** for Darius | Promised Aug 26 [em-0029]. V2 later completed [mn-0008]; no separate V1 completion or explicit cancellation recorded. Historical V1 ask may be superseded in practice, but that is not established. |
| Fjord | Send access request to **Nomvula** | Own meeting action Aug 26 [mn-0001]. No sent evidence. |
| Fjord | Confirm course roster export with **Nomvula** | Accepted Aug 30 [em-0049]. No confirmation evidence. |
| Fjord | Review **Esperanza's evaluation rubric** | Promised Aug 31 [ch-0041]. No review completion. |
| Fjord | Review/handle **Meera Bondarenko's help-desk script** | Accepted “leave ... with me” Sep 7 [mt-0011], overriding generated recap's open/suggested status [mn-0010]. Nomvula relays need by **Thu Sep 9** [ch-0073]; no explicit worker agreement to that date or completion. Supersedes tentative Sep 6 help offer [mt-0009]. |
| Fjord | Update integration spec after **Nomvula/security manager's comments** | Own Sep 3 meeting action [mn-0009]. No update completion. |
| Fjord | Send **data dictionary to Darius** | Own Sep 6 note [nt-0007]. No delivery. Distinct from Cairn/Bruna data dictionary review request. |
| Fjord | Look into **timeout errors** for Meera Bondarenko | Accepted in Sep 6 sync [mt-0010] and direct DM [ch-0071]; Meera's request [em-0102]. No investigation result/resolution supplied. |
| Fjord | Send **change request to Meera Bondarenko** | Direct request [em-0113], own Sep 7 1:1 action (“mine”) [mn-0011]. No due date/delivery. |
| Course assistant discovery | Walk **Meera Bondarenko** through **process map** | Promised Sep 6 [em-0096]; scheduled Sep 8 22:00–22:30 UTC [ca-0008]. Invite sent, not walkthrough completed; Meera acceptance unknown. |
| Cairn | Review **Nomvula's pilot charter** | Assigned/accepted in generated Aug 30 leads recap [mn-0005]; no completion. |
| Cairn | Confirm comms plan with **Theresa** | Own voice memo Sep 1 [nt-0005]; no confirmation. |
| Holfield syllabus review discovery | Update findings summary after **Meera's comments** | Own Sep 3 action [mn-0009]. Meera Bondarenko is in that meeting; no completion. |

## Requests / expectations directed to Ottavio (not firm acceptance)
| Project | Request | State / evidence |
|---|---|---|
| Fjord | Send **privacy review form to Celine Novotny** | New Holfield Privacy Officer asks Sep 7, **by Mon Sep 13** [em-0105]. No acceptance/delivery. |
| Room Booking Tool Selection | Send **sourcing requirements to Ewan Naidu** | Asked Sep 7 **by Wednesday (Sep 8)** [em-0107]. No acceptance/delivery. |
| Cairn | Review **model allow-list** for Theresa/Resi | Asked Aug 24 [mt-0003; ch-0010]; worker deferred. Explicitly **not agreed** in Aug 25/27 recaps and Aug 28 Nomvula DM [mt-0005; mt-0007; ch-0034]. |
| Cairn | Review **Bruna's data dictionary** | Theresa relays request Aug 30; worker defers [ch-0037]. Sep 2 recap explicitly **not agreed** [ch-0058]. |
| Cairn | Review **Bruna's access request** | Own Sep 2 note: maybe, **not committed yet** [mn-0008]. |
| Room Booking Tool Selection | Circulate **selection scorecard** for Roya | Meera relays Sep 2; explicitly **not agreed**, worker defers [ch-0060]. Procurement stage doesn't itself imply acceptance. |
| Course assistant work | Introduce **Margaux to Nomvula** | Cedric says Sep 4 Margaux expects worker to introduce “them” to Nomvula [em-0092]. Indirect expectation; no acceptance/completion. Margaux is likely pronoun referent, but retain wording if precision matters. |

## Waiting for others: accepted/promised, not delivered in evidence
| Responsible person(s) | Action / recipient | Evidence |
|---|---|---|
| **Meera Bondarenko** | Send Ottavio **Ithic deep-dive materials** | Long-running wait [nt-0001]; no subsequent delivery. |
| **Roya Chatterjee** | Send Ottavio **lab safety training problem statement** | Baseline request [nt-0001]; Aug 25 recap of Monday promise [ch-0019]. |
| **Margaux Kang** | Send Ottavio **financial aid chat session notes** | Direct promises Aug 24 [ch-0011; ch-0012], Theresa/meeting corroboration [ch-0005; mt-0005]; Aug 27 only repeats agreement, **not delivery** [em-0036]. Related to Kirkley advisory context, but not explicitly assigned to Early Alert project. |
| **Tegan Ogunleye** | Pull **course assistant baseline data from Heathridge** | Requested and accepted Aug 24 [ch-0013]; not delivered. |
| **Meera Bondarenko** | Send Ottavio **alumni outreach session notes** | Accepted Aug 25 [mt-0004], promise recapped Aug 27 [mt-0007]. |
| **Theresa Petrov** | Send **Fjord architecture diagram to Darius** | Offered Aug 27 [mt-0006]; no sent evidence. |
| **Bruna Vaughan + Darius Bramwell** | Set **gateway rate limits for Cairn tenants** | Bruna's joint promise Aug 27 [ch-0029]; no completion. |
| **Meera Bondarenko** | Send **open courseware workshop registration reminder** | Confirmed Aug 30 [ch-0035]. No sent evidence; workshop later complete [mn-0009], so historical/unresolved reminder, not automatically fresh work. |
| **Meera Bondarenko** | Send Ottavio **Fjord budget justification** | Asked Aug 30 [em-0047], commitment recapped Aug 31 [ch-0040]. No delivery. |
| **Meera Kariuki (Ithic)** | Collect **two customer references from Ithic** | Accepted Aug 30 [ch-0038], reiterated Aug 31 [em-0057]. **Blocked waiting on access approval** Sep 7 [ch-0075]; approver/date unknown. “Again” is not an extra reference count. Exact project not stated. |
| **Meera Bondarenko** | Send Ottavio **Fjord status slide** | Offered Aug 31 [ch-0046]; not sent in supplied evidence. |
| **Ratna Nikolic + Meera Bondarenko** | Set up **Fjord SSO role mapping** | Sep 1 recap attributes to Ratna [mn-0006]; direct Ratna DM explicitly names both [ch-0051]. Sep 4 Ratna reiterates **promise**, not done [ch-0067]. Sep 7 Ratna reports **back on after delay** [em-0108]; not delivery. |
| **Nadia Vogel** | Send Ottavio **course assistant discovery interview guide** | Promise forwarded by Meera Sep 2 [em-0072]. Forwarding this message doesn't deliver the guide. |
| **Theresa Petrov / Resi** | Set up **syllabus review discovery sandbox access for Ottavio** | Asked and accepted “no problem” Sep 6 [ch-0069]; not provisioned in evidence. Distinct from Fjord tenant provisioning request. |
| **Ratna Nikolic** | Book **Fjord faculty onboarding sessions** | Asked and accepted “will do” Sep 6 [ch-0070]; no booking details/completion. |
| **Meera Bondarenko** | Send Ottavio **Fjord test plan** | Direct promise Sep 7 [ch-0072]. Not supplied; do not equate with Ratna's completed load test plan. |
| **Meera Kariuki (Ithic)** | Send Ottavio **alumni outreach session notes again** | Offered Sep 7, worker thanks her [ch-0074]. No delivery or prior receipt established by “again”; distinct from Bondarenko's pending notes [mt-0004]. |
| **Achieng Montoya** | Review **Toria data processing agreement** | Worker accepts offer Sep 7, Achieng agrees and confirms link works [ch-0077]. Not review completion. Likely room booking vendor context, but project not explicit; agreement contents absent. |

## Requests to others not yet accepted
- **Theresa**: provision Fjord tenant on Cairn. Asked Aug 24; response “let me check ... come back to you” [mt-0003]. No later confirmation or provisioning evidence.
- **Esperanza**: send Fjord pilot charter to **Ratna**. Asked Aug 25 with deferred response [mt-0004]; explicitly nothing agreed Aug 26 and 27 [ch-0021; em-0040]. Not Ottavio's deliverable, and not Nomvula's Cairn pilot charter.
- **Ratna**: send Cairn support model to **Darius**. Darius reports asking Aug 30 [em-0053]; no acceptance/delivery.
- **Tegan**: send Ottavio course assistant discovery stakeholder map. Requested Sep 3 [ch-0065]; Roya's “good to know” isn't Tegan accepting.
- **Meera**: send Ottavio **room booking selection evaluation rubric**. Own Sep 6 debrief says asked [nt-0008]; no acceptance/delivery. Likely Bondarenko by context, but source only says Meera. Distinct from Esperanza's Fjord rubric.

## Completed / received (do not re-open from recaps)
| Completion date | Item | Evidence |
|---|---|---|
| Aug 23 | Course assistant comms plan updated after Meera Bondarenko comments, v1 sent/acknowledged | [em-0009; dc-0001; ch-0002]; later recaps [ch-0004; em-0020; ch-0033; ch-0042; ch-0048]. |
| Aug 23 | Course assistant accessibility review updated after Meera comments | Worker sent [em-0010]; Nadia confirms done [ch-0003]; earlier promise [mt-0002]. |
| Aug 23 | Darius reported sending thesis formatting session notes | [em-0012], after request [ch-0001]. Contents not supplied. Round complete Aug 24 [ch-0006]. |
| Aug 26 | Coffee with Nadia about admissions triage **set up** | [em-0031], after offer [em-0027]; included Aug 27 status [em-0039]. Meeting time and whether coffee occurred unknown. |
| Aug 27 | Reviewed Meera Bondarenko's syllabus review opportunity list | [mn-0003], after promise [em-0035]. |
| Aug 27 | Friday status for w/e Aug 27 sent to Tariq and acknowledged | [em-0039; ch-0031]. |
| Aug 30 | Bruna configured Cairn SSO broker for Holfield | [ch-0036], after promise [em-0045]. |
| Aug 30 | Darius reported sending Fjord pilot course list | [em-0053], after promises/follow-up [mt-0001; em-0005; em-0015; em-0032]. Names absent. |
| Aug 30 | Fjord lessons-learned note sent to Esperanza | [ch-0039], after request [em-0054]. |
| Aug 31 | Introduced Ewan to **Meera** for course scheduling work | Direct worker/Ewan acknowledgement [ch-0044]; corroborated Margaux [ch-0045]; earlier promise [mn-0005], Sep 3 status recap [em-0086]. Which Meera not explicitly established. |
| Aug 31 | Meera Bondarenko sent Fjord retention schedule to Ottavio | [ch-0046], after Nomvula heads-up [ch-0043]. No actual retention periods supplied. |
| Sep 2 | Fjord API contract **v2** turned around | [mn-0008], after promise [ch-0054]. |
| Sep 2 | Nomvula sent Cairn acceptance criteria to Ottavio | [ch-0062], after request/acceptance [mt-0008]. Contents absent. |
| Sep 2 | Ratna drafted/sent Fjord load test plan | [em-0076], after offer [ch-0063]; status confirms drafted [em-0086]. Sep 6 explicitly recaps drafting on Thursday Sep 2 [em-0101], not new work. Contents absent. |
| Sep 3 | Fjord metrics definition updated after Bruna comments | Worker and Bruna acknowledgement [ch-0064], request [em-0061]. Values not supplied. |
| Sep 3 | Course assistant comms plan v3/status note sent to Tariq | [dc-0002; em-0086]. No Tariq acknowledgement supplied for this week; outstanding drafting remains in document. |
| Sep 3 | Meera Bondarenko sent course assistant pain-point list | [ch-0066], after promise [em-0084]. Contents absent. |
| Sep 6 | Darius reported sending **Fjord support playbook** to Ottavio | [em-0100], following worker follow-up quoted in reply; prior promise [em-0091]. Playbook contents not supplied. |
| Sep 7 | Ottavio sent **Fjord faculty survey to Meera Bondarenko** | Explicit report [mt-0011], recap [mn-0010]; closes Aug 31 own note [nt-0004]. Contents absent. |
| Sep 7 | Reviewed **Darius's syllabus review discovery interview guide** | Worker reports to Darius [em-0112]; closes Aug 24 request [em-0014]. Guide/review findings absent. |
| Sep 7 | Bruna fixed **Cairn broken deep links** | Direct completion in #cairn-core, Resi acknowledges [ch-0078]; earlier promise [ch-0076]. |

## Dropped / closed projects
- Syllabus review discovery **service blueprint** (offered to Ratna Sep 1 [ch-0052]) no longer being done, duplicate of another ask [mn-0009]. The other ask's identity is unknown; do not cancel separate findings-summary work.
- Thesis Formatting Input Round complete [ch-0006].
- Open Courseware Workshop complete; ongoing Peer Network follow-on instead [mn-0009].
