"""One-time ingest of supplied artifacts; retain searchable text, no secrets/links."""
from pathlib import Path
import json, re, email.policy
from email.parser import BytesParser

def sanitize(text):
    # Links are unnecessary for evidentiary memory; strip all, including meeting joins.
    text = re.sub(r'(?im)^.*(?:passcode|password|access code|meeting id|join link|api[_ -]?key|secret|credential|token\s*[:=]).*$', '[sensitive line omitted]', text)
    text = re.sub(r'https?://[^\s<>"\)]+', '[link omitted]', text)
    return text

index_path = Path('sources/index.json')
index = json.loads(index_path.read_text()) if index_path.exists() else []
for mf in sorted(Path('inbox').glob('*/manifest.json')):
    m=json.loads(mf.read_text()); chunks=[]
    # Replace only this day's entries; earlier inboxes are no longer available.
    index = [a for a in index if a['date'] != m['date']]
    for a in m['artifacts']:
        p=mf.parent/a['path']
        if p.suffix=='.eml':
            msg=BytesParser(policy=email.policy.default).parsebytes(p.read_bytes())
            body=msg.get_body(preferencelist=('plain',))
            text='\n'.join(f'{h}: {msg[h]}' for h in ['From','To','Cc','Date','Subject'] if msg[h])+'\n\n'+(body.get_content() if body else '')
        elif p.name.startswith('ch-'):
            d=json.loads(p.read_text()); text=f"Channel: {d['channel']}\n"+'\n'.join(f"{x['ts']} {x['user']}: {x['text']}" for x in d['messages'])
        elif p.suffix=='.docx':
            from docx import Document
            d=Document(p); text='\n'.join(x.text for x in d.paragraphs)+'\n'+'\n'.join(' | '.join(c.text for c in r.cells) for t in d.tables for r in t.rows)
        elif p.suffix=='.pdf':
            from pypdf import PdfReader
            text='\n'.join(p.extract_text() for p in PdfReader(p).pages)
        else: text=p.read_text()
        text=sanitize(text)
        chunks.append(f"## {a['id']} — {a['title']}\nReceived: {a['received_at']}\nChannel: {a['channel']}"+(f"\nParent: {a['parent']}" if a.get('parent') else '')+'\n\n'+text+'\n')
        index.append(dict(a,date=m['date'],archive=f"sources/{m['date']}.md",path=p.name))
    out=Path('sources')/(m['date']+'.md');out.parent.mkdir(exist_ok=True);out.write_text('# Source record — '+m['date']+'\n\n'+'\n'.join(chunks))
Path('sources/index.json').write_text(json.dumps(index,indent=2))
