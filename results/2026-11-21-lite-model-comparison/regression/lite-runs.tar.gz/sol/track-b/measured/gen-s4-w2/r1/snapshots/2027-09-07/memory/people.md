# People and organizations

Worker: **Ottavio Moreira**, SLIO, Drayhurst University System [nt-0001; em-0009]. No specific job title supplied. Roles and project associations below from portfolio map [nt-0001] unless another ID is shown.

| Person | Role / organization | Relevant relationships |
|---|---|---|
| Tariq Ivanova | Associate Provost for Academic Technology, SLIO | Sponsor for most SLIO projects; receives weekly Friday status notes [em-0001; em-0044]. |
| Meera **Bondarenko** | Head of Learning Services, SLIO | Fjord, Cairn, room booking selection, both discoveries, workshop, thesis input, early alert, lab safety, Ithic diligence, learning series. Workshop/learning series owner. Usually “Meera” / @meera in SLIO context. |
| Darius Bramwell | Dean of Libraries, Holfield State College | Owner Fjord and Holfield syllabus review; Holfield lead in solution-brief notes [mn-0004; mt-0004]. |
| Ratna Nikolic | Service Desk Lead, Holfield | Fjord/Cairn/syllabus review. Load test plan and joint SSO role mapping [em-0076; ch-0051]; promised Fjord faculty onboarding bookings Sep 6 [ch-0070]. |
| Theresa Petrov / **Resi** | Lead, Cloud Platforms, SLIO | Cairn owner/platform lead [nt-0001; ch-0010; ch-0034]; accepted syllabus review sandbox access setup Sep 6 [ch-0069]. “Theresa P.” in Sep 6 sync is consistent with listed attendee [mt-0010]. |
| Nomvula Ndlovu | Information Security Manager, SLIO | Fjord and Cairn; “security manager” [nt-0001; mn-0009]. |
| Bruna Vaughan | Platform Engineer, SLIO | Fjord/Cairn; SSO broker [ch-0036], gateway limits with Darius [ch-0029]. |
| Esperanza Venkataraman / **Espe** | Product Owner, Student Systems, SLIO | Fjord; evaluation rubric/lessons-learned note [ch-0041; ch-0039]. |
| Yaroslav Moyo | CIO, Holfield | Fjord; forwards Darius's support playbook promise [em-0091]. |
| Roya Chatterjee | Director, Teaching & Learning Technology, Heathridge | Owner room booking selection, course assistant discovery, lab safety idea; workshop and learning series involvement. |
| Solene Yassin | CIO, Heathridge | Sponsor room booking selection and course assistant discovery. |
| Tegan Ogunleye | Site Reliability Engineer, Heathridge | Room booking selection/course assistant/workshop; course assistant baseline data [ch-0013]. |
| Nadia Vogel | Instructional Designer, Heathridge | Room booking/course assistant/workshop; admissions triage coffee [em-0031]. |
| Isabela Haidari | Account Executive, **Toria Analytics** | Room booking vendor contender. |
| Meera **Kariuki** | Account Executive, **Ithic Learning** | Vendor contact asked to collect two customer references [ch-0038; em-0057]. Not Meera Bondarenko even though chat display name is “Meera.” |
| Ishaan Bergstrom | Director of Advising, University of Kirkley | Owner Early Alert Advisory. |
| Margaux Kang | Service Desk Lead, Kirkley | Early alert; financial aid chat notes still promised [ch-0011; em-0036]; expected Nomvula introduction per Cedric [em-0092]. |
| Ewan Naidu | **Procurement Officer, System Procurement, Drayhurst University System** [em-0107] | Requests room booking sourcing requirements by Sep 8 [em-0107]. Introduced to “Meera” for course scheduling Aug 31 [ch-0044]; which Meera still unknown. Do not equate introduction with receipt of Ithic deep-dive materials. |
| Celine Novotny | **New Privacy Officer, Holfield State College** | Introduces herself Sep 7; Fjord among first work, requests privacy review form by Sep 13 [em-0105]. |
| Achieng Montoya | Role/organization unknown | Agrees to review Toria data processing agreement, confirms link access Sep 7 [ch-0077]; not evidence of completed review. |
| Cedric Yoon | Role unknown; sender address at frostwick-research.example | Sep 4 relays Margaux's introduction expectation [em-0092]. Formal affiliation not otherwise supplied. |
| Teagan Alexiou | Role/organization unknown | Team retro and social chats [mn-0002; ch-0026]. **Distinct from Tegan Ogunleye.** |
| Yael Costa | Events Coordinator, Drayhurst | Room booking confirmations and survey [em-0011; em-0018]. |
| Freja Kealoha | Conference Organizer | Regional Digital Services Summit call closes Sep 12 [em-0050]. |
| Funmilayo Danjuma | Newsletter sender; formal role unknown | The Quad Ledger [em-0017; em-0067]. |

## Disambiguation and source caution
- “Meera” in `dm-meerak-ottavio`/Ithic email is **Meera Kariuki** [ch-0038; em-0057], including Sep 7 alumni outreach notes offer [ch-0074] and blocked customer references [ch-0075]. Keep her notes promise separate from Bondarenko's [mt-0004]. Other SLIO Meera chats generally identify Bondarenko. Ewan introduction sources only say Meera [mn-0005; ch-0044; ch-0045; em-0086], so exact person unknown.
- Sep 7 generated Fjord recap [mn-0010] says help-desk-script acceptance still open, but transcript has Ottavio saying leave it with him [mt-0011]; prefer explicit speech. Recap lists Ishaan, transcript attendee list doesn't: his attendance not certain. Transcript's “my” script after Meera's “my” script is an ownership/pronoun inconsistency, not a second established deliverable.
- Transcripts contain misspellings: “Ottabio/Ottabio” → Ottavio, “Dariuse” → Darius, “Margauks” → Margaux, “Nombula” → Nomvula. Resolve by attendee lists and matching direct sources, not as new people [mt-0001; mt-0004; mt-0005; mt-0007; mt-0008]. “Nomvula's iPhone” is a device display label [mt-0003].
- Holfield State College, Heathridge University and University of Kirkley are campus partners. SLIO is the Systemwide Learning Innovation Office, within Drayhurst University System [nt-0001].
- **Falcombe Center for Digital Pedagogy** partners on research computing series [nt-0001]; the new Open courseware Peer Network maintains its relationship [mn-0009].
- Room booking Toria/Ithic evaluation and Ithic **course scheduling** diligence are separate projects [nt-0001]. “Holfield discovery” (syllabus) and “Heathridge discovery” (course assistant) are distinct, not Fjord.
