# People and organizations

Worker is **Hiba Deng**, at Clinical Digital Services (CDS), Iselvale Health Partners; identity is explicit in emails such as `em-0001` and outgoing `em-0022`. Portfolio map `nt-0001` is Hiba's own map (project owner “me” resolves to Hiba). Hiba's job title is not supplied.

## Core directory

Roles below from `nt-0001` unless otherwise cited.

| Person | Role / organization | Context / aliases |
|---|---|---|
| Lindiwe Ribeiro | Chief Digital Officer, CDS | Sponsor across all seven baseline projects; receives Hiba's weekly status notes (`em-0022`, `em-0053`); transcript “Lin diwe” resolves here |
| Isla Faure | Chief Nursing Officer, Falbury Community Clinics | Owner Wagtail and nurse scheduling selection; discovery partner; “Isla F.” in transcript context |
| Anahit Fifita | Director of Digital Programs, CDS | **Programs director** in `mt-0008` resolves here; chat `@anahit`, display “Anahit”; Wagtail/discovery/Okapi/selection collaborator. March 30 `@anahit` service blueprint request / FAQ recap resolve to Fifita, not Jeong (`ch-0049`, `ch-0052`; full-name `ch-0053`, `ch-0054`). Role also in email signature `em-0057` |
| Rudo Ekwueme | Revenue Cycle Analyst, Falbury Community Clinics | Export/metrics owner; “Rudo Ekwueme (Guest)” same participant in `mt-0011` |
| Lakshmi Figueroa | Principal, Integration Platform, CDS | Owner Okapi platform and operating model; “Lakshmi F.” transcript variant |
| Friederike Bhatt | Principal, Information Security, CDS | Goes by **Rike**; `@friederike`; transcript “Freederike” variants normalize only in matching context. Wagtail change request outstanding (`ch-0040`); promised Okapi test plan with Anahit Fifita (`ch-0051`); needs Wagtail RACI chart by April 1, relayed by Anahit (`ch-0054`) |
| Jisoo Nowak | Integration Engineer, CDS | Falbury SSO broker, vault rotation; `@jisoo` |
| Maricel Fuentes | Product Lead, Clinical Apps, CDS | Wagtail and leads calls |
| Rodrigo Okada | Chief Medical Information Officer, Falbury Community Clinics | Wagtail |
| Petra Moretti | Account Executive, Grion Systems | Deep-dive materials still promised; Grion questionnaire returned (`em-0003`, `ch-0028`) |
| Tahmina Rosales | Supply Chain Contracts Manager, Iselvale Health Partners | Nurse scheduling selection; Hiba set up prior authorization coffee (`em-0053`) |
| Sneha Arslan | Director of Pharmacy, Garfield General Hospital | Owner supply par levels placeholder; owes problem statement; operating model review participant |

## Additional people — only known facts

- **Anahit Jeong**: Marys Health vendor contact; forwarded email uses `anahit.jeong@marys.example`, chat handle **`@anahitj`**. Promised Marys security questionnaire March 25 and returned March 26 (`em-0048`, `ch-0039`). **Not Anahit Fifita**. Job title not given.
- **Marcelo Brandao**: **Director, Finance Shared Services**. Hiba promised Wagtail run-cost estimate March 26 (`mt-0012`, 05:59), reported sent March 29, Marcelo acknowledged (`ch-0046`); chat handle `@marcelo`. No email address or estimate amount supplied.
- **Kwame Zamora**: denials analytics session notes promised to Hiba March 16 (`ch-0004`); quarterly priorities attendee (`mt-0002`). Role/organization not explicitly given; transcript “Kwamey” in `mt-0004` resolves via the direct chat.
- **Aylin Kocak**: Hiba catch-up attendee (`mt-0001`); requested Wagtail privacy impact assessment by March 31 (`ch-0012`). Role not supplied; don't infer privacy officer from request alone.
- **Burak Jaber**: Talton Rehabilitation Center; cross-hospital AI forum attendee (`mn-0002`). Role not supplied.
- **Theodora Vu**: Events Coordinator; room bookings, catering menu and survey (`em-0007`, `em-0008`, `em-0009` and subsequent booking emails). Role explicit in signature; organizational affiliation not independently detailed beyond Iselvale email context.
- **Bruna Bergstrom**: sender of Clinical IT Briefing issues 11 and 12 (`em-0013`, `em-0046`); no project action or role supplied.

## Organization map

- **Iselvale Health Partners**: worker's organization; **Clinical Digital Services (CDS)**: worker's team (`nt-0001`).
- **Falbury Community Clinics**: Wagtail pilot, nurse scheduling selection, clinical documentation discovery; Isla, Rudo, Rodrigo (`nt-0001`).
- **Garfield General Hospital**: Sneha, supply par levels placeholder, operating model review context, referral triage diligence context (`nt-0001`).
- **Grion Systems** and **Marys Health**: vendors in nurse scheduling tool evaluation; also associated with referral triage diligence in baseline map. Same vendor name does not merge the efforts (`nt-0001`).
- **Talton Rehabilitation Center**: Burak's affiliation (`mn-0002`).

## Attribution cautions

Automatic transcripts explicitly warn that names/spellings may be inaccurate. Hiba is sometimes “Hibah”; Rike is Friederike. Use direct chat handles, full-name email signatures and baseline directory to resolve variants, not phonetics alone. Do not merge the two Anahits. The supply par levels idea, Grion referral diligence, clinical documentation discovery, and nurse scheduling selection are distinct even when people or topics overlap.
