# Commitments ledger — 2027-03-30

No completion is inferred from silence or reactions. “Open” means no completion evidence through March 30, not proof nothing happened. Dates are 2027; absent deadlines remain unknown. This ledger consolidates duplicates/recaps rather than counting them as new tasks.

## Accepted / worker-owned, still open

| Task | Recipient / collaborator | Accepted / evidence | Due | Latest state |
|---|---|---|---|---|
| Update nurse scheduling selection risk register after Rudo's comments | Request relayed by Anahit | March 16, Hiba “sure, can do” (`ch-0003`) | Not stated | No completion |
| Confirm Okapi status slide | Anahit Fifita | Own todo March 23 (`nt-0003`) | Not stated | No completion; distinct from Wagtail slide |
| Present clinical documentation discovery readout to Falbury | With Anahit Fifita (programs director) | March 24, Hiba offered both presenters (`mt-0008`, 28:43; role `nt-0001`) | Not stated | No completion; no separate explicit acceptance by Anahit supplied |
| Walk Anahit through Wagtail risk register | Anahit Fifita | March 29, Hiba “I'll walk you through” (`em-0061`) | Scheduled April 1, 14:00–14:30 UTC−05:00 (`ca-0005`) | Invite organized by Hiba; Anahit NEEDS-ACTION; no completion |
| Send Okapi cutover plan | Anahit Fifita | Own todo March 29 (`nt-0006`) | Not stated | No delivery |
| Friday status note w/e April 2 | Lindiwe Ribeiro | Weekly assignment March 29 (`em-0060`) | **EOD April 2** | No delivery; half-page movement/slips/leadership needs; reply for extension |
| Take ownership of Wagtail stale cache | Anahit Fifita | March 30 “leave ... with me” (`mt-0014`, 05:16) | Not stated | No resolution; exact action unspecified |
| Send Okapi retention schedule | Anahit Fifita | March 30 offer accepted by Anahit (`mt-0014`, 16:34–16:39) | Not stated | No delivery |

## Reported worker assignment (direct acceptance not supplied)

| Task | Assignment evidence | Due | Latest state |
|---|---|---|---|
| Draft nurses FAQ for Wagtail | Anahit Fifita reports earlier sync assigned Hiba (`ch-0052`, March 30) | **April 6**, edited from April 5 | No completion; distinct from service blueprint review; sync unidentified |

## Waiting on other people

| Person | Deliverable / action | First evidence | Latest evidence / state |
|---|---|---|---|
| Lakshmi Figueroa | Publish Okapi tenant onboarding guide | March 15 promise (`em-0002`) | No publication evidence |
| Petra Moretti | Send Grion deep-dive materials | Baseline request and March 15 offer (`nt-0001`, `em-0003`) | No receipt; unrelated to returned security questionnaire |
| Sneha Arslan | Supply par levels problem statement | Long-running item in March 15 map (`nt-0001`) | No later update |
| Kwame Zamora | Denials analytics session notes to Hiba | March 16 “will do” (`ch-0004`) | Recapped March 17 (`mt-0004`, 05:45), no receipt |
| Jisoo Nowak | Configure Falbury Okapi SSO broker | March 16 “I'll configure” (`ch-0005`) | March 17 “back on” (`ch-0009`): resumed/reactivated, configuration completion unconfirmed |
| Lakshmi Figueroa | Generate Wagtail synthetic patient dataset | March 18 offer (`ch-0011`) | No generated/delivered evidence |
| Friederike Bhatt / Rike | Wagtail change request to Hiba | March 19 accepted (`mt-0006`, 15:08), recap `ch-0016` | Hiba still waiting March 26 (`ch-0040`) |
| Anahit Fifita | Clinical documentation discovery opportunity list | March 23 assigned (`mn-0006`, automatic) | March 26 resumed (`ch-0042`); March 29 “moving again” in retro debrief (`nt-0005`), not explicit delivery |
| Anahit Fifita | Clinical documentation discovery findings summary | March 24 promise (`mt-0009`, 18:12) | March 29 “back on” (`ch-0045`), resumed not delivered; distinct from opportunity list |
| Lakshmi Figueroa | Send Okapi capacity plan | March 25 “Yeah, no problem” (`mt-0011`, 14:30) | March 30 “got what i needed” / “moving again” (`ch-0056`): resumed, no receipt |
| Isla Faure | Share Wagtail budget justification with Hiba | March 26 promise (`mt-0012`, 10:42) | No receipt |
| Anahit Fifita | Send nurse scheduling selection pricing comparison to Hiba | March 29 promise (`mt-0013`, 18:19) | No receipt/deadline |
| Jisoo Nowak | Set up Okapi test tenant login for Hiba | March 29 worker note says asked (`nt-0006`) | Requested, not yet accepted or completed in evidence |
| Lakshmi Figueroa | Send Okapi operating model draft v3 to Hiba | March 30 offer acknowledged by Hiba; Lakshmi “no problem” (`ch-0050`) | No delivery/deadline; unidentified link working is not delivery evidence |
| Friederike Bhatt, with Anahit Fifita | Send Okapi test plan to Hiba | March 30 direct promise (`ch-0051`) | No delivery/deadline; separate from test login |
| Jisoo Nowak | Share Okapi training outline with Hiba | March 30 relayed by Rudo “as discussed” (`ch-0055`) | No direct Jisoo acceptance, delivery or deadline |

## Requests / suggestions Hiba has NOT accepted

| Request | Requester | Requested due | Evidence and response |
|---|---|---|---|
| Complete Wagtail privacy impact assessment | Aylin Kocak | **March 31** | March 18, Hiba “can i come back to you on this?” (`ch-0012`). Checkmark reaction is not acceptance |
| Review Rudo's Okapi metrics definition | Rudo | None stated | March 19, Hiba “Let me check what I've got on and come back to you” (`mt-0006`, 04:29) |
| Reference note for referral triage fellowship application | Anahit Fifita | None stated | March 19, Hiba “I'll think about it” (`mt-0006`, 10:33) |
| Send Wagtail data-flow diagram to Friederike | Friederike via Anahit | None stated | March 20, Hiba “can i come back to you on this?” (`ch-0017`) |
| Review Rudo's Wagtail bed census extract | Rudo, relayed by Isla | **March 25**, edited from March 27 | March 22 explicitly “not agreed yet” (`ch-0025`). Requested date has passed; not an overdue accepted task |
| Update nurse scheduling requirements matrix after Anahit's comments | March 23 sync | None stated | Suggested Hiba only; “No owner agreed yet” (`mn-0006`, automatic). Distinct from accepted risk register update |
| Review Anahit's Wagtail order set review | Anahit Fifita | None stated | Requested March 29 (`em-0062`); no acceptance. Not completed Rike's Okapi review |
| Send Wagtail RACI chart to Rike | Hiba's tentative offer, then Friederike via Anahit | **April 1**, requested March 30; earlier tentative window April 5–11 | March 29 “I could ... sometime next week?”; no firm commitment (`mt-0013`, 28:16–28:38). March 30 Anahit says Friederike needs it by Thursday April 1 (`ch-0054`); no Hiba acceptance |
| Review Anahit's Wagtail service blueprint | Anahit Fifita (`@anahit`) | **March 31** (“tomorrow” on March 30) | Hiba “thanks for flagging” / tada reaction is not acceptance (`ch-0049`); distinct from order set review |

## Closed / delivered

| Task | Performer → recipient | Completed | Supporting IDs / distinctions |
|---|---|---|---|
| Wagtail API contract v2 | Hiba → Anahit | March 17 | Request accepted `ch-0003`; delivery `em-0010`; recaps `mn-0001`, `mn-0002`; status `em-0022` |
| Referral backlog wait-time export | Rudo → Hiba | March 17 | Promise `em-0014`; sent `ch-0010`; recaps `mt-0005`, `em-0022`; export contents unknown |
| Assemble Wagtail security review package | Hiba → Friederike / team | March 18 | Request `ch-0013`; done `ch-0014`; v1 March 19 `dc-0001`; reports `em-0022`, `mt-0007`; not approval |
| Friday status note w/e March 19 | Hiba → Lindiwe | March 19, 16:31 UTC−05:00 | Due EOD March 19 `em-0001`; assignment recaps `mt-0002`, `mt-0003`, `mt-0004`, `mn-0002`, `mt-0005`; sent `em-0022`; receipt `ch-0026` |
| Wagtail accessibility review | Anahit → Hiba | March 20 | Offered `ch-0017`; sent `ch-0018`; recap `ch-0021` |
| Wagtail status slide | Anahit → Hiba | March 22 | Waiting `nt-0002`; shared `ch-0019`; not Okapi slide confirmation |
| Wagtail metrics definition | Rudo → Hiba | March 22 | Announcement `ch-0020`; sent `ch-0022`; recaps `mn-0005`, `ch-0037`; not Okapi metrics review |
| Rotate Okapi vault secrets | Jisoo | March 22 | Assignment `ch-0023`; done `ch-0024`; report `em-0053`; no values retained |
| Set up prior authorization coffee with Tahmina | Hiba → Tahmina | By March 23 | Promise `em-0028`; automatic “done” `mn-0004`; direct status says set up `em-0053`. Coffee occurrence/time unknown |
| Set up prior authorization coffee with Jisoo | Hiba → Jisoo | March 23 | Promise `em-0036`; set up `ch-0027`; coffee occurrence/time unknown |
| Return Grion security questionnaire | Petra → team / Hiba notified | March 24 | Forwarded promise `em-0035`; returned `ch-0028`; not deep-dive materials |
| Review Friederike's Okapi order set review | Hiba → Friederike | March 24 | Commitment `mt-0010`, 17:17; done `ch-0032` |
| Wagtail integration spec | Lakshmi → Hiba | March 25 | Offer `ch-0033`; sent `ch-0036`; recap `em-0052` |
| Return Marys security questionnaire | Anahit **Jeong** → team / Hiba notified | March 26 | Forwarded promise `em-0048`; returned `ch-0039`; not Fifita |
| Confirm Wagtail decision memo with Friederike | Hiba ↔ Friederike | March 26 | Commitment `mt-0008`, 19:23; confirmed `ch-0043`; memo contents unknown |
| Run Wagtail go-live checklist with Anahit Fifita | Hiba with Anahit | March 26 | Commitment `mt-0011`, 13:25; ran `em-0054`; does not prove go-live |
| Friday status note w/e March 26 | Hiba → Lindiwe | March 26, 17:14 UTC−05:00 | Due EOD March 26 `em-0026`; assignment `mn-0007`; sent `em-0053` |
| Set up portal message routing coffee with Lakshmi | Hiba → Lakshmi | March 27 | Forwarded request `em-0057`; set up `em-0059`; occurrence/time unknown |
| Send Wagtail run-cost estimate | Hiba → Marcelo Brandao | March 29, 11:09 UTC−05:00 | Promise `mt-0012`, 05:59; Hiba says sent, Marcelo acknowledges `ch-0046`; amount/content unknown |
| Revise Wagtail evaluation plan | Hiba → Isla / team | March 29, earlier that day | Promise `mt-0012`, 11:30; reported complete at 15:52, Isla acknowledges `ch-0047`; contents unknown |
| Draft Okapi on-call rota | Lakshmi → team | March 29, 08:03 UTC−05:00 | Assignment `mn-0006`; done `ch-0044`, acknowledged by Rike; publication/implementation not established |
| Send clinical documentation discovery stakeholder map | Hiba → Isla | March 30, 13:51 UTC−05:00 | Request `em-0065`, acceptance `ch-0048`, sent `em-0067`; map contents unknown |
| Confirm Wagtail vendor comparison | Hiba ↔ Anahit Fifita | March 30, earlier that day | Promise `mt-0014`, 10:11; Hiba reports confirmed `ch-0053`; not nurse scheduling pricing comparison |

## Planning question still unresolved

Whether referral backlog becomes its own effort: next step in FCDD pivot March 16 (`ch-0006`). No final decision, separate project charter, owner or target date supplied.
