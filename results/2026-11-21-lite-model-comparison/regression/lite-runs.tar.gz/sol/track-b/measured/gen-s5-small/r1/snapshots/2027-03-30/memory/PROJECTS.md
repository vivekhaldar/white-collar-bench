# Portfolio and decisions

As of **2027-03-30**. Worker: Hiba Deng, Clinical Digital Services (CDS), Iselvale Health Partners. Baseline project map is `nt-0001`. Lindiwe Ribeiro sponsors every project listed in that map. Target dates below are baseline targets, not proof of a confirmed launch or selection.

## Wagtail

**Aliases:** Project Wagtail, prior authorization pilot, Falbury pilot. AI prior-authorization triage pilot at Falbury Community Clinics, hosted on Okapi; owner Isla Faure; sponsor Lindiwe. Baseline target **2027-04-21**, four wards (`nt-0001`).

**Latest stage: readiness.** Isla said on March 25 that there were no blockers at that point; next step was to run the go-live checklist with Falbury (`mt-0011`, 03:23–03:47 and 07:46). Hiba ran the checklist with Anahit Fifita on March 26 (`em-0054`). This does **not** establish that Wagtail is live, that the security review formally approved real patient data, or that every follow-up is closed.

### History, decisions and risks

- March 15: in build, four-ward pilot (`nt-0001`).
- March 18: in security review; blocked, real patient data paused pending security review (`mn-0003`). Lakshmi offered to generate synthetic patient data, but no delivery evidence exists (`ch-0011`).
- March 24: automatic standup recap records decision **limit pilot to four wards**, consistent with baseline scope (`mn-0008`, `nt-0001`). It does not name a decision-maker or provide rationale.
- March 25: readiness, no current blockers according to Isla (`mt-0011`), superseding the old blocked status as the latest reported project state. Formal security clearance remains unknown.
- March 26 status note flags tight timelines on “the flagship”; it does not explicitly name the project (`em-0053`). Do not overstate attribution. Standups also include general concerns about scope creep and overcommitment (`mt-0011`, `mt-0012`).

### Delivered / completed

- API contract v2: Hiba accepted request March 16 (`ch-0003`), sent to Anahit March 17 (`em-0010`); confirmed done by automatic recaps March 18 (`mn-0001`, `mn-0002`) and Hiba's March 19 status note (`em-0022`).
- Security review package: Rike requested March 18 (`ch-0013`); Hiba assembled it that day, acknowledged by Friederike (`ch-0014`). March 19 package v1 exists as `dc-0001`; Hiba reported completion to Lindiwe (`em-0022`); March 22 leads call recapped the Thursday completion (`mt-0007`). Assembling package is not security approval.
- Package v1 content: prepared by Hiba, dated March 19; shorter than prior version, detail moved to appendix; figures indicative/rounded; scope unchanged; support carried over; governance draft/comments welcome; timeline out of scope. Open questions: who maintains it after project ends, and whether current scope is still right (`dc-0001`). No numerical cost estimate or detailed approval is provided in that document.
- Accessibility review: Anahit offered March 20 (`ch-0017`), sent that day (`ch-0018`), recapped March 22 (`ch-0021`). Contents not supplied.
- Status slide: Hiba waiting March 19 (`nt-0002`); Anahit shared March 22 and Hiba acknowledged (`ch-0019`). Contents not supplied.
- Metrics definition: Isla said Rudo would send March 22 (`ch-0020`); Rudo sent later that morning (`ch-0022`); March 23 automatic recap and March 25 DM confirm (`mn-0005`, `ch-0037`). This is distinct from the requested review of Rudo's **Okapi** metrics definition.
- Integration spec: Lakshmi offered March 25 (`ch-0033`), sent that afternoon (`ch-0036`); Anahit recapped March 26 (`em-0052`). Contents not supplied.
- Decision memo: Hiba committed March 24 to confirm with Friederike (`mt-0008`, 19:23); Hiba confirmed with Rike March 26 (`ch-0043`). Memo contents unknown; do not conflate with security review package or change request.
- Go-live checklist: Hiba committed March 25 to run with Anahit (`mt-0011`, 13:25); completed March 26 (`em-0054`). Outcomes/checklist contents unknown.
- Run-cost estimate: promised to Marcelo March 26 (`mt-0012`, 05:59); Hiba reported sent March 29 at 11:09, Marcelo acknowledged (`ch-0046`). Amount/content unknown.
- Evaluation plan: committed March 26 (`mt-0012`, 11:30); Hiba reported revised earlier March 29, Isla acknowledged (`ch-0047`). Revisions/content unknown.
- Vendor comparison: Hiba committed to confirm with Anahit Fifita March 30 (`mt-0014`, 10:11); Hiba explicitly reported confirmed earlier that day (`ch-0053`). Contents unknown; distinct from nurse scheduling pricing comparison.

### Still open / not accepted

- **Friederike → Hiba: change request.** Accepted March 19 (`mt-0006`, 15:08; `ch-0016`); Hiba explicitly still waiting March 26 (`ch-0040`).
- **Lakshmi → Hiba: synthetic patient dataset.** Offered March 18, no delivery (`ch-0011`).
- **Isla → Hiba: budget justification.** Promised March 26, no delivery (`mt-0012`, 10:42).
- **Hiba → Anahit Fifita: walk through Wagtail risk register.** Committed March 29 (`em-0061`); Hiba organized April 1, 14:00–14:30 UTC−05:00 invite, Anahit NEEDS-ACTION (`ca-0005`). Not completed; distinct from nurse scheduling risk register update.
- **Review Anahit's Wagtail order set review:** requested March 29, not accepted (`em-0062`). Distinct from completed Rike's Okapi review.
- **Send Wagtail RACI chart to Rike:** Hiba floated “I could ... sometime next week?” March 29 (`mt-0013`, 28:16–28:38), tentatively April 5–11. March 30 Anahit relayed that Friederike needs it by **Thursday April 1** (`ch-0054`), an earlier requested deadline. Still no firm Hiba acceptance or delivery.
- **Draft nurses FAQ for Wagtail:** Anahit's March 30 recap of an earlier sync assigns Hiba, due **April 6**, edited from April 5 (`ch-0052`). Reported assignment, no direct acceptance or completion supplied; do not infer the cancelled standup was that sync.
- **Wagtail stale cache:** Hiba accepted ownership (“leave ... with me”) March 30 (`mt-0014`, 05:16). Action details/deadline and resolution unknown.
- **Review Anahit's Wagtail service blueprint by March 31:** requested March 30 (`ch-0049`); Hiba said “thanks for flagging” and reacted with tada, neither constitutes acceptance. Separate from order set review.
- Privacy impact assessment by March 31: Aylin requested March 18; Hiba said “can i come back to you on this?” despite checkmark reaction. **Not accepted** in supplied evidence (`ch-0012`).
- Data-flow diagram to Friederike: Anahit relayed request March 20; Hiba deferred, **not accepted** (`ch-0017`).
- Review Rudo's bed census extract: **not agreed**, requested due **March 25**, edited from March 27. Requested date passed, but not an overdue accepted commitment (`ch-0025`).

## Okapi platform

**Aliases:** platform, common platform, Okapi platform. Shared AI platform for hospital projects; owner Lakshmi Figueroa; sponsor Lindiwe (`nt-0001`). Distinct from the operating model review.

- March 15 baseline: onboarding tenants (`nt-0001`).
- **Latest stage: hardening**, announced March 18 (`em-0016`).
- **Decision:** route **all Okapi tenants through one model gateway**, confirmed by Lakshmi March 24 (`em-0039`). No exception or rationale given.
- Hardening review March 29 moved from 09:00–09:45 to **11:00–11:45, UTC−05:00**; same calendar UID, sequence 1 supersedes sequence 0 (`ca-0003`, `ca-0004`). Attendance acceptance not known.
- Tenant onboarding guide: Lakshmi promised publication March 15, no evidence of publication (`em-0002`).
- Falbury SSO broker: Jisoo committed to configure March 16 (`ch-0005`); March 17 said it was “back on, sorry for the delay” (`ch-0009`). This is resumption/reactivation, not unambiguous completion of configuration.
- Vault secrets rotation: Lakshmi announced Jisoo would do it March 22 (`ch-0023`); Jisoo reported rotated earlier that day (`ch-0024`), later included in Hiba's status note (`em-0053`). No secret values retained.
- On-call rota: Lakshmi assigned to draft in March 23 automatic recap (`mn-0006`); reported drafted March 29, Rike acknowledged (`ch-0044`). Drafting complete; publication/implementation unknown.
- Cutover plan: Hiba's March 29 own todo to send to Anahit; no delivery (`nt-0006`).
- Test tenant login: Hiba noted asking Jisoo to set up an Okapi test tenant login for Hiba March 29; no acceptance/completion evidenced (`nt-0006`). No login credentials retained.
- Capacity plan: Hiba requested March 25, Lakshmi agreed to send (`mt-0011`, 14:30). March 30 Lakshmi says “got what i needed” and plan “is moving again” (`ch-0056`): resumed, not delivered.
- Status slide: Hiba's own March 23 todo to confirm with Anahit; no completion (`nt-0003`). Do not confuse with completed **Wagtail** slide sharing.
- Order set review: Hiba committed March 24 to review Rike's Okapi order set review (`mt-0010`, 17:17); completed later that day (`ch-0032`).
- Rudo's metrics definition review: requested March 19; Hiba deferred to check workload, not accepted (`mt-0006`, 04:29).
- Retention schedule: Hiba offered to send to Anahit Fifita, who accepted March 30 (`mt-0014`, 16:34–16:39). Open; no delivery/deadline or schedule contents supplied.
- Test plan: Friederike promised to send to Hiba “with Anahit Fifita” March 30 (`ch-0051`). No delivery/deadline; not the test tenant login.
- Training outline: Rudo relayed March 30 that Jisoo will share with Hiba “as discussed” (`ch-0055`). No direct Jisoo acceptance, delivery or deadline.

## Nurse Scheduling Tool Selection

**Aliases:** nurse scheduling bake-off, Grion/Marys evaluation, NSTS selection. Owner Isla; sponsor Lindiwe; selecting Falbury nurse scheduling tool between Grion Systems and Marys Health. Baseline stage waiting on vendor questionnaires; target **2027-04-09** (`nt-0001`). No final choice or new formal stage is evidenced.

- Hiba agreed March 16 to update risk register after Rudo's comments. No completion/date known (`ch-0003`).
- Reference-check notes: Hiba recorded decision **use approach A** March 29 (`nt-0004`). No explanation, alternatives, decision-maker beyond note attribution, or implementation evidence supplied.
- Pricing comparison: Anahit Fifita promised to send to Hiba March 29; no receipt/date known (`mt-0013`, 18:19).
- Requirements matrix update after Anahit's comments: automatic March 23 recap explicitly says **no owner agreed yet**, Hiba only suggested. Not accepted (`mn-0006`). Distinct from risk register.
- Grion security questionnaire: Petra promised return via forwarded email March 23 (`em-0035`); returned March 24, Hiba acknowledged (`ch-0028`). Actual answers not supplied.
- Marys security questionnaire: **Anahit Jeong**, not Fifita, promised return via forwarded email March 25 (`em-0048`); returned March 26, Hiba acknowledged (`ch-0039`). Actual answers not supplied.
- Both named security questionnaires are returned as of March 26. Do not keep them marked pending. This does not prove all vendor answers, scoring or selection are complete. Hiba's March 19 status note reported some vendor answers outstanding without naming them (`em-0022`).

## Falbury Clinical Documentation Discovery

**Aliases:** Falbury discovery, clinical documentation work, FCDD discovery. Owner **Hiba**, sponsor Lindiwe; Falbury with Anahit, Isla, Rudo; baseline target **2027-05-05** (`nt-0001`).

- March 15: site visits, problem framing moving (`nt-0001`).
- March 16: **pivot**; next step decide whether referral backlog becomes its own effort (`ch-0006`). No later explicit split decision is supplied.
- March 19: Hiba reported **analysis** (`mt-0006`, 03:47).
- **Latest stage: readout**, Isla announced March 22 (`em-0032`).
- Rudo promised referral backlog wait-time export March 17 (`em-0014`), reported sent that evening (`ch-0010`), recapped March 18 (`mt-0005`, 11:16) and Hiba's March 19 status note (`em-0022`). Export contents not supplied.
- Hiba committed March 24 that Hiba and “our programs director” can present discovery readout to Falbury (`mt-0008`, 28:43). Programs director resolves to **Anahit Fifita** using `nt-0001` / `em-0057`; no presentation completion or date supplied.
- Opportunity list: Anahit assigned to send in March 23 recap (`mn-0006`); March 26 “Picking ... back up now!” means resumed, **not delivered** (`ch-0042`). March 29 retro voice debrief says “got what i needed” and list “is moving again,” not explicit delivery of the list (`nt-0005`).
- Findings summary: Anahit promised to share March 24 (`mt-0009`, 18:12); March 29 “back on, sorry for the delay” means resumed, not delivered (`ch-0045`). Separate from opportunity list and completed wait-time export.
- Stakeholder map: Isla requested March 29 by email and chat; Hiba accepted (“will do”) (`em-0065`, `ch-0048`); **sent March 30, 13:51 UTC−05:00** via outgoing email (`em-0067`). Map contents not supplied.

## Okapi Operating Model Review

**Aliases:** operating model review, ops model draft, Okapi operating model. Owner Lakshmi, sponsor Lindiwe; platform operating model for peer review before leadership; Anahit and Sneha involved; Garfield General Hospital context (`nt-0001`).

- Baseline out for review March 15 (`nt-0001`).
- **Latest stage: revision**, Lakshmi stated March 25 (`mt-0011`, 10:06), Hiba reported March 26 to Lindiwe (`em-0053`). No leadership approval or subsequent stage known.
- Draft v3: March 30 Hiba thanked Lakshmi for offering to send the Okapi operating model draft v3; Lakshmi said “no problem” (`ch-0050`). Waiting on Lakshmi, no delivery/deadline. Later “link worked” exchange does not identify the link or establish draft delivery.

## Garfield Supply Par Levels Idea

**Aliases:** Sneha's supply par levels idea, supply par levels placeholder. Owner Sneha Arslan; sponsor Lindiwe; Garfield General Hospital. **Still only a placeholder waiting on a problem statement**, based on March 15 map; Sneha owes it to Hiba. No later project-specific input (`nt-0001`). Do not infer movement from Sneha appearing in a forum.

## Grion Referral Triage Diligence

**Aliases:** Grion deep dive, referral triage diligence. Owner Hiba; sponsor Lindiwe; Garfield General Hospital, Grion Systems, Marys Health. Baseline **in diligence**, early enthusiasm but no dated activity (`nt-0001`). Petra said March 15 she can send deep-dive materials; no receipt/completion evidenced (`em-0003`). Do not confuse this with nurse scheduling selection or mark materials received because the Grion security questionnaire was returned.

## Cross-project / other

- Weekly status notes to Lindiwe: w/e March 19 sent March 19 at 16:31 (`em-0022`), receipt recapped March 23 (`ch-0026`); w/e March 26 sent March 26 at 17:14 (`em-0053`). Both complete. Next note w/e **April 2** due to Lindiwe by EOD April 2; half-page movement/slips/leadership needs, extension by reply (`em-0060`). No delivery yet.
- Prior authorization coffees: Tahmina arrangement complete by March 23 automatic recap (`mn-0004`), directly supported in March 26 status note as **set up** (`em-0053`); Jisoo arrangement completed March 23 (`ch-0027`, following `em-0036`). Neither proves coffee occurred. March 29 retro debrief retrospectively says Hiba set up the Tahmina coffee “on tuesday” (`nt-0005`); exact Tuesday/meeting time unclear, not evidence of attendance or a new coffee commitment.
- Portal message routing coffee with Lakshmi: requested in forwarded March 27 email (`em-0057`); Hiba set up that afternoon (`em-0059`). No meeting time or new project defined.
- Kwame owes denials analytics session notes: agreed March 16 (`ch-0004`), recapped March 17 (`mt-0004`), no receipt. Project association is not explicitly stated; don't conflate with completed referral export.
- Anahit Fifita requested reference note for referral triage fellowship application March 19; Hiba said “I'll think about it,” not accepted (`mt-0006`, 10:33). No fellowship deadline given.
