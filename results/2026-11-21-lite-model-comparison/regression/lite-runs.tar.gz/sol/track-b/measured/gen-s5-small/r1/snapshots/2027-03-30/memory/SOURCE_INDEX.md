# Source index

All 158 input artifacts from 2027-03-15 through 2027-03-30 are preserved as searchable text. Calendar join details and passcodes are omitted. DOCX text is extracted; automatic summaries/transcripts remain explicitly fallible. Received timestamps are not necessarily event timestamps.

| ID | Received | Channel | Title | Retained source |
|---|---|---|---|---|
| em-0001 | 2027-03-15T07:03:00-05:00 | email | Reminder: Friday status note due Friday 19 March | [daily source](sources/2027-03-15.md) |
| nt-0001 | 2027-03-15T08:05:00-05:00 | note | Portfolio map | [daily source](sources/2027-03-15.md) |
| em-0002 | 2027-03-15T09:53:00-05:00 | email | Re: Okapi tenant onboarding guide | [daily source](sources/2027-03-15.md) |
| em-0003 | 2027-03-15T10:05:00-05:00 | email | FYI: Grion deep-dive materials | [daily source](sources/2027-03-15.md) |
| em-0004 | 2027-03-15T11:27:00-05:00 | email | All-staff: building access changes | [daily source](sources/2027-03-15.md) |
| em-0005 | 2027-03-15T12:31:00-05:00 | email | Reminder: all-staff meeting Thursday | [daily source](sources/2027-03-15.md) |
| ch-0001 | 2027-03-15T13:46:00-05:00 | chat | #general | [daily source](sources/2027-03-15.md) |
| ch-0002 | 2027-03-15T16:52:00-05:00 | chat | #general | [daily source](sources/2027-03-15.md) |
| mt-0001 | 2027-03-15T17:00:00-05:00 | transcript | Catch-up: Hiba / Aylin (transcript) | [daily source](sources/2027-03-15.md) |
| em-0006 | 2027-03-15T18:22:00-05:00 | email | Wellbeing week activities | [daily source](sources/2027-03-15.md) |
| ch-0003 | 2027-03-16T08:33:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng | [daily source](sources/2027-03-16.md) |
| em-0007 | 2027-03-16T10:11:00-05:00 | email | Catering menu for next month | [daily source](sources/2027-03-16.md) |
| em-0008 | 2027-03-16T11:00:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-16.md) |
| em-0009 | 2027-03-16T11:54:00-05:00 | email | Event space survey | [daily source](sources/2027-03-16.md) |
| ch-0004 | 2027-03-16T12:12:00-05:00 | chat | DM: Hiba Deng / Kwame Zamora | [daily source](sources/2027-03-16.md) |
| ch-0005 | 2027-03-16T12:48:00-05:00 | chat | #okapi-core | [daily source](sources/2027-03-16.md) |
| ch-0006 | 2027-03-16T13:08:00-05:00 | chat | DM: Isla Faure / Hiba Deng | [daily source](sources/2027-03-16.md) |
| ch-0007 | 2027-03-16T14:09:00-05:00 | chat | #coffee | [daily source](sources/2027-03-16.md) |
| ch-0008 | 2027-03-16T15:08:00-05:00 | chat | #general | [daily source](sources/2027-03-16.md) |
| mt-0002 | 2027-03-16T15:30:00-05:00 | transcript | Quarterly priorities (transcript) | [daily source](sources/2027-03-16.md) |
| em-0010 | 2027-03-17T07:19:00-05:00 | email | Re: Wagtail API contract v2 | [daily source](sources/2027-03-17.md) |
| em-0011 | 2027-03-17T07:47:00-05:00 | email | [Scheduled] Network maintenance window | [daily source](sources/2027-03-17.md) |
| ca-0001 | 2027-03-17T08:07:00-05:00 | calendar | Invite: Wagtail build sync | [daily source](sources/2027-03-17.md) |
| ch-0009 | 2027-03-17T09:05:00-05:00 | chat | DM: Jisoo Nowak / Hiba Deng | [daily source](sources/2027-03-17.md) |
| mt-0003 | 2027-03-17T09:55:00-05:00 | transcript | Wagtail standup (transcript) | [daily source](sources/2027-03-17.md) |
| em-0012 | 2027-03-17T13:01:00-05:00 | email | [INC-77668] Ticket updated | [daily source](sources/2027-03-17.md) |
| mt-0004 | 2027-03-17T14:45:00-05:00 | transcript | Wagtail build sync (transcript) | [daily source](sources/2027-03-17.md) |
| em-0013 | 2027-03-17T15:02:00-05:00 | email | Clinical IT Briefing: issue 11 | [daily source](sources/2027-03-17.md) |
| em-0014 | 2027-03-17T17:13:00-05:00 | email | Re: Referral backlog wait-time export | [daily source](sources/2027-03-17.md) |
| ch-0010 | 2027-03-17T18:46:00-05:00 | chat | DM: Rudo Ekwueme / Hiba Deng | [daily source](sources/2027-03-17.md) |
| ch-0011 | 2027-03-18T08:05:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-18.md) |
| mn-0001 | 2027-03-18T09:55:00-05:00 | meeting_notes | Recap: Wagtail standup | [daily source](sources/2027-03-18.md) |
| em-0015 | 2027-03-18T12:09:00-05:00 | email | [INC-51847] Ticket updated | [daily source](sources/2027-03-18.md) |
| em-0016 | 2027-03-18T13:18:00-05:00 | email | Okapi: moving to hardening | [daily source](sources/2027-03-18.md) |
| mn-0002 | 2027-03-18T14:00:00-05:00 | meeting_notes | Recap: Cross-hospital AI forum | [daily source](sources/2027-03-18.md) |
| ch-0012 | 2027-03-18T14:39:00-05:00 | chat | DM: Aylin Kocak / Hiba Deng | [daily source](sources/2027-03-18.md) |
| mn-0003 | 2027-03-18T16:00:00-05:00 | meeting_notes | Notes: Wagtail build sync | [daily source](sources/2027-03-18.md) |
| ch-0013 | 2027-03-18T16:21:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-18.md) |
| mt-0005 | 2027-03-18T16:30:00-05:00 | transcript | Catch-up: Hiba / Rudo (transcript) | [daily source](sources/2027-03-18.md) |
| ch-0014 | 2027-03-18T16:54:00-05:00 | chat | DM: Hiba Deng / Friederike Bhatt | [daily source](sources/2027-03-18.md) |
| em-0017 | 2027-03-18T18:15:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-18.md) |
| mt-0006 | 2027-03-19T09:55:00-05:00 | transcript | Wagtail standup (transcript) | [daily source](sources/2027-03-19.md) |
| em-0018 | 2027-03-19T10:23:00-05:00 | email | [REQ-37046] Request resolved | [daily source](sources/2027-03-19.md) |
| ch-0015 | 2027-03-19T10:58:00-05:00 | chat | #random | [daily source](sources/2027-03-19.md) |
| em-0019 | 2027-03-19T11:13:00-05:00 | email | Parking lot resurfacing | [daily source](sources/2027-03-19.md) |
| em-0020 | 2027-03-19T15:29:00-05:00 | email | [REQ-37278] Request resolved | [daily source](sources/2027-03-19.md) |
| em-0021 | 2027-03-19T16:25:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-19.md) |
| dc-0001 | 2027-03-19T16:31:00-05:00 | document | Wagtail security review package v1 | [daily source](sources/2027-03-19.md) |
| em-0022 | 2027-03-19T16:31:00-05:00 | email | Status note: w/e 19 March | [daily source](sources/2027-03-19.md) |
| ch-0016 | 2027-03-19T18:53:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-19.md) |
| nt-0002 | 2027-03-19T19:59:00-05:00 | note | Fri notes | [daily source](sources/2027-03-19.md) |
| em-0023 | 2027-03-20T09:04:00-05:00 | email | [REQ-20265] Request resolved | [daily source](sources/2027-03-20.md) |
| em-0024 | 2027-03-20T09:04:00-05:00 | email | [INC-78684] Ticket updated | [daily source](sources/2027-03-20.md) |
| em-0025 | 2027-03-20T09:50:00-05:00 | email | [Investigating] Intermittent sign-in delays | [daily source](sources/2027-03-20.md) |
| ch-0017 | 2027-03-20T12:08:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng | [daily source](sources/2027-03-20.md) |
| ch-0018 | 2027-03-20T12:19:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng | [daily source](sources/2027-03-20.md) |
| em-0026 | 2027-03-22T07:02:00-05:00 | email | Reminder: Friday status note due Friday 26 March | [daily source](sources/2027-03-22.md) |
| em-0027 | 2027-03-22T08:01:00-05:00 | email | Reminder: all-staff meeting Thursday | [daily source](sources/2027-03-22.md) |
| ch-0019 | 2027-03-22T08:16:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng | [daily source](sources/2027-03-22.md) |
| em-0028 | 2027-03-22T09:42:00-05:00 | email | Re: Coffee with Tahmina about prior authorization | [daily source](sources/2027-03-22.md) |
| ch-0020 | 2027-03-22T11:35:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-22.md) |
| ch-0021 | 2027-03-22T11:44:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-22.md) |
| mt-0007 | 2027-03-22T11:45:00-05:00 | transcript | CDS leads call (transcript) | [daily source](sources/2027-03-22.md) |
| ch-0022 | 2027-03-22T12:12:00-05:00 | chat | DM: Rudo Ekwueme / Hiba Deng | [daily source](sources/2027-03-22.md) |
| ch-0023 | 2027-03-22T12:38:00-05:00 | chat | #okapi-core | [daily source](sources/2027-03-22.md) |
| em-0029 | 2027-03-22T13:12:00-05:00 | email | [Investigating] Intermittent sign-in delays | [daily source](sources/2027-03-22.md) |
| em-0030 | 2027-03-22T13:43:00-05:00 | email | [Scheduled] Network maintenance window | [daily source](sources/2027-03-22.md) |
| ch-0024 | 2027-03-22T14:19:00-05:00 | chat | #okapi-core | [daily source](sources/2027-03-22.md) |
| em-0031 | 2027-03-22T16:17:00-05:00 | email | Scheduled maintenance this weekend | [daily source](sources/2027-03-22.md) |
| em-0032 | 2027-03-22T17:03:00-05:00 | email | Re: Falbury Clinical Documentation Discovery: moving to readout | [daily source](sources/2027-03-22.md) |
| ch-0025 | 2027-03-22T19:06:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-22.md) |
| ch-0026 | 2027-03-23T08:26:00-05:00 | chat | DM: Lindiwe Ribeiro / Hiba Deng | [daily source](sources/2027-03-23.md) |
| mn-0004 | 2027-03-23T09:00:00-05:00 | meeting_notes | Recap: Catch-up: Hiba / Isla | [daily source](sources/2027-03-23.md) |
| mn-0005 | 2027-03-23T10:00:00-05:00 | meeting_notes | Recap: Wagtail standup | [daily source](sources/2027-03-23.md) |
| em-0033 | 2027-03-23T12:40:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-23.md) |
| ca-0002 | 2027-03-23T12:58:00-05:00 | calendar | Invite: Wagtail security review | [daily source](sources/2027-03-23.md) |
| em-0034 | 2027-03-23T13:48:00-05:00 | email | [REQ-28898] Request resolved | [daily source](sources/2027-03-23.md) |
| mn-0006 | 2027-03-23T14:45:00-05:00 | meeting_notes | Recap: Okapi / Wagtail sync | [daily source](sources/2027-03-23.md) |
| em-0035 | 2027-03-23T14:48:00-05:00 | email | Fwd: Grion security questionnaire | [daily source](sources/2027-03-23.md) |
| mn-0007 | 2027-03-23T15:30:00-05:00 | meeting_notes | Recap: Clinical documentation discovery check-in | [daily source](sources/2027-03-23.md) |
| em-0036 | 2027-03-23T15:53:00-05:00 | email | Coffee with Jisoo about prior authorization | [daily source](sources/2027-03-23.md) |
| nt-0003 | 2027-03-23T16:12:00-05:00 | note | Tue notes | [daily source](sources/2027-03-23.md) |
| em-0037 | 2027-03-23T17:26:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-23.md) |
| ch-0027 | 2027-03-23T17:45:00-05:00 | chat | DM: Hiba Deng / Jisoo Nowak | [daily source](sources/2027-03-23.md) |
| em-0038 | 2027-03-23T17:58:00-05:00 | email | [Resolved] Elevated latency on file storage | [daily source](sources/2027-03-23.md) |
| ch-0028 | 2027-03-24T08:23:00-05:00 | chat | DM: Petra Moretti / Hiba Deng | [daily source](sources/2027-03-24.md) |
| ch-0029 | 2027-03-24T09:07:00-05:00 | chat | #random | [daily source](sources/2027-03-24.md) |
| mn-0008 | 2027-03-24T09:55:00-05:00 | meeting_notes | Recap: Wagtail standup | [daily source](sources/2027-03-24.md) |
| ch-0030 | 2027-03-24T11:12:00-05:00 | chat | #random | [daily source](sources/2027-03-24.md) |
| mt-0008 | 2027-03-24T11:30:00-05:00 | transcript | Wagtail security review (transcript) | [daily source](sources/2027-03-24.md) |
| em-0039 | 2027-03-24T12:37:00-05:00 | email | Re: All Okapi tenants through one model gateway | [daily source](sources/2027-03-24.md) |
| mt-0009 | 2027-03-24T13:00:00-05:00 | transcript | Catch-up: Hiba / Anahit (transcript) | [daily source](sources/2027-03-24.md) |
| mt-0010 | 2027-03-24T14:35:00-05:00 | transcript | Okapi platform sync (transcript) | [daily source](sources/2027-03-24.md) |
| ch-0031 | 2027-03-24T16:22:00-05:00 | chat | #coffee | [daily source](sources/2027-03-24.md) |
| em-0040 | 2027-03-24T17:55:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-24.md) |
| ca-0003 | 2027-03-24T18:08:00-05:00 | calendar | Invite: Okapi hardening review | [daily source](sources/2027-03-24.md) |
| em-0041 | 2027-03-24T18:13:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-24.md) |
| ch-0032 | 2027-03-24T18:20:00-05:00 | chat | #okapi-core | [daily source](sources/2027-03-24.md) |
| em-0042 | 2027-03-24T18:49:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-24.md) |
| em-0043 | 2027-03-25T06:44:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-25.md) |
| mt-0011 | 2027-03-25T10:00:00-05:00 | transcript | Wagtail standup (transcript) | [daily source](sources/2027-03-25.md) |
| ch-0033 | 2027-03-25T10:38:00-05:00 | chat | DM: Lakshmi Figueroa / Hiba Deng | [daily source](sources/2027-03-25.md) |
| em-0044 | 2027-03-25T12:46:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-25.md) |
| em-0045 | 2027-03-25T13:10:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-25.md) |
| ch-0034 | 2027-03-25T13:23:00-05:00 | chat | #random | [daily source](sources/2027-03-25.md) |
| em-0046 | 2027-03-25T15:35:00-05:00 | email | Clinical IT Briefing: issue 12 | [daily source](sources/2027-03-25.md) |
| em-0047 | 2027-03-25T15:52:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-25.md) |
| ch-0035 | 2027-03-25T16:10:00-05:00 | chat | #random | [daily source](sources/2027-03-25.md) |
| em-0048 | 2027-03-25T16:20:00-05:00 | email | Fwd: Marys security questionnaire | [daily source](sources/2027-03-25.md) |
| ch-0036 | 2027-03-25T17:10:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-25.md) |
| em-0049 | 2027-03-25T18:35:00-05:00 | email | [INC-89499] Ticket updated | [daily source](sources/2027-03-25.md) |
| ch-0037 | 2027-03-25T19:08:00-05:00 | chat | DM: Rudo Ekwueme / Hiba Deng | [daily source](sources/2027-03-25.md) |
| em-0050 | 2027-03-26T08:42:00-05:00 | email | Room booking confirmation | [daily source](sources/2027-03-26.md) |
| ch-0038 | 2027-03-26T08:59:00-05:00 | chat | #general | [daily source](sources/2027-03-26.md) |
| em-0051 | 2027-03-26T09:07:00-05:00 | email | [REQ-25109] Request resolved | [daily source](sources/2027-03-26.md) |
| mt-0012 | 2027-03-26T10:00:00-05:00 | transcript | Wagtail standup (transcript) | [daily source](sources/2027-03-26.md) |
| ch-0039 | 2027-03-26T11:50:00-05:00 | chat | DM: Anahit Jeong / Hiba Deng | [daily source](sources/2027-03-26.md) |
| ch-0040 | 2027-03-26T11:50:00-05:00 | chat | #wagtail-core | [daily source](sources/2027-03-26.md) |
| ch-0041 | 2027-03-26T12:38:00-05:00 | chat | #coffee | [daily source](sources/2027-03-26.md) |
| em-0052 | 2027-03-26T13:00:00-05:00 | email | Re: FYI: Wagtail integration spec | [daily source](sources/2027-03-26.md) |
| ca-0004 | 2027-03-26T13:08:00-05:00 | calendar | Updated: Okapi hardening review | [daily source](sources/2027-03-26.md) |
| ch-0042 | 2027-03-26T16:17:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng | [daily source](sources/2027-03-26.md) |
| em-0053 | 2027-03-26T17:14:00-05:00 | email | Status note: w/e 26 March | [daily source](sources/2027-03-26.md) |
| em-0054 | 2027-03-26T18:02:00-05:00 | email | Re: Wagtail go-live checklist | [daily source](sources/2027-03-26.md) |
| ch-0043 | 2027-03-26T18:14:00-05:00 | chat | DM: Hiba Deng / Friederike Bhatt | [daily source](sources/2027-03-26.md) |
| em-0055 | 2027-03-27T08:44:00-05:00 | email | [REQ-13307] Request resolved | [daily source](sources/2027-03-27.md) |
| em-0056 | 2027-03-27T08:46:00-05:00 | email | [REQ-32861] Request resolved | [daily source](sources/2027-03-27.md) |
| em-0057 | 2027-03-27T11:25:00-05:00 | email | Fwd: A coffee with Lakshmi about portal message routing | [daily source](sources/2027-03-27.md) |
| em-0058 | 2027-03-27T11:43:00-05:00 | email | [INC-87659] Ticket updated | [daily source](sources/2027-03-27.md) |
| em-0059 | 2027-03-27T16:55:00-05:00 | email | Re: Coffee with Lakshmi about portal message routing | [daily source](sources/2027-03-27.md) |
| em-0060 | 2027-03-29T07:05:00-05:00 | email | Reminder: Friday status note due Friday 2 April | [daily source](sources/2027-03-29.md) |
| nt-0004 | 2027-03-29T07:23:00-05:00 | note | Mon notes — selection reference-check approach A | [daily source](sources/2027-03-29.md) |
| em-0061 | 2027-03-29T08:29:00-05:00 | email | Re: Wagtail risk register | [daily source](sources/2027-03-29.md) |
| ch-0044 | 2027-03-29T08:36:00-05:00 | chat | #okapi-core — on-call rota drafted | [daily source](sources/2027-03-29.md) |
| em-0062 | 2027-03-29T09:01:00-05:00 | email | Anahit's Wagtail order set review | [daily source](sources/2027-03-29.md) |
| ch-0045 | 2027-03-29T10:33:00-05:00 | chat | DM: Anahit Fifita / Hiba Deng — findings summary resumed | [daily source](sources/2027-03-29.md) |
| ch-0046 | 2027-03-29T11:41:00-05:00 | chat | DM: Hiba Deng / Marcelo Brandao — run-cost estimate sent | [daily source](sources/2027-03-29.md) |
| mt-0013 | 2027-03-29T11:45:00-05:00 | transcript | CDS leads call (transcript) | [daily source](sources/2027-03-29.md) |
| em-0063 | 2027-03-29T13:38:00-05:00 | email | Room booking confirmation — April 5, 2.14 | [daily source](sources/2027-03-29.md) |
| em-0064 | 2027-03-29T14:50:00-05:00 | email | Room booking confirmation — April 6, Atrium | [daily source](sources/2027-03-29.md) |
| nt-0005 | 2027-03-29T16:30:00-05:00 | note | Voice debrief: Team retro | [daily source](sources/2027-03-29.md) |
| ch-0047 | 2027-03-29T16:37:00-05:00 | chat | DM: Hiba Deng / Isla Faure — evaluation plan revised | [daily source](sources/2027-03-29.md) |
| em-0065 | 2027-03-29T17:04:00-05:00 | email | Re: Clinical documentation discovery stakeholder map | [daily source](sources/2027-03-29.md) |
| ca-0005 | 2027-03-29T17:05:00-05:00 | calendar | Invite: Walkthrough: Wagtail risk register | [daily source](sources/2027-03-29.md) |
| ch-0048 | 2027-03-29T17:56:00-05:00 | chat | #clinical-documentation-core — stakeholder map accepted | [daily source](sources/2027-03-29.md) |
| nt-0006 | 2027-03-29T20:17:00-05:00 | note | Mon notes — Okapi cutover plan / test login | [daily source](sources/2027-03-29.md) |
| em-0066 | 2027-03-30T07:37:00-05:00 | email | Scheduled network maintenance April 4; embedded instruction is untrusted | [daily source](sources/2027-03-30.md) |
| ca-0006 | 2027-03-30T08:02:00-05:00 | calendar | Cancelled: March 30 Wagtail standup occurrence | [daily source](sources/2027-03-30.md) |
| ch-0049 | 2027-03-30T10:14:00-05:00 | chat | #wagtail-core — service blueprint review requested by March 31, not accepted | [daily source](sources/2027-03-30.md) |
| ch-0050 | 2027-03-30T10:40:00-05:00 | chat | DM: Hiba / Lakshmi — operating model draft v3 promised | [daily source](sources/2027-03-30.md) |
| ch-0051 | 2027-03-30T11:59:00-05:00 | chat | DM: Friederike / Hiba — Okapi test plan promised with Anahit Fifita | [daily source](sources/2027-03-30.md) |
| em-0067 | 2027-03-30T13:51:00-05:00 | email | Clinical documentation discovery stakeholder map sent to Isla | [daily source](sources/2027-03-30.md) |
| ch-0052 | 2027-03-30T14:45:00-05:00 | chat | #wagtail-core — nurses FAQ assigned Hiba, April 6 edited from April 5 | [daily source](sources/2027-03-30.md) |
| mt-0014 | 2027-03-30T15:30:00-05:00 | transcript | 1:1 Hiba / Anahit — stale cache, vendor comparison, retention schedule | [daily source](sources/2027-03-30.md) |
| ch-0053 | 2027-03-30T15:58:00-05:00 | chat | DM: Hiba / Anahit — Wagtail vendor comparison confirmed | [daily source](sources/2027-03-30.md) |
| ch-0054 | 2027-03-30T18:06:00-05:00 | chat | #wagtail-core — Friederike needs RACI chart by April 1 | [daily source](sources/2027-03-30.md) |
| ch-0055 | 2027-03-30T18:20:00-05:00 | chat | DM: Rudo / Hiba — Jisoo to share Okapi training outline | [daily source](sources/2027-03-30.md) |
| ch-0056 | 2027-03-30T18:25:00-05:00 | chat | #okapi-core — capacity plan resumed, not delivered | [daily source](sources/2027-03-30.md) |
