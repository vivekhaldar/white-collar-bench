# People and organizations

Worker is **Camila Abernathy**, City of Holcrest, **Office of Civic Technology (OCT)**. In the portfolio note, “me” means Camila. [nt-0001]

## Core people

Roles below are from 25 Oct portfolio map unless more specifically cited. Do not infer changed roles from later project assignments. [nt-0001]

| Person | Role / organization | Relevant ownership or interaction |
|---|---|---|
| **Fernanda Olawale** | Chief Digital Officer, OCT | Sponsor of most portfolio items except parking selection (Imran) and Ulworth benefits discovery (Karim). Receives Friday status notes; requested Tarn name/brief/findings; to approve Carys offer. [nt-0001; em-0001; em-0010; ch-0024; ch-0062; mt-0009] |
| **Jalen Sandberg** | Director of Delivery, OCT | Workshop owner; Camila's delivery counterpart across Marten, platform and discovery. Recipient of process map, slides, public notice; risk-register collaborator. [nt-0001; em-0081; em-0021; mt-0004; ch-0059] |
| **Petra Korkmaz** | Operations Manager, Birchcrest Department of Transportation | Marten owner; sponsor-side department counterpart. Sends/requests project inputs; to countersign Birchcrest agreement. [nt-0001; mt-0008] |
| **Sipho Sengupta** | Caseworker Supervisor, Birchcrest Department of Transportation | Workshop/parking/discovery counterpart. Author/sender of notice-translation process map v1. Asked to recruit five Tarn test caseworkers, not accepted in evidence. [nt-0001; dc-0004; em-0086; ch-0063] |
| **Dina Taufa** | Systems Administrator, Birchcrest Department of Transportation | With Camila on Marten security review package. [nt-0001; em-0030] |
| **Imran Achterhof** | Department Director, Birchcrest Department of Transportation | Parking-selection sponsor; requested Marten evaluation-rubric update; to send Marten service-request extract. [nt-0001; ch-0009; ch-0034] |
| **Yasmin Mokoena** | Principal, Platform Engineering, OCT | Owns Obsidian and operating-model review. Model-gateway decision; model allow-list/stakeholder map reviews; onboarding-guide publication; Marten comparison reviewer/input. [nt-0001; ch-0014; ch-0022; ch-0049; em-0066; em-0083] |
| **Thandiwe Garnier** | Platform Engineer, OCT | Configured Birchcrest Obsidian SSO broker 2 Nov. [nt-0001; ch-0041] |
| **Nadia Jovanovic** | Chief Information Security Officer (CISO), OCT | Marten diagram request not agreed; receives security package; asked timeline update; joint rollout-checklist/equity-review inputs. Meeting-minutes coffee setup with Camila. [nt-0001; em-0028; em-0030; em-0056; em-0046; ch-0064; ch-0010] |
| **Joselito Moradi** | Product Lead, Resident Services, OCT | Marten comms plan promised via Jalen; floated Jalen lessons-learned note 6 Nov, not agreed. [nt-0001; ch-0028; ch-0067] |
| **Karim Jansen** | Department Director, Ulworth Library Services | Ulworth benefits discovery sponsor. [nt-0001] |
| **Andrei Lindgren** | Chief of Staff, Ulworth Library Services | Benefits-discovery phase/blocker updates; duplicate-requests decision. Also operating-model-review participant. [nt-0001; ch-0006; em-0011; ch-0054] |
| **Ifeoma Chevalier** | GIS Analyst, Ulworth Library Services | Benefits screening; Camila updated pain-point list after Ifeoma's comments. [nt-0001; ch-0030; ch-0033] |
| **Corinne Kaya** | Systems Administrator, Ulworth Library Services | Promised baseline benefits-screening data pull. [nt-0001; em-0017] |
| **Yiannis Bustamante** | Recruitment Partner, City of Holcrest | Expected Camila's Carys panel feedback; panel attendee. [nt-0001; ch-0013; em-0015; ca-0003] |
| **Minji Vu** | Customer Service Manager, Corrbrook Housing Services | Service-request-triage input round participant; no newer input shown. [nt-0001] |
| **Rafiq Tetteh** | Deputy Director, Thorndale Public Works | Owns meeting-minutes idea; still owes problem statement requested by Camila. [nt-0001] |
| **Jalen Venkataraman** | Account Executive, Quino Systems | Asked for Quino permit-intake deep-dive materials; no receipt shown. **Different person from Jalen Sandberg.** [nt-0001] |

## Other people encountered

| Person | What is actually known |
|---|---|
| **Dalisay Dahl** | Sandstead Permitting Office affiliation supported by calendar email domain; involved in DE panel, conveyed panel and offer stages. **Job title not supplied.** [ch-0002; ca-0003; ch-0050] |
| **Carys** | DE-hire candidate; panel scheduled 2 Nov; feedback requested from Camila; offer awaiting Fernanda approval. **Surname, terms, start date and acceptance unknown.** [ch-0013; em-0015; ca-0003; em-0070; mt-0009] |
| **Katerina Vaughan** | Senior Research Scientist, Nantgate (explicit in Jalen's 3 Nov chat). Wants catch-up with Camila, not agreed. Not listed on separate 10 Nov Nantgate sync invite. [ch-0048; mt-0009; ca-0008] |
| **Hiba Overton** | Thorndale Public Works, 3 Nov relationship-check-in attendee. Camila offered pothole-reporting reading list 1 Nov. **Job title not supplied.** [em-0053; mt-0005] |
| **Aarav Zamora** | Requested and acknowledged Marten privacy impact assessment. OCT/municipal email presence not enough to infer formal title; **job title unknown.** [ch-0023; ch-0032; ch-0036] |
| **Kirsten Ellery** | Camila catch-up 29 Oct autogenerated notes list Kirsten; role/organization not established. **Not evidence Kirsten owns the benefits map.** [mn-0005] |
| **Freja Afolabi** | Events Coordinator; sends room-booking confirmations and event-space/catering notices. [em-0005; em-0019; em-0061] |
| **Kayode Kariuki** | Conference Organizer; Regional Digital Services Summit proposals close 17 Nov. [em-0065] |
| **Bayani Bishara** | Civic Tech Bulletin sender. No project assignment or formal title established. [em-0026; em-0060] |
| **Minji Chebet** | **Solutions Engineer, Zeneth Labs**; sent sandbox-setup notice 8 Nov. **Not Minji Vu** of Corrbrook. [em-0093; nt-0001] |
| **Niamh Obi** | Participant in 8 Nov quarterly priorities call; **role/organization unknown**. Reports possible second-floor Wi-Fi outage 9 Nov. [mt-0011; ch-0077] |
| **Venkatesh Yassin** | **Budget Director, City of Holcrest**. Says Tarn budget agreed 9 Nov, cannot put numbers in email yet; asks Camila for Tarn user journey map. Amount unknown; request not accepted in evidence. [em-0101] |

## Aliases / spelling cautions

- **Jalen**, **@jalen** in Holcrest project chats, and email nickname **J** refer to **Jalen Sandberg** based on DM titles, participants and portfolio context. **Jalen Venkataraman** must remain separate in vendor diligence. [ch-0013; ch-0015; em-0070; nt-0001]
- **Yanni** is Yiannis Bustamante in the Carys-feedback relay: direct email to Yiannis corroborates. [ch-0013; em-0015]
- **Thandi**, **Thandiwe**, **@thandiwe** are Thandiwe Garnier. [ch-0038; ch-0041; nt-0001]
- **Lito**, **Joselito**, **@joselito** are Joselito Moradi. DM manifest title identifies Joselito while participant is Lito. [ch-0067; ch-0028; nt-0001]
- **Nadia**, **CISO**, **N** are Nadia Jovanovic. Transcript **“Nadiah”** in coffee setup is likely spelling noise, supported by direct Nadia DM and follow-on notes. [nt-0001; ch-0010; mt-0002; mn-0004; em-0028]
- **Kate rina** in lunch-and-learn transcript is Katerina Vaughan, corroborated by chat. [mt-0009; ch-0048]
- **Camilah** in 5 Nov stakeholder-map transcript is Camila Abernathy. [mt-0008]
- **Minji Chebet** (Zeneth Labs) and **Minji Vu** (Corrbrook Housing Services) are distinct people; do not merge by first name. [em-0093; nt-0001]
- **platform lead / Yasmin's team** refer to Yasmin/platform engineering in the portfolio and platform-sync context. [nt-0001; mn-0003]

## Organizations / disambiguation

- **City of Holcrest / OCT:** worker's central team; Obsidian, central prototype/hiring/reporting work. [nt-0001]
- **Birchcrest Department of Transportation:** department on Marten, parking analytics, notice translation, Tarn and workshop in the source map. Preserve the map's “library help” Marten description despite transportation department; no correction established. [nt-0001]
- **Ulworth Library Services:** benefits screening, operating-model peer-review involvement and permit-intake diligence. [nt-0001]
- **Corrbrook Housing Services:** service-request triage input. [nt-0001]
- **Thorndale Public Works:** Rafiq meeting-minutes idea; Hiba pothole relationship item. [nt-0001; em-0053; mt-0005]
- **Nantgate Institute for Public Service Design:** relationship partnership; Katerina scientist. [nt-0001; ch-0048]
- **Sandstead Permitting Office:** Dalisay/hiring involvement. [ch-0002; ca-0003]
- **Zeneth Labs / Quino Systems:** named parking candidates and permit-diligence organizations. **No evidence maps them to unnamed Marten Option A/B.** [nt-0001; dc-0002]
